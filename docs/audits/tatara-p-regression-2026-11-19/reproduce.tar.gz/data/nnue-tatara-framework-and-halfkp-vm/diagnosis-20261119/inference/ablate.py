import numpy as np, argparse
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('rows');p.add_argument('npz');p.add_argument('output');args=p.parse_args()
rows=np.fromfile(args.rows,dtype='<i4').reshape(-1,296); src=np.load(args.npz)
w={k[8:]:src[k].astype(np.float64) for k in src.files if k.startswith('weights.')}
H=256; alpha=127/128;ko=8128/12
ix=np.arange(13680); rights=ix%12>=6; ci=ix//144*72+ix%144//12*6+np.minimum(ix%12,11-ix%12)
F=np.zeros((13681,256)); F[:-1]=w['ft_weights'][ci]; F[:-1][rights]=np.roll(F[:-1][rights],128,axis=1)
Q=np.r_[w['psqt'][ci],0]; fb=np.tile(w['ft_biases'],2)
l1=w['l1_weights']+w['l1_shared_weights']; b1=w['l1_biases']+w['l1_shared_biases']
l2=w['l2_weights'];b2=w['l2_biases'];l3=w['l3_weights'];b3=w['l3_bias']
def rnd(v): return np.sign(v)*np.floor(np.abs(v)+0.5)
def quant(v,sc):return rnd(v*sc)/sc
def towardzero(v):return np.trunc(v+np.sign(v)*1e-9)
def fl(v):return np.floor(v+1e-9)
def act(v):return v.clip(0.,1.)
scales='ft pair l1 skip z l2 u l3 psqt final'.split()
S=set(scales)
variants={'float':set(),'production':S,'hihead':S,'floath':S-{'l1','skip','l2','l3'},'exactft':S-{'ft'},'nearestact':S,'skiponlyhi':S,'no_floor':S-{'pair','z','u'},'idealafterft':{'ft'},'nearestall':S,'hi_ft':S}
for s in scales:variants['only_'+s]={s};variants['omit_'+s]=S-{s}
outs={k:[] for k in variants}
for start in range(0,len(rows),128):
 r=rows[start:start+128]; ids=r[:,4:].reshape(len(r),2,146);ids[ids<0]=13680
 af=(fb+F[ids].sum(axis=2));aq=(rnd(127*fb)+rnd(F[ids]*127).sum(axis=2))/127
 aqhigh=(rnd(255*fb)+rnd(F[ids]*255).sum(axis=2))/255
 q=Q[ids].sum(axis=2); q=(q[:,0]-q[:,1])/2
 qi=rnd(Q[ids]*8128).sum(axis=2);qi=towardzero((qi[:,0]-qi[:,1])/2)/8128
 for k,ss in variants.items():
  a=act((aqhigh if k=='hi_ft' else aq) if 'ft' in ss else af)
  pairs=(alpha*a[:,:,:128]*a[:,:,128:]).reshape(len(r),-1)
  rounda=rnd if k in ['nearestact','nearestall'] else fl
  if 'pair' in ss:pairs=rounda(127*pairs)/127
  den=256 if k=='hihead' else 64
  direct=4096 if k in ['hihead','skiponlyhi'] else 64
  Y=pairs@((quant(l1[:-1],den) if 'l1' in ss else l1[:-1]).T)+(quant(b1[:-1],127*den) if 'l1' in ss else b1[:-1])
  skip=pairs@(quant(l1[-1],direct) if 'skip' in ss else l1[-1])+(quant(b1[-1],127*direct) if 'skip' in ss else b1[-1])
  Z=np.concatenate([act(alpha*Y*Y),act(Y)],axis=1)
  if 'z' in ss:Z=rounda(127*Z)/127
  U=act(Z@((quant(l2,den) if 'l2' in ss else l2).T)+(quant(b2,127*den) if 'l2' in ss else b2))
  if 'u' in ss:U=rounda(U*127)/127
  od=4096 if k=='hihead' else 64
  out=(U@(quant(l3,od) if 'l3' in ss else l3)+(quant(b3,127*od) if 'l3' in ss else b3)+skip+(qi if 'psqt' in ss else q))*ko
  if 'final' in ss:out=towardzero(out).clip(-28999,28999)
  outs[k].extend(out)
A={k:np.array(v) for k,v in outs.items()};np.savez(args.output,**A)
assert np.array_equal(A['production'],rows[:,2]),(np.sum(A['production']!=rows[:,2]),np.max(abs(A['production']-rows[:,2])))
def stats(v):return ' '.join(f'{x:.3f}' for x in [v.mean(),np.mean(abs(v)),v.std(),np.quantile(abs(v),.99)])
r=rows[:,1]==0;c=~r;print('positions',r.sum(),'children',c.sum(),'exact',len(rows))
for k in A:
 print(k,stats((A[k]-A['float'])[r]))
groups=np.split(np.flatnonzero(c),np.flatnonzero(np.diff(rows[c,0]))+1)
for k in ['production','hihead','floath','no_floor','idealafterft','nearestact','hi_ft','exactft','skiponlyhi']:
 loss=[]; ties=[]; flip=tot=0; ranks=[]
 for g in groups:
  f=A['float'][g]; q=A[k][g];loss.append(f[np.argmin(q)]-min(f));ties.append(np.sum(q==min(q)))
  delta=f[:,None]-f; dq=q[:,None]-q;mask=(delta>0.1);tot+=mask.sum();flip+=np.sum(mask&(dq<0)); ranks.append(np.sum(f<f[np.argmin(q)]))
 print('moves',k,len(groups),np.mean(np.array(loss)>0.001),np.mean(loss),np.mean(ties),flip/tot,np.quantile(loss,.9),np.mean(ranks))

from pathlib import Path
import sys
p=Path(sys.argv[1]);s=(p.parent/'training/full_float.cpp').read_text()
s=s.replace('bool old;','bool old; uint64_t positive[32]={}; float maxima[32]={};').replace('h[i]=std::clamp(sum+b2[i],0.f,1.f);','h[i]=std::clamp(sum+b2[i],0.f,1.f); positive[i]+=(h[i]>0); maxima[i]=std::max(maxima[i],sum+b2[i]);')
s=s[:s.index('int main(')]+r'''
#include <bit>
#include <cstring>
#include <cassert>
int main(int argc,char**argv){Model old(argv[1],true),nw(argv[2],false);
int map[2][128][144];uint64_t total=0;
for(int s=0;s<2;s++)for(int c=0;c<128;c++)for(int sq=0;sq<144;sq++){
 int payload=(c&63)-1;if(payload<0||payload>=58)continue;
 int kind=payload%29;int st=kind;if(payload<29&&kind<20&&kind!=10&&kind!=11)st=29+kind-(kind>10)-(kind>11);
 map[s][c][sq]=((s!=(c>=64))*47+st)*144+(s?11-sq/12:sq/12)*12+sq%12;
}
std::vector<uint8_t> data(138*16384);
for(int i=3;i<argc;i++){FILE *f=fopen(argv[i],"rb");assert(f);size_t n;
while((n=fread(data.data(),138,16384,f))){total+=n;for(size_t j=0;j<n;j++){
 uint16_t ids[2][94];
 const uint8_t *r=data.data()+138*j,*v=r+21; int k=0;
 for(int block=0;block<3;block++){uint64_t bits=0;memcpy(&bits,r+8*block,block==2?2:8);
 while(bits){int pos=block*64+std::countr_zero(bits),c=(*v++)&127; for(int side=0;side<2;side++)ids[side][k]=map[r[18]^side][c][pos];++k;bits&=bits-1;}}
 if(r[19]<144){for(int s=0;s<2;s++)ids[s][k]=13536+((r[18]^s)?11-r[19]/12:r[19]/12)*12+r[19]%12;++k;}
 assert(k<94);ids[0][k]=ids[1][k]=65535;old.evaluate(ids);nw.evaluate(ids);
}}fclose(f);}
printf("positions %lld\n",(long long)total);
for(auto m:{&old,&nw}){printf("%s",m==&old?"old":"new");for(int i=0;i<32;i++)printf(" %llu",(long long)m->positive[i]);puts("");}
}
'''
(p/'full_activity.cpp').write_text(s)

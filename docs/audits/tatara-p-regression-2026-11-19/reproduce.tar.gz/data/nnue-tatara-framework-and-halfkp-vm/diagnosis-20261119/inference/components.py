import sys
from pathlib import Path
import numpy as np
P=Path(sys.argv[1]); net=Path(sys.argv[2]);src=np.load(net/'train-before/latest.npz'); src2=np.load(net/'train-after/latest.npz')
def w(s):return {k[8:]:s[k].astype(np.float64) for k in s.files if k.startswith('weights.')}
old=w(src);new=w(src2)
ix=np.arange(13680);rights=ix%12>=6;ci=ix//144*72+ix%144//12*6+np.minimum(ix%12,11-ix%12)
def ft(weight):
 f=np.zeros((13681,256));f[:-1]=weight[ci];f[:-1][rights]=np.roll(f[:-1][rights],128,axis=1);return f
fo=ft(old['ft.embedding.weight']); fn=ft(new['ft_weights']);L=np.vstack((old['linear.weight'][ci],[0,0]));Q=np.r_[new['psqt'][ci],0]
ao=np.tile(old['head.biases'],2);an=np.tile(new['ft_biases'],2);ko=8128/12;kt=float(src['cp_per_logit'])
rows=np.fromfile(P/'features.bin',dtype='<i4').reshape(-1,296)
out=[]
for start in range(0,len(rows),128):
 r=rows[start:start+128];ids=r[:,4:].reshape(len(r),2,146);ids[ids<0]=13680
 of=(fo[ids].sum(axis=2)+ao).clip(0,1);nf=(fn[ids].sum(axis=2)+an).clip(0,1);phi=(((ids[:,0]<13536).sum(axis=1)-2)/90).clip(0,1);ls=L[ids].sum(axis=2);qs=Q[ids].sum(axis=2);st=[]
 op=(of[:,:,:64]*of[:,:,64:128]+of[:,:,128:192]*of[:,:,192:])
 npair=127/128*nf[:,:,:128]*nf[:,:,128:]
 for i in [0,1]:
  ol=phi*ls[:,i,0]+(1-phi)*ls[:,i,1];nl=(qs[:,i]-qs[:,1-i])*ko/2
  rr=op[:,[i,1-i]].reshape(len(r),-1);direct=rr@old['head.output_weights'].reshape(-1)+old['head.output_bias']
  y=rr@old['head.hidden1_weights'].reshape(15,-1).T+old['head.hidden1_biases'];z=np.c_[(127/128*y*y).clip(0,1),y.clip(0,1)]
  u=(z@old['head.hidden2_weights'].T+old['head.hidden2_biases']).clip(0,1)
  oo=(u@old['head.hidden2_output']+direct)*kt
  pp=npair[:,[i,1-i]].reshape(len(r),-1);y=pp@(new['l1_weights']+new['l1_shared_weights']).T+new['l1_biases']+new['l1_shared_biases']
  v=y[:,:-1];z=np.c_[(127/128*v*v).clip(0,1),v.clip(0,1)];u=(z@new['l2_weights'].T+new['l2_biases']).clip(0,1)
  nn=ko*(u@new['l3_weights']+new['l3_bias']+y[:,-1])
  st.extend([ol,oo,nl,nn])
 out.extend(np.stack(st,axis=1))
np.save(P/'components.npy',out)

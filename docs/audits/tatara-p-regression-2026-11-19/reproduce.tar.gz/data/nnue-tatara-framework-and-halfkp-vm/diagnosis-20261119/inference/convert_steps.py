from pathlib import Path
import numpy as np,sys
orig=np.load(sys.argv[1]);data=Path(sys.argv[2])
for file in sorted(data.glob('step-*.raw')):
 arr=np.fromfile(file,'<f4');off=0;obj={'step':int(file.stem.split('-')[-1])}
 for k in orig.files:
  if not k.startswith('weights.'):continue
  x=orig[k];obj[k]=arr[off:off+x.size].reshape(x.shape);off+=x.size
 assert off==len(arr)
 np.savez(file.with_suffix('.npz'),**obj)

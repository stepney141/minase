#include <cstdint>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cassert>
#include <vector>
#include <bit>
using namespace std;
uint16_t table[2][128][144];uint64_t cnt[6841]{},records=0;
int main(int argc,char **argv){
 for(int s=0;s<2;s++)for(int c=0;c<128;c++)for(int sq=0;sq<144;sq++){
  int payload=(c&63)-1;if(payload<0||payload>=58)continue;
  int kind=payload%29;int st=kind;
  if(payload<29&&kind<20&&kind!=10&&kind!=11)st=29+kind-(kind>10)-(kind>11);
  int rank=(s==0)?sq/12:11-sq/12;
  table[s][c][sq]=((s!=(c>=64))*47+st)*72+rank*6+min(sq%12,11-sq%12);
 }
 vector<uint8_t> data(138*65536);
 for(int i=1;i<argc;i++){FILE *f=fopen(argv[i],"rb");assert(f);
 size_t n;while((n=fread(data.data(),138,65536,f))){records+=n;for(size_t j=0;j<n;j++){
 const uint8_t*r=data.data()+j*138;const uint8_t*pieces=r+21;
 const auto &t=table[r[18]];
 for(int block=0;block<3;block++){uint64_t bits=0;memcpy(&bits,r+8*block,block==2?2:8);
 while(bits){int pos=block*64+std::countr_zero(bits);cnt[t[(*pieces++)&127][pos]]++;bits&=bits-1;}}
 if(r[19]<144){int sq=r[19];cnt[94*72+(r[18]?11-sq/12:sq/12)*6+min(sq%12,11-sq%12)]++;}
 }}fclose(f);}
 fprintf(stderr,"records %lld\n",(long long)records);fwrite(cnt, sizeof(*cnt),6841,stdout);
}

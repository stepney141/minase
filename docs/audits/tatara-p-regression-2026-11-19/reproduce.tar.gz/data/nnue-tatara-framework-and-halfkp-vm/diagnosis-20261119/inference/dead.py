"""Measure per-unit Layer 2 activation on a fixed part of the shared validation sample."""
import argparse
from pathlib import Path
import numpy as np

def main():
    p=argparse.ArgumentParser()
    p.add_argument('checkpoints',nargs='+',type=Path)
    p.add_argument('--data',type=Path,default=Path(__file__).resolve().parent.parent/'training/after')
    p.add_argument('--n',type=int,default=10000)
    args=p.parse_args()
    rec=np.memmap(args.data,mode='r',dtype=[('score','<i4'),('features','<u2',(2,94))])
    assert len(rec)==60000 and 0<args.n<=len(rec)
    ids=rec['features'][np.random.default_rng(1901).choice(len(rec),args.n,replace=False)].astype(np.int32)
    ids[ids==65535]=13680
    feature=np.arange(13680)
    index=feature//144*72+feature%144//12*6+np.minimum(feature%12,11-feature%12)
    right=feature%12>=6
    for fname in args.checkpoints:
        with np.load(fname) as data:
            old='weights.linear.weight' in data
            def w(k):return data['weights.'+k].astype(float)
            F=np.zeros((13681,256));F[:-1]=w('ft.embedding.weight' if old else 'ft_weights')[index]
            F[:-1][right]=np.roll(F[:-1][right],128,axis=1)
            fb=np.tile(w('head.biases' if old else 'ft_biases'),2)
            if old:
                W1=w('head.hidden1_weights').reshape(15,128);b1=w('head.hidden1_biases')
                W2=w('head.hidden2_weights');b2=w('head.hidden2_biases')
            else:
                W1=(w('l1_weights')+w('l1_shared_weights'))[:15];b1=(w('l1_biases')+w('l1_shared_biases'))[:15]
                W2=w('l2_weights');b2=w('l2_biases')
            h=[]
            for block in np.array_split(ids,(len(ids)+127)//128):
                ft=(F[block].sum(axis=2)+fb).clip(0,1)
                if old: pairs=ft[:,:,:64]*ft[:,:,64:128]+ft[:,:,128:192]*ft[:,:,192:]
                else: pairs=127/128*ft[:,:,:128]*ft[:,:,128:]
                y=pairs.reshape(len(ft),-1)@W1.T+b1
                z=np.c_[(127/128*y*y).clip(0,1),y.clip(0,1)]
                h.append(z@W2.T+b2)
            h=np.vstack(h)
            mx=h.max(axis=0);hi=b2+np.maximum(W2,0).sum(axis=1)
            rates=(h>0).sum(axis=0)
            print(fname,'step',int(data['step']),'positions',len(ids),'never_positive',np.flatnonzero(mx<=0).tolist(),'provably_nonpositive',np.flatnonzero(hi<=0).tolist(),'live_leq_0.1%',sum((rates>0)&(rates<=args.n*.001)))
            print('positive_examples',rates.tolist())
            print('max_pre_activation',np.round(mx,6).tolist())
            print('bias',np.round(b2,6).tolist())
if __name__=='__main__': main()

import hashlib
import os
import json
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent
cfg=json.loads((p.parents[1]/'train-after/config.json').read_text())
scratch=Path(os.environ['MINASE_TATARA_SPILL'])
selected=np.fromfile(p/'first-original.u64','<u8');assert len(selected)==32768
out=np.zeros((len(selected),138),dtype=np.uint8);h=hashlib.sha256();start=offset=0
for i in range(37):
 train=np.memmap(scratch/f'train-{i}.bin',mode='r',dtype='u1').reshape(-1,138)
 val=(scratch/f'validation-{i}.bin').stat().st_size//138
 for block in np.array_split(train,64):
  file=np.ascontiguousarray(block[:,126:130]).view('<u4').ravel();assert np.all(file==i)
  ids=np.ascontiguousarray(block[:,130:138]).view('<u8').ravel();assert np.all(np.diff(ids)>0);h.update((ids+start).astype('<u8').tobytes())
 m=(selected>=offset)&(selected<offset+len(train))
 out[m]=train[selected[m]-offset]
 offset+=len(train);start+=len(train)+val
assert offset==96462343 and h.hexdigest()==cfg['preprocessing']['training_indices_sha256']
out.tofile(p/'first-original.sample')
print(h.hexdigest(),hashlib.sha256(out.tobytes()).hexdigest())

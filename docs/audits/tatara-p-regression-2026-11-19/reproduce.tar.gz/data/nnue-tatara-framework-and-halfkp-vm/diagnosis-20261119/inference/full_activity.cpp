#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <fstream>
#include <vector>

struct Model {
    std::vector<float> ft;
    float bias[256];
    std::vector<float> linear, w1, b1, w2, b2, w3, b3, direct;
    bool old; uint64_t positive[32]={}; float maxima[32]={};
    Model(const char *path, bool is_old) : old(is_old) {
        std::ifstream in(path,std::ios::binary);
        auto get=[&](size_t n) { std::vector<float> v(n);in.read(reinterpret_cast<char*>(v.data()),n*4); if(!in)std::abort();return v; };
        ft=get(13680*256); auto b=get(256);std::copy(b.begin(),b.end(),bias);
        linear=get(13680*(old?2:1)); w1=get(old?15*128:16*256);b1=get(old?15:16);
        w2=get(32*30); b2=get(32);w3=get(32);b3=get(1);
        if(old)direct=get(128);
    }
    float evaluate(const uint16_t (&ids)[2][94]){
        float aa[2][256], pp[256], y[16], z[30], h[32], lin[2]={};
        int count=0;
        for(int v=0;v<2;++v) {
            std::copy_n(bias,256,aa[v]);
            for(auto id:ids[v]){
                if(id==65535)break; if(id>=13680)std::abort();
                if(old){ if(!v){lin[0]+=linear[id*2];lin[1]+=linear[id*2+1];} }
                else lin[v]+=linear[id];
                if(!v && id<13536)++count;
                auto row=ft.data()+id*256; for(int j=0;j<256;++j)aa[v][j]+=row[j];
            }
            for(float &x:aa[v])x=std::clamp(x,0.f,1.f);
            if(old)for(int j=0;j<64;++j)pp[v*64+j]=aa[v][j]*aa[v][j+64]+aa[v][j+128]*aa[v][j+192];
            else for(int j=0;j<128;++j)pp[v*128+j]=aa[v][j]*aa[v][j+128]*(127.f/128.f);
        }
        for(int i=0;i<(old?15:16);++i){
            const int n=old?128:256;float sum=0;for(int j=0;j<n;++j)sum+=w1[i*n+j]*pp[j]; y[i]=sum+b1[i];
        }
        for(int i=0;i<15;++i){z[i]=std::clamp(y[i]*y[i]*(127.f/128.f),0.f,1.f);z[15+i]=std::clamp(y[i],0.f,1.f);}
        for(int i=0;i<32;++i){float sum=0;for(int j=0;j<30;++j)sum+=w2[i*30+j]*z[j]; h[i]=std::clamp(sum+b2[i],0.f,1.f); positive[i]+=(h[i]>0); maxima[i]=std::max(maxima[i],sum+b2[i]);}
        float output=b3[0];for(int i=0;i<32;++i)output+=h[i]*w3[i];
        if(old){for(int j=0;j<128;++j)output+=pp[j]*direct[j];float phi=std::clamp((count-2)/90.f,0.f,1.f);return output*679.029296875f+lin[0]*phi+lin[1]*(1-phi);}
        return (output+y[15]+(lin[0]-lin[1])/2)*(8128.f/12.f);
    }
};

#include <bit>
#include <cstring>
#include <cassert>
int main(int argc,char**argv){Model old(argv[1],true),nw(argv[2],false);
int map[2][128][144];uint64_t total=0;
for(int s=0;s<2;s++)for(int c=0;c<128;c++)for(int sq=0;sq<144;sq++){
 int payload=(c&63)-1;if(payload<0||payload>=58)continue;
 int kind=payload%29;int st=kind;if(payload<29&&kind<20&&kind!=10&&kind!=11)st=29+kind-(kind>10)-(kind>11);
 map[s][c][sq]=((s!=(c>=64))*47+st)*144+(s?11-sq/12:sq/12)*12+sq%12;
}
std::vector<uint8_t> data(138*16384);
for(int i=3;i<argc;i++){FILE *f=fopen(argv[i],"rb");assert(f);size_t n;
while((n=fread(data.data(),138,16384,f))){total+=n;for(size_t j=0;j<n;j++){
 uint16_t ids[2][94];
 const uint8_t *r=data.data()+138*j,*v=r+21; int k=0;
 for(int block=0;block<3;block++){uint64_t bits=0;memcpy(&bits,r+8*block,block==2?2:8);
 while(bits){int pos=block*64+std::countr_zero(bits),c=(*v++)&127; for(int side=0;side<2;side++)ids[side][k]=map[r[18]^side][c][pos];++k;bits&=bits-1;}}
 if(r[19]<144){for(int s=0;s<2;s++)ids[s][k]=13536+((r[18]^s)?11-r[19]/12:r[19]/12)*12+r[19]%12;++k;}
 assert(k<94);ids[0][k]=ids[1][k]=65535;old.evaluate(ids);nw.evaluate(ids);
}}fclose(f);}
printf("positions %lld\n",(long long)total);
for(auto m:{&old,&nw}){printf("%s",m==&old?"old":"new");for(int i=0;i<32;i++)printf(" %llu",(long long)m->positive[i]);puts("");}
}

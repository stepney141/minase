use std::{io::{self,Write},fs};
use minase_core::{Position,MoveRules,MoveGenerator,notation::usi};
use minase::eval::{features::active_features_for,nnue::LayerStackNetwork};
fn main(){
 let args:Vec<_>=std::env::args().collect();
 let net=LayerStackNetwork::decode(&fs::read(&args[1]).unwrap()).unwrap();
 let mut w=io::BufWriter::new(io::stdout());
 let write_pos=|p:&Position,group,mode:i32,w:&mut io::BufWriter<io::Stdout>|{
 let mut row=[-1i32;296]; row[0]=group; row[1]=mode;row[2]=net.evaluate(p); row[3]=p.side_to_move().index() as i32;
 for (j,side) in [p.side_to_move(),p.side_to_move().opposite()].into_iter().enumerate(){
 let mut k=4+146*j;active_features_for(side,p,|x|{row[k]=x as i32;k+=1;})
 }for e in row { w.write_all(&e.to_le_bytes()).unwrap(); }
 };
 let rules=MoveRules::standard(); let genr=MoveGenerator::standard(); let mut group=0;
 for file in args.into_iter().skip(2){
 let data:serde_json::Value=serde_json::from_slice(&fs::read(file).unwrap()).unwrap();let pair=data["pair_number"].as_u64().unwrap();
 if pair>284 || data["category"].is_null(){continue;} let mut start=Position::initial();for t in data["opening"]["moves"].as_array().unwrap(){let m=usi::parse(&start,t.as_str().unwrap()).unwrap();start.make_move_unchecked(m,rules);}
 for (g,game) in data["games"].as_array().unwrap().iter().enumerate(){let mut p=start.clone();
 for (i,t) in game["turns"].as_array().unwrap().iter().enumerate(){
 let Some(m)=t["response"]["usi"].as_str() else{break};
 if true {
 group+=1;write_pos(&p,pair as i32,(g*10000+i) as i32,&mut w);
 if false {
 let mut moves=vec![];genr.generate_moves(&p,&mut moves);
 for m in moves{let undo=p.make_move_unchecked(m,rules);write_pos(&p,group,1,&mut w);p.unmake_move(undo);}
 }
 }
 let mv=usi::parse(&p,m).unwrap();p.make_move_unchecked(mv,rules);
 }}
 }
}

import sys,contextlib,io
from pathlib import Path
with contextlib.redirect_stdout(io.StringIO()):
 exec(open(str(Path(sys.argv[1])/'ranks.py')).read())
expit=lambda a:1/(1+np.exp(-a))
def rankdata(a):
 u,inv,counts=np.unique(a,return_inverse=True,return_counts=True);return (counts.cumsum()-(counts-1)/2)[inv]
rows=rows[r];M=M[r];N=N[r];X=rows[:,4:150];types=np.arange(47);side=X//(144*47);index=(X//144)%47
mats=np.stack([((index==k)&(side==0)).sum(axis=1)-((index==k)&(side==1)).sum(axis=1) for k in types],axis=1)
sq=X%144;coords=np.minimum(sq%12,11-sq%12)+(sq//12)*6
ci=X//144*72+coords
new=A['float'][r];old=A['oldfloat'][r];Y=new-old
print('stage	qty	material_CV_R2	material_corr	old/new spread	best disagreement')
for name,m in [('all',np.ones(len(rows),bool)),('late',N<25),('mid',(N>=25)&(N<65)),('early',N>=65)]:
 Yhat=np.zeros(np.sum(m));preds=np.zeros((m.sum(),2))
 Xmat=mats[m].astype(float);spread=np.std(Xmat,axis=0);Xmat=Xmat[:,spread>0];phase=(N[m]-45)/45
 Xmat=np.c_[Xmat,Xmat*phase[:,None]];folds=M[m,0].astype(int)%5
 for f in range(5):
  train=folds!=f;test=~train;sx=Xmat[train];sy=Y[m][train]; coef=np.linalg.solve(sx.T@sx+np.eye(sx.shape[1])*1,sx.T@sy)
  Yhat[test]=Xmat[test]@coef
  for i,a in enumerate([old[m],new[m]]):
   val=lambda s:np.mean((expit(a[train]/s)-M[m,4][train])**2)
   lo,hi=200.,4000.
   for j in range(45):
    l=(2*lo+hi)/3;h=(lo+2*hi)/3
    if val(l)<val(h): hi=h
    else: lo=l
   S=(lo+hi)/2
   preds[test,i]=expit(a[test]/S)
 print(name,m.sum(),'cv R2',round(1-((Y[m]-Yhat)**2).mean()/np.var(Y[m]),3),'material_net_MAE',round(np.mean(abs(Y[m]-Yhat))), 'old/new SD',np.round([np.std(old[m]),np.std(new[m])],1))
 for i,a in enumerate([old[m],new[m]]):
  scores=rankdata(a[M[m,4]!=0.5]);lab=M[m,4][M[m,4]!=0.5]
  AUC=(scores[lab==1].sum()-len(scores[lab==1])*(len(scores[lab==1])+1)/2)/(len(scores[lab==1])*len(scores[lab==0]))
  print(i,'cal CV',np.mean((preds[:,i]-M[m,4])**2),'AUC (decisive games)',AUC)

import numpy as np, sys
from pathlib import Path
src=np.load(sys.argv[2]); rows=np.fromfile(sys.argv[1],dtype='<i4').reshape(-1,296)
w={k[8:]:src[k].astype(np.float64) for k in src.files if k.startswith('weights.')}
ix=np.arange(13680); rights=ix%12>=6; ci=ix//144*72+ix%144//12*6+np.minimum(ix%12,11-ix%12)
F=np.zeros((13681,256)); F[:-1]=w['ft.embedding.weight'][ci];F[:-1][rights]=np.roll(F[:-1][rights],128,axis=1)
L=np.vstack((w['linear.weight'][ci],[0,0]))
out=[]
for start in range(0,len(rows),128):
 r=rows[start:start+128]; ids=r[:,4:].reshape(len(r),2,146);ids[ids<0]=13680
 a=(np.tile(w['head.biases'],2)+F[ids].sum(axis=2)).clip(0,1)
 pairs=(a[:,:,:64]*a[:,:,64:128]+a[:,:,128:192]*a[:,:,192:]).reshape(len(r),-1)
 l=L[ids[:,0]].sum(axis=1); phi=(((ids[:,0]<13536).sum(axis=1)-2)/90).clip(0,1)
 direct=pairs@w['head.output_weights'].reshape(-1)+w['head.output_bias']
 y=pairs@w['head.hidden1_weights'].reshape(15,-1).T+w['head.hidden1_biases']
 z=np.concatenate([(127/128*y*y).clip(0,1),y.clip(0,1)],axis=1)
 u=(z@w['head.hidden2_weights'].T+w['head.hidden2_biases']).clip(0,1)
 out.extend((u@w['head.hidden2_output']+direct)*float(src['cp_per_logit'])+l[:,0]*phi+l[:,1]*(1-phi))
np.save(sys.argv[3],out)

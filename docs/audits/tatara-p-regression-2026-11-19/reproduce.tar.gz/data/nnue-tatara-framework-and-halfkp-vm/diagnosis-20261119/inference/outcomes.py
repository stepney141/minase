import sys, contextlib,io
with contextlib.redirect_stdout(io.StringIO()):
 exec(open(str(__import__('pathlib').Path(sys.argv[1])/'ranks.py')).read())
V=np.load(P/'components.npy')
ol,od,nl,nd,ot_l,ot_d,nt_l,nt_d=V.T
o=ol+od; n=nl+nd; ot=ot_l+ot_d;nt=nt_l+nt_d
assert np.max(abs(A['float']-n))<1e-5 and np.max(abs(A['oldfloat']-o))<1e-5
r &= np.isfinite(M[:,4]);eps=1e-7;bin=679.029296875
def pr(x):return 1/(1+np.exp(-x/bin))
def compare(v1,v2,m):
 d=((pr(v1)-M[:,4])**2-(pr(v2)-M[:,4])**2)[m]
 gp=M[m,0].astype(int); u=np.unique(gp)
 count=np.bincount(gp)[u]; sums=np.bincount(gp,weights=d)[u]
 b=np.random.default_rng(5294).integers(len(u),size=(5000,len(u)));ci=np.quantile(sums[b].sum(axis=1)/count[b].sum(axis=1),[.025,.975])
 return round(d.mean(),6),ci, len(u)
for name,mask in [('all',r),('late',r&(N<25)),('mid',r&(N>=25)&(N<65)),('early',r&(N>=65))]:
 print(name,mask.sum(),'MAE_lin nonlinear total',*(round(abs(v[mask]).mean(),2) for v in [nl-ol,nd-od,n-o]),'corr',round(np.corrcoef((nl-ol)[mask],(nd-od)[mask])[0,1],3))
 print('symmetric/antisym MAE old/new diff',round(abs(((n+nt-o-ot)/2)[mask]).mean(),2),round(abs(((n-nt-o+ot)/2)[mask]).mean(),2))
 for k,v in [('old',o),('new',n),('old anti',(o-ot)/2),('new anti',(n-nt)/2),('old linear oldNL+newPST',nl+od),('new→old symmetric',(n-nt+o+ot)/2),('new→old anti',(n+nt+o-ot)/2)]:
  print(k,'Brier',round(((pr(v[mask])-M[mask,4])**2).mean(),5))
 print('new float−old float',compare(n,o,mask),'new int−new float',compare(A['production'],n,mask))
 print('old,new STM premium med mean sd',[(round(np.median(v[mask]),1),round(v[mask].mean(),1),round(v[mask].std(),1))for v in [(o+ot)/2,(n+nt)/2]])

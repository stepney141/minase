import sys,contextlib,io
from pathlib import Path
with contextlib.redirect_stdout(io.StringIO()):exec(open(str(Path(sys.argv[1])/'ranks.py')).read())
net=Path(sys.argv[3]);wo=np.load(net/'train-before/latest.npz')['weights.linear.weight'];wp=np.load(net/'train-after/latest.npz')['weights.psqt']
ix=np.arange(13680);ci=ix//144*72+ix%144//12*6+np.minimum(ix%12,11-ix%12)
L=np.vstack((np.rint(wo.astype(float)*8)[ci],[0,0])); Q=np.r_[(np.sign(wp)*np.floor(np.abs(wp.astype(float))*8128+.5))[ci],0];L[13536:]=0;Q[13536:]=0
data=[]
for g in groups:
 parent=g[0]-1;assert rows[parent,1]==0
 g=g[N[g]==N[parent]]
 if len(g)<2:continue
 s=rows[g,150:];t=rows[g,4:150]; q=min(90,max(0,N[parent]-2));end=L[s].sum(axis=1);old=end[:,0]*q+end[:,1]*(90-q);new=(Q[s].sum(axis=1)-Q[t].sum(axis=1))
 data.append((g,old,new))
print('parents',len(data),'quiets',sum(len(g) for g,*_ in data))
for target in ['newkey','oldfloat','float','production','oldinteger']:
 for k in ['oldkey','newkey']:
  tie=flip=total=0; top=[]; loss=[]
  for g,old,new in data:
   a=old if k=='oldkey' else new;b=new if target=='newkey' else -A[target][g]
   ad=a[:,None]-a;bd=b[:,None]-b; m=bd>0.1; flip+=np.sum(m&(ad<0));tie+=np.sum(m&(ad==0));total+=m.sum();top.append(b[np.argmax(a)]>=max(b)-.001);loss.append(max(b)-b[np.argmax(a)])
  print(k,target,'strict disagreement',round(flip/total,4),'ties',round(tie/total,4),'top match',round(np.mean(top),4),'regret',round(np.mean(loss),1))

import numpy as np,sys,glob,json
from pathlib import Path
P=Path(sys.argv[1])
rows=np.fromfile(P/'features.bin',dtype='<i4').reshape(-1,296); before=np.fromfile(P/'old.bin',dtype='<i4').reshape(-1,296); cal=np.fromfile(P/'cal.bin',dtype='<i4').reshape(-1,296)
for a in [before,cal]:
 assert np.array_equal(rows[:,:2],a[:,:2]) and np.array_equal(rows[:,3:],a[:,3:])
A=dict(np.load(P/'ablate.npz'));A.update(oldfloat=np.load(P/'oldfloat.npy'),oldinteger=before[:,2],cal=cal[:,2])
meta=[None]
for file in sorted(glob.glob(sys.argv[2])):
 data=json.load(open(file)); pair=data['pair_number']
 for g,game in enumerate(data['games']):
  for i,t in enumerate(game['turns']):
   if t['response'].get('usi') is None:break
   if (i+g+pair)%11:continue
   sc=(t.get('evaluation') or {}).get('score') or {}
   winner=game['termination'].get('winner')
   y=0.5 if not winner else float(winner==t['side'])
   meta.append((pair,i,g,data['category'] is not None and pair<=284,y,sc.get('value') if sc.get('kind')=='cp' else np.nan,game['candidate_color']==t['side']))
M=np.array([meta[k] for k in rows[:,0]]);assert np.max(rows[:,0])+1==len(meta)
N=((rows[:,4:150]>=0)&(rows[:,4:150]<13536)).sum(axis=1); r=(M[:,3]==1)&(rows[:,1]==0);c=(M[:,3]==1)&(rows[:,1]==1)
groups=np.split(np.flatnonzero(c),np.flatnonzero(np.diff(rows[c,0]))+1)
print('valid positions',sum(r),'children',sum(c),'groups',len(groups))
print('mean mae std p99')
def stats(v):return ' '.join(f'{x:.3f}' for x in [v.mean(),np.mean(abs(v)),v.std(),np.quantile(abs(v),.99)])
for base,vs in [('float',list(A.keys())),('oldfloat',['oldinteger'])]:
 for k in vs:
  if k.startswith('omit_') or k in ('nearestall',):continue
  print(k,stats((A[k]-A[base])[r]))
print('compare variant fracchanged meanregret strictflip minregret>10')
for base,vs in [('float',['production','hihead','cal','idealafterft','skiponlyhi','oldfloat','oldinteger']),('oldfloat',['oldinteger','float','production'])]:
 for k in vs:
  loss=[]; ties=[]; flip=tot=0
  for g in groups:
   f=A[base][g];q=A[k][g];loss.append(f[np.argmin(q)]-min(f));ties.append(np.sum(q==min(q)))
   delta=f[:,None]-f; dq=q[:,None]-q;mask=(delta>0.1);tot+=mask.sum();flip+=(mask&(dq<0)).sum()
  print(base,k,round(np.mean(np.array(loss)>0.001),4),round(np.mean(loss),4),round(flip/tot,5),sum(np.array(loss)>10))
for name,mask in [('all',r),('late',r&(N<25)),('mid',r&(N>=25)&(N<65)),('early',r&(N>=65)),('short',r&(M[:,1]<40))]:
 print(name,'positions',mask.sum())
 for k in ['oldinteger','oldfloat','production','float','cal','hihead']:
  pred=1/(1+np.exp(-A[k]/679.029296875));loss=(pred-M[:,4])**2
  print(k,'outcome mse',round(loss[mask].mean(),6),'calibration',round((pred-M[:,4])[mask].mean(),4),'mate outcome distribution',round(M[mask,4].mean(),3))

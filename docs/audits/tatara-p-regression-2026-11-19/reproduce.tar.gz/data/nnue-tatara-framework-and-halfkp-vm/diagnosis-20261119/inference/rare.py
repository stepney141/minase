import sys, contextlib,io,hashlib
from pathlib import Path
with contextlib.redirect_stdout(io.StringIO()):exec(open(str(Path(sys.argv[1])/'ranks.py')).read())
P=Path(sys.argv[1]); ct=np.fromfile(P/'counts.u64','<u8');assert hashlib.sha256(ct.tobytes()).hexdigest()=='5fcfa36a0388f9e434d78f1e9670ff8da82d93022f7246dd2f7fa0f6c40dc4de'
ix=np.arange(13680);ci=ix//144*72+ix%144//12*6+np.minimum(ix%12,11-ix%12)
other=np.where(ix<13536,((1-ix//(47*144))*47+(ix//144)%47)*144,94*144)+(11-ix%144//12)*12+ix%12
both=ct[ci]+ct[ci[other]]
look=np.r_[both,np.iinfo(np.uint64).max] 
def calc(rows):
 rare=[];prom=[];hits={}
 for block in np.array_split(rows,64):
  f=block[:,4:].reshape(-1,2,146).copy();f[f<0]=13680
  rare.extend(look[f].min(axis=(1,2)))
  st=f[:,0]//144%47
  prom.extend(((f[:,0]<13536)&(st>=21)&(st<=28)).any(axis=1))
  ix,nn=np.unique(f[(f<13680)&(look[f]==0)],return_counts=True)
  for i,x in zip(ix,nn):hits[int(i)]=hits.get(int(i),0)+int(x)
 return np.array(rare),np.array(prom),hits
full=np.memmap(P/'allmoves.bin',dtype='<i4',mode='r').reshape(-1,296)
rare,promo,hits=calc(full)
print('all recorded played root positions',len(full),'contains promoted-only kind',sum(promo),'zero hits',hits)
for t in [0,10,100,1000,10000]:
 rr=rare<=t
 print('train frequency <=',t,'game positions',sum(rr),'pairs',len(set(full[rr,0])),'games',len(set(zip(full[rr,0],full[rr,1]//10000))))
rr,prom,hits=calc(rows[r])
sg=M[r]; of=A['oldfloat'][r]; nf=A['float'][r]
def pr(x):return 1/(1+np.exp(-x/679.029296875))
print('frequency classes count mean|float old-new| delta Brier')
for nam,t in [('all',np.ones(len(rr),bool)),('<=1000',rr<=1000),('>1000',rr>1000),('>10000',rr>10000),('promoted-only type',prom),('no promoted-only type',~prom)]:
 print(nam,t.sum(),round(abs(of[t]-nf[t]).mean(),2),round(((pr(nf[t])-sg[t,4])**2-(pr(of[t])-sg[t,4])**2).mean(),6))
counts=ct[:6768].reshape(2,47,72).sum(axis=(0,2))
for st in range(21,29):
 exists=(((rows[r,4:150]//144)%47)==st).any(axis=1)
 print('promotion',st,'training STMany slots',int(counts[st]),'STC samples',sum(exists),'median float abs diff',round(np.median(abs(of[exists]-nf[exists])),1))
for name,t in [('early',N[r]>=65),('mid',(N[r]>=25)&(N[r]<65)),('late',N[r]<25)]:
 idx=np.flatnonzero(t&(np.sign(of)!=np.sign(nf))&(rr>1000));idx=idx[np.argmax(abs(of[idx]-nf[idx]))]
 print('example max opposite (freq>1000)',name,'pair index game',sg[idx,:3], 'pieces',N[r][idx], 'old/new/int cp',of[idx],nf[idx],A['production'][r][idx],'minimum feat freq',rr[idx], 'outcome',sg[idx,4])

#!/usr/bin/env bash
# Run from the nnue-tatara-framework-and-halfkp-vm worktree after both release engines have been built.
set -euo pipefail
s=$(cd "$(dirname "$0")" && pwd)
d=../../nnue-tatara-framework-and-halfkp-vm
matches=../../matches/nnue-tatara-framework-and-halfkp-vm-stc/pairs
build() {
    local dep=$1 source=$2 exe=$3
    local minase=("$dep"/libminase-*.rlib) core=("$dep"/libminase_core-*.rlib) json=("$dep"/libserde_json-*.rlib)
    rustc --edition=2024 -C opt-level=2 -C target-cpu=native -L "dependency=$dep" --extern "minase=${minase[0]}" --extern "minase_core=${core[0]}" --extern "serde_json=${json[0]}" "$s/$source" -o "$s/$exe"
}
test -d "${MINASE_TATARA_SPILL:?Run via ../training/with_spill.sh}"
export OPENBLAS_NUM_THREADS=1
build target/release/deps features.rs features
build ../tatara-before-a48f03aa/target/release/deps oldfeatures.rs oldfeatures
"$s/features" "$d/train-after/nnue.bin" "$matches"/*.json > "$s/features.bin"
"$s/oldfeatures" "$d/train-before/nnue.bin" "$matches"/*.json > "$s/old.bin"
"$s/features" "$d/diagnosis-20261119/training/p-calibrated.bin" "$matches"/*.json > "$s/cal.bin"
python "$s/ablate.py" "$s/features.bin" "$d/train-after/latest.npz" "$s/ablate.npz" > "$s/output.log"
python "$s/oldfloat.py" "$s/features.bin" "$d/train-before/latest.npz" "$s/oldfloat.npy"
python "$s/components.py" "$s" "$d"
python "$s/ranks.py" "$s" "$matches/*.json" > "$s/valid.log"
python "$s/outcomes.py" "$s" "$matches/*.json" > "$s/outcomes.log"
build target/release/deps fullboard.rs fullboard
"$s/fullboard" "$d/train-after/nnue.bin" "$matches"/*.json > "$s/allmoves.bin"
c++ -std=c++20 -O3 -march=native "$s/count.cpp" -o "$s/count"
"$s/count" "$MINASE_TATARA_SPILL"/train-*.bin > "$s/counts.u64"
python "$s/rare.py" "$s" "$matches/*.json" > "$s/rare.log"
python "$s/material.py" "$s" "$matches/*.json" > "$s/material.log"
python "$s/quiet.py" "$s" "$matches/*.json" "$d" > "$s/quiet.log"
python "$s/v0.py" ../../../target/match-cache "$d" "$matches" > "$s/v0.log"
python "$s/dead.py" "$d"/train-{before,after}/latest.npz > "$s/dead-final.log"
python "$s/build_full_activity.py" "$s"
c++ -std=c++20 -O3 -ffast-math -march=native "$s/full_activity.cpp" -o "$s/full_activity"
"$s/full_activity" "$s/../training/full-before.f32" "$s/../training/full-after.f32" "$MINASE_TATARA_SPILL"/validation-*.bin > "$s/full-activity.log"
build_trainer_probe() {
    local lib=(target/release/deps/libminase_trainer-*.rlib)
    rustc --edition=2024 -C opt-level=2 -C target-cpu=native -L dependency=target/release/deps --extern "minase_trainer=${lib[0]}" "$s/$1.rs" -o "$s/$1"
}
build_trainer_probe permutation
build_trainer_probe step1
"$s/permutation" > "$s/first-original.u64"
python "$s/extract_original.py" > "$s/first-original.log"
"$s/../training/read-after" "$d/train-after/nnue.bin" "$s/first-original.sample" > "$s/first-original.features"
for arm in original positive005; do
    if [[ "$arm" = original ]]; then bias=0; else bias=0.05; fi
    mkdir -p "$s/replay-$arm"
    "$s/step1" "$s/replay-$arm" "$s/first-original.sample" "$s/first-original.features" 16384 "$bias" > "$s/replay-$arm/train.log" 2>&1
    python "$s/convert_steps.py" "$d/train-after/latest.npz" "$s/replay-$arm"
    python "$s/dead.py" "$s"/replay-"$arm"/*.npz > "$s/replay-$arm/activation.log"
done

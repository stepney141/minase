use std::{fs,io::{BufWriter,Write}};
use minase_trainer::nnue::layerstack::{Scale,Parameters,Parameter,AdamW,Features,backward};
fn main(){
 let args:Vec<_>=std::env::args().collect();let dir=&args[1];let n:usize=args[4].parse().unwrap();let bias:f32=args[5].parse().unwrap();
 let raws=fs::read(&args[2]).unwrap();let features=fs::read(&args[3]).unwrap();let s=Scale::new(679.029296875).unwrap();let mut w=Parameters::initialize(1,s);w[Parameter::L2Biases].fill(bias);let mut opt=AdamW::new(Default::default()).unwrap();
 for st in 0..=2 {
  let mut out=BufWriter::new(fs::File::create(format!("{dir}/step-{st}.raw")).unwrap());for p in Parameter::ALL{ for x in &w[p]{out.write_all(&x.to_le_bytes()).unwrap()}}drop(out); if st==2{break}
  let mut f=vec![];let mut t=vec![];
  for i in (st*n)..(st+1)*n{let feats=&features[i*380+4..(i+1)*380];let rows=std::array::from_fn(|j|feats[j*188..(j+1)*188].chunks_exact(2).map(|c|u16::from_le_bytes([c[0],c[1]]) as usize).take_while(|&v|v!=65535).collect());f.push(Features::new(rows).unwrap());
  let score=f32::from_le_bytes(raws[i*138+113..i*138+117].try_into().unwrap());t.push((1./(1.+(-f64::from(score)/s.teacher()).exp())) as f32);}
  let (loss,gr)=backward(&w,s,&f,&t).unwrap();eprintln!("{st} {loss} biasgrad {:?}",&gr[Parameter::L2Biases]);let schedule=minase_trainer::nnue::schedule::LrSchedule::Cosine{horizon_superbatches:64.,floor:0.027};let lr=schedule.multiplier(st as u64,std::num::NonZeroU64::new(6104).unwrap());opt.update(&mut w,&gr,lr).unwrap();
 }
}

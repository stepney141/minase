import sys,json,glob,random,re,subprocess,hashlib
from pathlib import Path
root=Path(sys.argv[1]);d=Path(sys.argv[2]).resolve();matches=Path(sys.argv[3]);paths=[root/'a48f03aa35cfa419353739ee001664543536dd71/minase',root/'8b853b6655f3c2acfa41677449d2bcc8509dc66c/minase'];nets=[d.parent/'nnue-generation-reset/base.bin',d/'diagnosis-20261119/inference/v0-layerstack.bin']
records=[]
for f in sorted(matches.glob('*')):
 p=json.load(open(f));k=p['pair_number']
 if k>284 or p['category'] is None:continue
 for g,game in enumerate(p['games']):
  moves=[t['response']['usi'] for t in game['turns'] if 'usi' in t['response']]
  records.append((k,g,p['opening']['moves'],moves))
rng=random.Random(76192);positions=[(0,0,0,[])]
for k,g,op,ms in rng.sample(records,128):
 i=rng.randrange(len(ms));positions.append((k,g,i,op+ms[:i]))
def extract(exe,net):
 p=subprocess.Popen([str(exe),'--protocol','usi'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1)
 def cmd(s):p.stdin.write(s+'\n');p.stdin.flush()
 def until(prefix):
  out=[]
  while True:
   l=p.stdout.readline().strip()
   if not l or l.startswith('info string error'):raise Exception((l,out))
   out.append(l)
   if l.startswith(prefix):return out
 for c in ['setoption name RuleSet value JCSA','setoption name USI_Hash value 16','setoption name EvalFile value '+str(net),'isready']:cmd(c)
 print(exe,until('readyok'))
 out=[]
 for pair,g,i,ms in positions:
  cmd('usinewgame');cmd('position startpos'+(' moves '+' '.join(ms) if ms else ''));cmd('eval');ev=until('info string evaluation')[-1].split()[3];cmd('go nodes 3000')
  ls=until('bestmove');info=[l for l in ls if l.startswith('info depth')];last=info[-1]
  strip=lambda s:re.sub(r'\b(?:time|nps) [0-9]+\s*','',s)
  out.append((int(ev),ls[-1],strip(last)))
 cmd('quit');assert p.wait()==0
 return out
a,b=[extract(*pair) for pair in zip(paths,nets)]
for i in range(3):print(['static','bestmove+ponder','full final depth line excluding time and nps'][i],sum(x[i]==y[i] for x,y in zip(a,b)),'/',len(a))
for pos,x,y in zip(positions,a,b):
 if x!=y:print('mismatch',pos[:3],x,y)

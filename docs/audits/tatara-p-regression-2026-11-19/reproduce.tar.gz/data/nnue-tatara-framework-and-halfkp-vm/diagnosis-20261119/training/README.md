# P型NNUEの量子化と検証損失の再計算

このディレクトリで各コマンドを実行する。学習で保存した実数の重みは2階層上の `train-before/latest.npz` と `train-after/latest.npz` にある。量子化済みの `nnue.bin` は対応する各ディレクトリにある。環境は x86-64 Linux、Rust 1.98.0、C++17、Python 3.14、NumPy 2.5.5を使用した。局面の段階を表す表の再学習に限りSciPy 1.17.1を使う。CPUスレッドは1本でよい。

## 保存した標本で再計算する

`./reproduce.sh` は、保存した検証標本 `sample` の60,000局面と訓練標本 `calibration.sample` の32,768局面を使う。旧型・新型のリリースビルドと同じRustで局面を復元し、両エンジンの整数出力、量子化の段別集計、訓練標本だけによる整数重みの補正を再計算する。最後に補正後のモデルの全60,000個の整数出力をエンジンの実測と照合する。元の学習器の作業用ファイルはこの再計算に不要である。

## 全37本の教師から局面を復元する

`./with_spill.sh ./run_full.sh` は、`teacher-jcsa-v3/book-0.mnsd` から `book-36.mnsd` までを番号順に本番コードの `SpillStore::create` へ渡す。学習局面数、検証局面数、各集合の通し番号のSHA-256を検査してから、復元した各ファイルの場所を環境変数 `MINASE_TATARA_SPILL` に設定する。全5,162,867検証局面の実数評価と整数評価を集計し、終了時に一時ファイルを消す。実行中に約15 GBのディスク空き容量を要する。先に `./reproduce.sh` を実行して2本の特徴抽出器と `p-calibrated.bin` を作る。

標本自体の復元には `./with_spill.sh python sample_validation.py` と `./with_spill.sh python prepare_calibration.py` を使う。SHA-256は順に `1415dd00204afe997098bdaeebb5cfac2751d6b03dfe787c455f0fdd3a31a4bc` と `8ba11edd449a1df43c301705c5b5ed59c9c399d98991c405c075092e20f0921c` である。

Rustのビルド成果物は、本体リポジトリの `data/worktrees/tatara-before-a48f03aa`、`data/worktrees/tatara-after-8389b160`、`data/worktrees/tatara-head-264b7fc4` の3つのworktreeの `target/release/deps` を使う。最初の2つは各版の `cargo build --release -p minase`、最後は `cargo build --release -p minase-trainer` で作れる。

## 局面の段階に応じた駒と升の表を検査する

`phase/` に保存した訓練標本と検証標本から `OPENBLAS_NUM_THREADS=1 python phase_fit.py` と `python phase_more_stats.py` を順に実行する。標本を初めから生成する場合には、`run_full.sh` により作った評価器を使い、`./with_spill.sh python phase_data.py` を実行する。検証集合の対局の50%を追加学習、20%を正則化係数の選択、30%を効果の評価に使う。元の訓練集合で追加学習する比較でも、正則化係数の選択と評価には同じ対局の分割を使う。

位相は盤上の駒数をNとして `2(N−2)/90−1` とした。駒種・升の表は左右鏡映を共有し、手番側と相手側の特徴の差を使う。各係数1つの基準モデルと、同じ特徴に位相を掛けた係数を追加したモデルを比べる。目的関数は元の新型の実数出力におけるシグモイドの1次近似で、元のモデルを固定して正則化つき最小二乗で係数を求める。正則化の候補は10、100、1,000、10,000、100,000、1,000,000および補正量ゼロとした。係数の選択・評価では元のシグモイド勝率で誤差を計算する。順位の診断では先手から見た教師の評価値に換算し、同一対局・16手以内の隣接標本で、教師値が異なる2局面のみを比べる。これは同一の親から出る着手どうしの順位ではない。

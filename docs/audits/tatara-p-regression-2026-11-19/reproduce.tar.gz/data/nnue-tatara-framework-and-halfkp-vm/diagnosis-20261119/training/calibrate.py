"""Calibrate a native 8-bit LayerStack export on saved training positions only."""
from pathlib import Path
import hashlib
import numpy as np

base = Path(__file__).resolve().parent
source = base.parents[1] / 'train-after'
params = np.load(source / 'latest.npz')
w = {name[8:]: params[name].astype(np.float64) for name in params.files if name.startswith('weights.')}
rows = np.arange(13681)
mirror = rows % 12 >= 6
row = rows // 144 * 72 + rows % 144 // 12 * 6 + np.minimum(rows % 12, 11 - rows % 12)
row[-1] = 6840

def nearest(x):
    return np.copysign(np.floor(np.abs(x) + .5), x)

def activations(path):
    records = np.fromfile(path, dtype=[('cp', '<i4'), ('features', '<u2', (2,94))])
    xfloat = []
    xint = []
    psqt = []
    ft = w['ft_weights'][row].copy()
    ft[mirror] = np.roll(ft[mirror], 128, axis=1)
    ft[-1] = 0
    fb = np.tile(w['ft_biases'], 2)
    fwq = nearest(ft * 127)
    fbq = nearest(fb * 127)
    for batch in np.array_split(records['features'], (len(records)+255)//256):
        ids = np.minimum(batch, 13680)
        a = np.clip(ft[ids].sum(2) + fb, 0, 1)
        aq = np.clip(fwq[ids].sum(2) + fbq, 0, 127)
        xfloat.append((a[:,:,:128] * a[:,:,128:] * 127/128).reshape(-1,256))
        xint.append(np.floor(aq[:,:,:128] * aq[:,:,128:] / 128).reshape(-1,256))
        linear = w['psqt'][row[ids]]
        continuous = (linear[:,0].sum(1) - linear[:,1].sum(1)) * 4064
        quantized = nearest(linear * 8128).sum(2)
        psqt.append(np.c_[continuous, np.trunc((quantized[:,0] - quantized[:,1])/2)])
    return np.concatenate(xfloat), np.concatenate(xint), np.concatenate(psqt), records['cp']

W1 = w['l1_weights'] + w['l1_shared_weights']
b1 = w['l1_biases'] + w['l1_shared_biases']
W2, b2, W3, b3 = [w[k] for k in ('l2_weights','l2_biases','l3_weights','l3_bias')]

def continuous(x, psqt):
    y = x@W1.T + b1
    z = np.c_[np.clip(y[:,:15]**2*127/128,0,1),np.clip(y[:,:15],0,1)]
    h = z@W2.T+b2
    raw = (np.clip(h,0,1)@W3 + b3 + y[:,15])*8128 + psqt[:,0]
    return raw, y*8128, h*8128

def integer(x, psqt, biases1, biases2, readout, bias3):
    y = x@nearest(W1*64).T + biases1
    z = np.c_[np.clip(np.floor(y[:,:15]**2/2**19),0,127), np.clip(np.floor(y[:,:15]/64),0,127)]
    h = z@nearest(W2*64).T + biases2
    active = np.c_[x, np.clip(np.floor(h/64),0,127)]
    raw = active@readout + biases1[15] + bias3 + psqt[:,1]
    return np.clip(np.trunc(raw/12), -28999, 28999), y, h, active

def export(B1,B2,R,B3):
    data = (source/'nnue.bin').read_bytes()
    def tail(b1,b2,o,b3):
        weights = nearest(W1*64).astype('i1')
        weights[15] = o[:256]
        return b''.join([b1.astype('<i4').tobytes(), weights.tobytes(), b2.astype('<i4').tobytes(),
            np.pad(nearest(W2*64).astype('i1'), ((0,0),(0,2))).tobytes(), np.array([b3],'<i4').tobytes(), o[256:].astype('i1').tobytes()])
    ordinary = tail(nearest(b1*8128),nearest(b2*8128),orig_readout,nearest(b3[0]*8128))
    assert data.endswith(ordinary)
    buf = data[:-len(ordinary)] + tail(B1,B2,R,B3)
    (base/'p-calibrated.bin').write_bytes(buf)
    print('sha256',hashlib.sha256(buf).hexdigest(), flush=True)

orig_b1, orig_b2, orig_b3 = nearest(b1*8128), nearest(b2*8128), nearest(b3[0]*8128)
source_readout = np.r_[W1[15],W3] * 64
orig_readout = nearest(source_readout)
def fit():
    fp, xp, psqt, expected = activations(base/'calibration.after')
    target, y_target, h_target = continuous(fp,psqt)
    original,y,_,_ = integer(xp, psqt, orig_b1,orig_b2,orig_readout,orig_b3)
    assert np.array_equal(original,expected)
    # Match each preactivation's training mean, in the original integer units.
    B1 = nearest(orig_b1+(y_target-y).mean(0))
    _,_,h,_ = integer(xp,psqt,B1,orig_b2,orig_readout,orig_b3)
    B2 = nearest(orig_b2+(h_target-h).mean(0))
    _,_,_,act = integer(xp,psqt,B1,B2,orig_readout,orig_b3)
    # The skip connection and final layer are linear in the readout coefficients.
    # Fit only the choice of floor/ceil, unconstrained intercept, mean squared FP error.
    delta = target - psqt[:,1] - B1[15]
    means = act.mean(0)
    centered = np.asfortranarray(act - means)
    residual = (delta-delta.mean()) - centered@orig_readout
    norm = np.einsum('ij,ij->j', centered, centered)
    R = orig_readout.copy()
    for epoch in range(32):
        changes = 0
        for j in range(len(R)):
            if norm[j] == 0: continue
            step = (centered[:,j] @ residual) / norm[j]
            candidate = np.clip(nearest(R[j]+step),max(-128,np.floor(source_readout[j])),min(127,np.ceil(source_readout[j])))
            difference = candidate - R[j]
            if difference != 0:
                R[j] = candidate
                residual -= centered[:,j]*difference
                changes += 1
        if not changes: break
    B3 = nearest(delta.mean()-means@R)
    print('coordinate sweeps',epoch+1,'changed coefficients',np.sum(R!=orig_readout),'bias changes',
          np.round(B1-orig_b1).astype(int).tolist(),np.round(B2-orig_b2).astype(int).tolist(),int(B3-orig_b3))
    export(B1,B2,R,B3)
    return B1,B2,R,B3

fitted = fit()
for label,path in [('train','calibration.after'),('validation','after')]:
    fp,xp,psqt,orig = activations(base/path)
    target,_,_ = continuous(fp,psqt)
    pred,*_ = integer(xp,psqt,*fitted)
    if label == 'validation': pred.astype('<i4').tofile(base/'calibrated-expected')
    def calc(x):
        e=x-target/12
        return np.round([e.mean(),np.abs(e).mean(),np.sqrt(np.mean(e*e)),np.quantile(np.abs(e),.99)],4).tolist()
    print(label,'old',calc(orig),'calibrated',calc(pred))

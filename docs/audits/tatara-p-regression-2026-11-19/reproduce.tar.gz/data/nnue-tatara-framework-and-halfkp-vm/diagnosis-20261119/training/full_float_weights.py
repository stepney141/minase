from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent
idx=np.arange(13680); row=idx//144*72 +idx%144//12*6+np.minimum(idx%12,11-idx%12); rot=idx%12>=6
for v in ('before','after'):
    with np.load(p.parents[1]/f'train-{v}/latest.npz') as f:
        w={k[8:]:f[k] for k in f.files if k.startswith('weights.')}
    old=v=='before'
    ft=w['ft.embedding.weight' if old else 'ft_weights'][row].copy()
    ft[rot]=np.roll(ft[rot],128,axis=1)
    bias=np.tile(w['head.biases' if old else 'ft_biases'],2)
    with (p/f'full-{v}.f32').open('wb') as out:
        def put(a):out.write(np.asarray(a,dtype='<f4').tobytes())
        put(ft);put(bias)
        if old:
            for a in [w['linear.weight'][row],w['head.hidden1_weights'],w['head.hidden1_biases'],w['head.hidden2_weights'],w['head.hidden2_biases'],w['head.hidden2_output'],w['head.output_bias'],w['head.output_weights']]:put(a)
        else:
            for a in [w['psqt'][row],w['l1_weights']+w['l1_shared_weights'],w['l1_biases']+w['l1_shared_biases'],w['l2_weights'],w['l2_biases'],w['l3_weights'],w['l3_bias']]:put(a)

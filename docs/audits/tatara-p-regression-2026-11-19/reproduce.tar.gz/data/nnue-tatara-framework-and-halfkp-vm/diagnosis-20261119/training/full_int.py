"""Aggregate paired native integer evaluations over all validation records."""
import os
from pathlib import Path
import subprocess, json
import numpy as np
p = Path(__file__).resolve().parent
base = p.parents[1]
scratch = Path(os.environ['MINASE_TATARA_SPILL'])
names=['old','new','calibrated']
nets=[base / 'train-before/nnue.bin', base / 'train-after/nnue.bin', p / 'p-calibrated.bin']
versions=['before','after','after']
scores=[]
for i in range(37):
    file = scratch / f'validation-{i}.bin'
    records = np.memmap(file, mode='r', dtype='u1').reshape(-1,138)
    raw = records[:,113:117].copy().view('<f4').ravel().astype(float)
    num = np.unpackbits(records[:,:18],axis=1).sum(1)
    game = records[:,122:126].copy().view('<u4').ravel().astype(int)
    prob = lambda x: 1/(1+np.exp(-x / 679.029296875))
    counts=np.bincount(game)
    row = {'file':i,'game': np.where(counts>0)[0].tolist(),'groups':{}}
    estimates = []
    for name,ver,net in zip(names,versions,nets):
        out=subprocess.run([p/('full-'+ver),net,file],capture_output=True,check=True)
        est=np.frombuffer(out.stdout,'<i4').astype(float);assert est.size==num.size
        estimates.append(est)
    for lo,hi in [(2,25),(26,50),(51,75),(76,92),(2,92)]:
        m=(num>=lo)&(num<=hi)
        counts=np.bincount(game,weights=m)
        idx=np.array(row['game'])
        agg=lambda v: np.bincount(game,weights=v*m)[idx].tolist()
        group={'count':counts[idx].astype(int).tolist()}
        for name,est in zip(names,estimates):
            group[name]=[agg((prob(est)-prob(raw))**2),agg(est-raw),agg(abs(est-raw))]
        row['groups'][str(lo)]=group if lo!=2 or hi!=92 else group
        if lo==2 and hi==25: row['groups']['late']=row['groups']['2']
    scores.append(row)
    print(i, sum(map(len, [row['game']])),len(raw),flush=True)
(p/'full-game-sums.json').write_text(json.dumps(scores,separators=(',',':')))
for k in ['late','26','51','76','2']:
    count=sum(sum(r['groups'][k]['count']) for r in scores)
    print(k,count,[[sum(sum(r['groups'][k][name][j]) for r in scores)/count for j in range(3)] for name in names])

import json
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent
d=json.loads((p/'full-game-sums.json').read_text());f=json.loads((p/'full-float-game-sums.json').read_text())
assert all(r['file']==s['file'] and r['game']==s['game'] for r,s in zip(d,f))
n=sum(len(r['game']) for r in d);print('full games',n)
idx=np.random.default_rng(789).integers(n,size=(1000,n),dtype=np.int32)
for k in ['late','26','51','76','2']:
 def sumvar(src, name, col):
  return np.concatenate([r['groups'][k][name][col] for r in src])
 cnt=np.concatenate([r['groups'][k]['count'] for r in d])
 totals=cnt[idx].sum(1)
 def ci(x):
  stat=x[idx].sum(1)/totals; return [round(x.sum()/cnt.sum(),3),*np.round(np.percentile(stat,[2.5,97.5]),3).tolist()]
 of,oi,nf,ni,bc=[sumvar(src, name,0)*1e6 for src,name in [(f,'old'),(d,'old'),(f,'new'),(d,'new'),(d,'calibrated')]]
 print(k,'N',cnt.sum(),'float',ci(nf-of),'quant delta',ci((ni-oi)-(nf-of)),'total',ci(ni-oi),'cal minus new',ci(bc-ni))
 print(k,'mean teacher abs error', [round(sumvar(src, name,2).sum()/cnt.sum(),3) for src,name in [(f,'old'),(d,'old'),(f,'new'),(d,'new'),(d,'calibrated')]])

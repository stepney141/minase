from pathlib import Path
import numpy as np

p=Path(__file__).resolve().parent; data=p.parents[1]
d=np.load(p/'pred.npz'); globals().update({k:d[k] for k in d.files})
a=np.fromfile(p/'after',dtype=[('cp','<i4'),('feature','<u2',(2,94))]);f=a['feature'];idx=np.arange(13681);row=idx//144*72+idx%144//12*6+np.minimum(idx%12,11-idx%12);row[-1]=6840; f=row[np.minimum(f,13680)]
w=np.load(data/'train-before'/'latest.npz')['weights.linear.weight'].astype(float);raw=w[f].sum(axis=2); phase=((count-2)/90)[:,None]
antisym=(raw[:,0]-raw[:,1])/2;tem=(raw[:,0]+raw[:,1])/2
taper=(phase[:,0]-.5)*(antisym[:,0]-antisym[:,1]);tempo=(tem* np.c_[phase[:,0],1-phase[:,0]]).sum(axis=1);mid=antisym.mean(axis=1); assert np.max(abs(mid+taper+tempo-ol))<1e-5
def sig(cp):return 1/(1+np.exp(-cp/679.029296875))
for m in [np.ones(len(nf),bool), count<=25,(count>25)&(count<=50),(count>50)&(count<=75),count>75]:
 print('std lin,difference,phase,tempo',np.round([v[m].std() for v in [ol,nl,ol-nl,taper,tempo]],3))
print('new float loss replacing whole linear, adding old taper/tempo',[( (sig(score)-sig(v))**2).mean() for v in [nf,nf+ol-nl,nf+taper,nf+tempo,nf+taper+tempo]])
rng=np.random.default_rng(871);games,inv=np.unique(game,return_inverse=True);fold=rng.integers(0,5,len(games))[inv]
for n in [2,4,5]:
 vars=[np.ones(len(nf)),(mid-nl)/100,taper/20,tempo/20,(of-nf-ol+nl)/100][:n]; X=np.stack(vars).T; res=np.empty_like(nf)
 for i in range(5):
  train=fold!=i; beta=np.zeros(n)
  for _ in range(12):
   pred=sig(nf[train]+X[train]@beta); jac=(pred*(1-pred)/679.029296875)[:,None]*X[train];beta+=np.linalg.lstsq(jac,sig(score[train])-pred,rcond=None)[0]
  res[~train]=nf[~train]+X[~train]@beta
 print(n,beta, ((sig(score)-sig(res))**2).mean())

from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent; data=p.parents[1]
a=np.fromfile(p/'after',dtype=[('cp','<i4'),('feature','<u2',(2,94))])
f=a['feature']; oldi=np.fromfile(p/'before','<i4'); newi=a['cp'].copy()
sample=np.fromfile(p/'sample',np.uint8).reshape(-1,138)
def fld(i,n,ty): return np.ascontiguousarray(sample[:,i:i+n]).view(ty).ravel()
score=fld(113,4,'<f4'); game=fld(122,4,'<u4').astype(int)+fld(126,4,'<u4').astype(int)*100000
count=(f[:,0,:]<13536).sum(-1);side=sample[:,18]
def checkpoint(v):
 w=np.load(data/('train-'+v)/'latest.npz')
 return {s[8:]:w[s].astype(np.float64) for s in w.files if s.startswith('weights.')}
idx=np.arange(13681); row=idx//144*72+idx%144//12*6+np.minimum(idx%12,11-idx%12); rot=(idx%12>=6); row[-1]=6840; rot[-1]=False
f=np.minimum(f,13680)
def accum(w,b):
 tab=w[row].copy();tab[rot]=np.roll(tab[rot],128,axis=1);tab[-1]=0
 return np.concatenate([np.sum(tab[frame],axis=2)+np.tile(b,2) for frame in np.array_split(f,250)])
def old():
 d=checkpoint('before'); ft=np.clip(accum(d['ft.embedding.weight'],d['head.biases']),0,1)
 p=ft[:,:,0:64]*ft[:,:,64:128]+ft[:,:,128:192]*ft[:,:,192:256]; p=p.reshape(len(f),128)
 y=p@d['head.hidden1_weights'].reshape(15,128).T+d['head.hidden1_biases']; z=np.concatenate([np.minimum(y*y*127/128,1),np.clip(y,0,1)],axis=1)
 h=np.clip(z@d['head.hidden2_weights'].T+d['head.hidden2_biases'],0,1)
 lin=d['linear.weight'][row[f[:,0]]].sum(axis=1); phase=(count-2)/90; lin=lin[:,0]*phase+lin[:,1]*(1-phase)
 return lin+679.029296875*(h@d['head.hidden2_output']+d['head.output_bias']+p@d['head.output_weights'].ravel()),lin
def q(x,k): return np.copysign(np.floor(np.abs(x)*k+0.5),x)/k
d=checkpoint('after')
def newprep():
 x=accum(d['ft_weights'],d['ft_biases']); c=np.clip(x,0,1)
 pp=(c[:,:,:128]*c[:,:,128:]*127/128).reshape(len(x),256)
 del c,x
 x=accum(q(d['ft_weights'],127),q(d['ft_biases'],127)); c=np.clip(np.round(x*127),0,127)
 pf=(c[:,:,:128]*c[:,:,128:]/(127*128)).reshape(len(x),256)
 pq=np.floor(pf*127)/127
 return pp,pf,pq
pp,pf,pq=newprep();of,ol=old()
lin=d['psqt'][row[f]].sum(axis=-1); lin=(lin[:,0]-lin[:,1])/2
lint=q(d['psqt'],8128)[row[f]].sum(axis=-1); lint=np.trunc((np.rint(lint[:,0]*8128)-np.rint(lint[:,1]*8128))/2)/8128
def new(p,ds=(),ac=False,ll=False,hi=False):
 ws=[d['l1_weights']+d['l1_shared_weights'],d['l2_weights'],d['l3_weights']]
 bs=[d['l1_biases']+d['l1_shared_biases'],d['l2_biases'],d['l3_bias']]
 for k in ds:
  scales=64 if not hi else [np.r_[[256]*15,4096][:,None],256,4096][k]
  ws[k]=q(ws[k],scales);bs[k]=q(bs[k],np.asarray(scales).ravel()*127)
 y=p@ws[0].T+bs[0]; z=np.concatenate([np.clip(y[:,:15]**2*127/128,0,1),np.clip(y[:,:15],0,1)],axis=1)
 if ac:z=np.floor(z*127+1e-9)/127
 h=np.clip(z@ws[1].T+bs[1],0,1)
 if ac:h=np.floor(h*127+1e-9)/127
 cp=(h@ws[2]+y[:,15]+bs[2]+(lint if ll else lin))*(8128/12)
 denom=768 if hi else 12
 return np.clip(np.trunc(np.rint(cp*denom)/denom),-28999,28999) if ll else cp
nf=new(pp); cur=new(pq,(0,1,2),True,True); print('mismatch',np.sum(cur!=newi),np.max(abs(cur-newi)))
def err(x):return np.round([x.mean(),abs(x).mean(),x.std(),np.quantile(abs(x),.99)],3)
def sig(x):return 1/(1+np.exp(-x/679.029296875))
def loss(cp):return (sig(cp)-sig(score))**2
hi=new(pq,(0,1,2),True,True,True)
print('quant old new',err(oldi-of),err(newi-nf));print('16bit',err(hi-nf))
for i in range(3): print('layer',i,err(new(pp,(i,))-nf), 'omit',err(new(pq,tuple(s for s in range(3) if s!=i),True,True)-nf))
print('ft, pair w/ ft, activ FP, psqt',err(new(pf)-nf),err(new(pq)-nf),err(new(pp,ac=True)-nf),err((lint-lin)*8128/12))
for lo,h in [(2,25),(26,50),(51,75),(76,92),(2,92)]:
 mask=(count>=lo)&(count<=h)
 print('group',lo,h,mask.sum(),'biasMAE',[(round((x[mask]-score[mask]).mean(),2),round(abs(x[mask]-score[mask]).mean(),2),round(loss(x)[mask].mean(),7)) for x in [of,oldi,nf,newi,hi]])
print('quant loss', [round(loss(x).mean(),8) for x in (of,oldi,nf,newi,hi)])
print('linear comps', [(x.mean(),x.std()) for x in (ol,lin*(8128/12),of-ol,nf-lin*(8128/12))])
np.savez(p/'pred.npz',score=score,game=game,count=count,side=side,nf=nf,of=of,ni=newi,oi=oldi,hi=hi,nl=lin*(8128/12),ol=ol)

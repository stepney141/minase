import os
from pathlib import Path
import numpy as np
import subprocess
p=Path(__file__).resolve().parent; src=p.parents[1]
out=p/'phase';out.mkdir(exist_ok=True)
scratch=Path(os.environ['MINASE_TATARA_SPILL'])
for label,seed,n in [('train',34101,131072),('validation',34102,262144)]:
    files=[scratch/f'{label}-{i}.bin' for i in range(37)]
    sizes=np.array([file.stat().st_size//138 for file in files]);idx=np.sort(np.random.default_rng(seed).choice(sizes.sum(),n,replace=False))
    with (out/f'{label}.sample').open('wb') as o:
        for file,off,size in zip(files,np.r_[0,sizes.cumsum()[:-1]],sizes):
            rec=np.memmap(file,dtype='u1',mode='r',shape=(size,138));o.write(rec[idx[(idx>=off)&(idx<off+size)]-off].tobytes())
    with (out/f'{label}.features').open('wb') as o:
        subprocess.run([p/'read-after',src/'train-after/nnue.bin',out/f'{label}.sample'],stdout=o,check=True)
    with (out/f'{label}.features').open('rb') as inp,(out/f'{label}.float').open('wb') as o:
        subprocess.run([p/'full-float',p/'full-before.f32',p/'full-after.f32'],stdin=inp,stdout=o,check=True)

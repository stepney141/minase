"""Residual response to a phase-dependent PSQT, matched against a constant PSQT."""
from pathlib import Path
from time import monotonic
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import LinearOperator, cg
from scipy.special import expit
from scipy.stats import spearmanr

p=Path(__file__).resolve().parent/'phase'
K=679.029296875
D=47*72+36
def dataset(label):
    records=np.memmap(p/f'{label}.sample',mode='r',dtype='u1').reshape(-1,138)
    scores=records[:,113:117].copy().view('<f4').ravel().astype(float)
    games=records[:,122:126].copy().view('<u4').ravel().astype(int)+100000*records[:,126:130].copy().view('<u4').ravel().astype(int)
    ply=records[:,120:122].copy().view('<u2').ravel()
    sides=records[:,18]
    old,fp=np.memmap(p/f'{label}.float',mode='r',dtype='<f4').reshape(-1,2).T.astype(float)
    features=np.memmap(p/f'{label}.features',mode='r',dtype=[('cp','<i4'),('f','<u2',(2,94))])['f']
    chunks=[]; phases=[]
    for start in range(0,len(scores),2048):
        ids=features[start:start+2048,0,:]
        phases.append((((ids<13536).sum(1)-2)/90-.5)*2)
        rr,cc=np.nonzero(ids<13680)
        a=ids[rr,cc].astype(int)
        pc=a//144;rank=a%144//12;file=a%12;file=np.minimum(file,11-file)
        enemy=(pc>=47)&(pc<94);lion=(pc==94)
        sign=np.where(enemy | (lion & (rank>=6)),-1.,1.)
        rank=np.where(enemy,11-rank,rank)
        # Each own/enemy pair related by viewpoint has one independent weight.
        col=np.where(lion,47*72+np.minimum(rank,11-rank)*6+file,(pc%47)*72+rank*6+file)
        mat=sparse.csr_matrix((sign,(rr,col)),shape=(len(ids),D));mat.eliminate_zeros();chunks.append(mat)
    return sparse.vstack(chunks),np.concatenate(phases),scores,games,ply,sides,old,fp

def fit(X,t,y,fp,l2,taper):
    # First-order least squares at the frozen new evaluation. d and target are scaled
    # so unit weight is reached around 0 cp. The ridge penalty is l2*||beta||^2.
    pred=expit(fp/K); d=4*pred*(1-pred); target=4*K*(expit(y/K)-pred)
    m=D*(1+taper)
    rhs = X.T @ (d*target)
    if taper:rhs=np.r_[rhs,X.T@(t*d*target)]
    twice=d*d; xt=X.T.tocsr()
    square=X.power(2); diag=square.T@twice
    if taper:diag=np.r_[diag,square.T@(twice*t*t)]
    def mul(v):
        z=X@v[:D]
        if taper:z+=t*(X@v[D:])
        z*=twice
        out=xt@z
        if taper:out=np.r_[out,xt@(z*t)]
        return out + l2*v
    op=LinearOperator((m,m),matvec=mul,dtype='f8');pre=LinearOperator((m,m),matvec=lambda v:v/(diag+l2),dtype='f8')
    beta,err=cg(op,rhs,M=pre,rtol=1e-6,maxiter=350)
    if err:raise ValueError(err)
    return beta

def apply(X,t,fp,w):
    pred=fp+X@w[:D]
    if len(w)>D:pred+=t*(X@w[D:])
    return pred

tr=dataset('train');va=dataset('validation');X,t,y,g,ply,side,old,fp=va; g_unique,inv=np.unique(g,return_inverse=True)
perm=np.random.default_rng(34103).permutation(len(g_unique)); parts=np.empty(len(perm),int);parts[perm]=np.arange(len(perm))%10
fitval=parts[inv]<5;tune=(parts[inv]>=5)&(parts[inv]<7);test=parts[inv]>=7
target=expit(y/K);loss=lambda a:(expit(a/K)-target)**2
Xs=X[test]; ttest=t[test];ytest=y[test];gtest=g[test]; ptest=ply[test];stest=side[test]; ftest=fp[test]
out={'old':old[test],'new':ftest,'teacher':ytest,'game':gtest,'ply':ptest,'side':stest,'phase':ttest}
print('val splits (positions,games)',[(m.sum(),len(np.unique(g[m]))) for m in (fitval,tune,test)],flush=True)
print('local full source val',len(y),loss(old).mean(),loss(fp).mean())
def solve(tr,va,tag):
 global D
 X,t,y,g,ply,side,old,fp=va
 D=X.shape[1]
 for group in ['train','heldout']:
     if group=='train': xx,tt,yy,_,_,_,_,zf=tr
     else:xx,tt,yy,zf=X[fitval],t[fitval],y[fitval],fp[fitval]
     for taper in (False,True):
         best=(np.mean((expit(fp[tune]/K)-target[tune])**2), np.inf, np.zeros(D*(1+taper)))
         for ridge in [10,100,1000,10000,100000,1000000]:
             start=monotonic()
             beta=fit(xx,tt,yy,zf,ridge,taper)
             cp=apply(X[tune],t[tune],fp[tune],beta)
             tune_mse=np.mean((expit(cp/K)-target[tune])**2)
             print(group,taper,ridge,'tune MSE',tune_mse,'seconds',round(monotonic()-start,2),flush=True)
             if ridge==10000:out[tag+group+('_phase' if taper else '_constant')+'_10000']=apply(X[test],ttest,ftest,beta)
             if tune_mse<best[0]:best=tune_mse,ridge,beta
         label=tag+group+('_phase' if taper else '_constant')
         np.save(p/(label+'.npy'),best[2])
         out[label]=apply(X[test],ttest,ftest,best[2])
         print(label,'choice',best[1],flush=True)
solve(tr,va,'')
state=np.minimum(np.arange(3420)//72,47)
collapse=sparse.coo_matrix((np.ones(3420),(np.arange(3420),state)),shape=(3420,48)).tocsr()
solve((tr[0]@collapse,*tr[1:]),(va[0]@collapse,*va[1:]),'material_')
np.savez(p/'phase-predictions.npz',**out)

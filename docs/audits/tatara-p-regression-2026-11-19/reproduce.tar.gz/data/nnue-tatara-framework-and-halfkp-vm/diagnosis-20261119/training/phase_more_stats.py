exec(open(__file__.replace('phase_more_stats.py','phase_stats.py')).read())
for k in d.files:
 if not(k.endswith('10000') or k.startswith('material_')):continue
 l=L(k)
 order=np.sign(np.diff(d[k]*orientation)[ids]); agree=(order==teacher_order)+.5*(order==0)
 print(k,round(l.mean(),9),'diff vs frozen',ci((l-L('new'))*1e6,np.ones(len(t),bool)),
       'Spearman',round(spearmanr(t,d[k]).statistic,6),'near rank',round(agree.mean(),6))
 if '_phase' in k:
    control=k.replace('_phase','_constant')
    print('direct versus constant',k,ci((l-L(control))*1e6,np.ones(len(t),bool)))

from pathlib import Path
import numpy as np
from scipy.special import expit
from scipy.stats import spearmanr
p=Path(__file__).resolve().parent/'phase'
d=np.load(p/'phase-predictions.npz');t=d['teacher'];g=d['game'];side=d['side'];ply=d['ply'];K=679.029296875
gu,inv=np.unique(g,return_inverse=True);rng=np.random.default_rng(34104);boot=rng.integers(len(gu),size=(1000,len(gu)),dtype=np.int32)
def ci(x,m):
 cnt=np.bincount(inv,weights=m);sums=np.bincount(inv,weights=x*m)
 return np.round([x[m].mean(),*np.percentile(sums[boot].sum(1)/cnt[boot].sum(1),[2.5,97.5])],4)
L=lambda k:(expit(d[k]/K)-expit(t/K))**2
# Score ranking between consecutive sampled positions within a game, converted to first player.
# Exclude teacher ties and distance >16 plies. Predicted ties receive half credit.
ids=(np.where((g[1:]==g[:-1]) & (ply[1:]>ply[:-1]) & ((ply[1:].astype(int)-ply[:-1])<=16))[0])
orientation=1-2*side.astype(int);teacher_order=np.sign(np.diff(t*orientation)[ids]);ids=ids[teacher_order!=0];teacher_order=teacher_order[teacher_order!=0]
print('test positions, games, neighboring comparisons',len(g),len(gu),len(ids))
losses={}
for key in ['old','new','train_constant','train_phase','heldout_constant','heldout_phase']:
 l=L(key);losses[key]=l
 order=np.sign(np.diff(d[key]*orientation)[ids]);agree=(order==teacher_order)+.5*(order==0)
 rho=spearmanr(d[key],t).statistic
 print(key,'mse',round(l.mean(),9),'diff vs frozen (1e-6)',ci((l-L('new'))*1e6,np.ones(len(t),bool)),'spearman',round(rho,6),'adjacent rank correct',round(agree.mean(),6))
for name in ['train','heldout']:
 print(name,'taper minus constant',ci((losses[f'{name}_phase']-losses[f'{name}_constant'])*1e6,np.ones(len(t),bool)))

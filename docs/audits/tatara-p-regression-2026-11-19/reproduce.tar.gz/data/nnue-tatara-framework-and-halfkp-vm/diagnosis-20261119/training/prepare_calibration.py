import os
from pathlib import Path
import subprocess
import numpy as np

output = Path(__file__).resolve().parent
data = output.parents[1]
scratch = Path(os.environ['MINASE_TATARA_SPILL'])
files = [scratch / f'train-{i}.bin' for i in range(37)]
sizes = np.array([file.stat().st_size // 138 for file in files])
assert sizes.sum() == 96_462_343
indices = np.sort(np.random.default_rng(1329).choice(sizes.sum(), 32_768, replace=False))
with (output / 'calibration.sample').open('wb') as out:
    for file, offset, size in zip(files, np.r_[0, sizes.cumsum()[:-1]], sizes):
        records = np.memmap(file, np.uint8, mode='r', shape=(size, 138))
        out.write(records[indices[(indices >= offset) & (indices < offset + size)] - offset].tobytes())

use minase::training::records::decode_position;
use minase::eval::features::active_features_for;
use minase_core::{Color,Square};
use std::io::{self,Write};
fn main() {
 let a:Vec<_>=std::env::args().collect();
 let netdata=std::fs::read(&a[1]).unwrap();
 #[cfg(old)] let net=minase::eval::nnue::Nnue::decode(&netdata).unwrap();
 #[cfg(not(old))] let net=minase::eval::nnue::Network::decode(&netdata).unwrap();
 let mut out=io::BufWriter::new(io::stdout().lock());
 for r in std::fs::read(&a[2]).unwrap().chunks_exact(138){
  let mut board=[0;144];
  let mut j=21;
  for i in 0..144 { if (r[i/8]>>(i%8))&1!=0 {board[i]=r[j]; j+=1;} }
  let side=if r[18]==0 {Color::Black} else {Color::White};
  let pos=decode_position(&board,side,Square::from_dense(r[19] as usize),r[20]!=0).unwrap();
  #[cfg(old)] let cp=minase::eval::nnue::evaluate(&net,&pos);
  #[cfg(not(old))] let cp=net.evaluate_for(&pos,side).unwrap();
  out.write_all(&cp.to_le_bytes()).unwrap();
  if cfg!(old){continue;}
  for s in [side,side.opposite()]{let mut f=[65535u16;94];let mut j=0; active_features_for(s,&pos,|v|{f[j]=v as u16;j+=1;}); for x in f{out.write_all(&x.to_le_bytes()).unwrap();}}
 }
}

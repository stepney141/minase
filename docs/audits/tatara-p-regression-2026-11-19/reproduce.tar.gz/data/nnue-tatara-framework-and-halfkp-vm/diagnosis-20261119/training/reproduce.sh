#!/usr/bin/env bash
set -euo pipefail
probe_dir=$(cd -- "$(dirname -- "$0")" && pwd)
data_dir=$(cd -- "$probe_dir/../.." && pwd)
minase_root=$(cd -- "$data_dir/../.." && pwd)
for version in before after; do
    case "$version" in
        before)
            dep_dir="$minase_root/data/worktrees/tatara-before-a48f03aa/target/release/deps"
            flags=(--cfg old)
            ;;
        after)
            dep_dir="$minase_root/data/worktrees/tatara-after-8389b160/target/release/deps"
            flags=()
            ;;
    esac
    minase_lib=("$dep_dir"/libminase-*.rlib)
    core_lib=("$dep_dir"/libminase_core-*.rlib)
    [[ ${#minase_lib[@]} == 1 && ${#core_lib[@]} == 1 ]]
    rustc --edition 2024 -C opt-level=3 -C target-cpu=native -L "dependency=$dep_dir" --extern "minase=${minase_lib[0]}" --extern "minase_core=${core_lib[0]}" "${flags[@]}" "$probe_dir/read.rs" -o "$probe_dir/read-$version"
    "$probe_dir/read-$version" "$data_dir/train-$version/nnue.bin" "$probe_dir/sample" > "$probe_dir/$version"
done
export OPENBLAS_NUM_THREADS=1
python "$probe_dir/model.py" > "$probe_dir/outputs.txt"
python "$probe_dir/stats.py" > "$probe_dir/cluster.txt"
python "$probe_dir/linear.py" > "$probe_dir/linear.txt"
"$probe_dir/read-after" "$data_dir/train-after/nnue.bin" "$probe_dir/calibration.sample" > "$probe_dir/calibration.after"
python "$probe_dir/calibrate.py" > "$probe_dir/calibrate.log"
"$probe_dir/read-after" "$probe_dir/p-calibrated.bin" "$probe_dir/sample" > "$probe_dir/calibrated-actual"
python - "$probe_dir" <<'PY'
from pathlib import Path
import sys
import numpy as np
p=Path(sys.argv[1])
actual=np.fromfile(p/'calibrated-actual',dtype=[('cp','<i4'),('features','<u2',(2,94))])['cp']
np.testing.assert_array_equal(actual,np.fromfile(p/'calibrated-expected','<i4'))
print(f'{len(actual)} calibrated integer predictions match')
PY

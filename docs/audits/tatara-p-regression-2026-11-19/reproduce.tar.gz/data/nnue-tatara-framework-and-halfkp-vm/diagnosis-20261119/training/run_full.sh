#!/usr/bin/env bash
# Run inside with_spill.sh, after running reproduce.sh.
set -euo pipefail
: "${MINASE_TATARA_SPILL:?run via with_spill.sh}"
export OPENBLAS_NUM_THREADS=1
probe_dir=$(cd -- "$(dirname -- "$0")" && pwd)
data_dir=$(cd -- "$probe_dir/../.." && pwd)
minase_root=$(cd -- "$data_dir/../.." && pwd)
for ver in before after; do
    case "$ver" in
        before) dep="$minase_root/data/worktrees/tatara-before-a48f03aa/target/release/deps"; opts=(--cfg old);;
        after) dep="$minase_root/data/worktrees/tatara-after-8389b160/target/release/deps"; opts=();;
    esac
    minase_lib=("$dep"/libminase-*.rlib)
    core_lib=("$dep"/libminase_core-*.rlib)
    [[ ${#minase_lib[@]} == 1 && ${#core_lib[@]} == 1 ]]
    rustc --edition 2024 -C opt-level=3 -C target-cpu=native -L "dependency=$dep" --extern "minase=${minase_lib[0]}" --extern "minase_core=${core_lib[0]}" "${opts[@]}" "$probe_dir/full_int.rs" -o "$probe_dir/full-$ver"
done
python "$probe_dir/full_float_weights.py"
g++ -std=c++17 -O3 -march=native "$probe_dir/full_float.cpp" -o "$probe_dir/full-float"
python "$probe_dir/full_int.py" > "$probe_dir/full-int.log"
python "$probe_dir/full_float.py" > "$probe_dir/full-float.log"
python "$probe_dir/full_stats.py" > "$probe_dir/full-stats.log"

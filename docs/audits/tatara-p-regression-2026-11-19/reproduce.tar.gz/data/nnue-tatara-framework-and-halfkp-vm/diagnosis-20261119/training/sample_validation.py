import os
from pathlib import Path
import numpy as np

output = Path(__file__).resolve().parent
base = output.parents[1]
files = [Path(os.environ['MINASE_TATARA_SPILL']) / f'validation-{i}.bin' for i in range(37)]
sizes = np.array([file.stat().st_size // 138 for file in files])
assert sizes.sum() == 5_162_867
indices = np.sort(np.random.default_rng(721).choice(sizes.sum(), 60_000, replace=False))
with (output/'sample').open('wb') as out:
    for file,offset,size in zip(files,np.r_[0,sizes.cumsum()[:-1]],sizes):
        records = np.memmap(file,np.uint8,mode='r',shape=(size,138))
        out.write(records[indices[(indices>=offset) & (indices<offset+size)]-offset].tobytes())

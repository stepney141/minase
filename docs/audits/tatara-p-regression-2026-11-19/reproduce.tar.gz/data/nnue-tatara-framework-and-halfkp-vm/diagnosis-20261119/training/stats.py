from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent
d=np.load(p/'pred.npz'); globals().update({k:d[k] for k in d.files}); game,inv=np.unique(game,return_inverse=True);print('games',len(game)); target=1/(1+np.exp(-score.astype(float)/679.029296875))
def loss(x):return (1/(1+np.exp(-x/679.029296875))-target)**2
losses=[loss(x) for x in (of,oi,nf,ni,hi)]
r=np.random.default_rng(789); idx=r.integers(len(game),size=(1000,len(game)),dtype=np.int32)
def ci(x,m):
 sums=np.bincount(inv,weights=x*m); cnt=np.bincount(inv,weights=m); stat=sums[idx].sum(1)/cnt[idx].sum(1);return tuple(np.round(np.percentile(stat,[2.5,97.5]),2))
for l,h in [(2,25),(26,50),(51,75),(76,92),(2,92)]:
 m=(l<=count)&(count<=h); print(l,h,'float/quant/high-low/total diff in micros:')
 for x in (losses[2]-losses[0],losses[3]-losses[2],losses[4]-losses[3],losses[3]-losses[1]):
  print(round(x[m].mean()*1e6,2),ci(x*1e6,m),end=';')
 print()
print('train losses from logs')
import json
for v in ['before','after','after-overflow-84b652bd']:
 rows=[json.loads(r) for r in (p.parents[1]/('train-'+v)/'training.jsonl').read_text().splitlines()]
 print(v, [(k,rows[k]['train_loss'],rows[k]['validation_loss']) for k in (8,16,32,64)])

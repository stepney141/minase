"""Validate all 37 regenerated shards against the retained sampled bytes."""
import hashlib, os, sys, time
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent
src=Path(sys.argv[1]); rebuilt=Path(sys.argv[2])
for label,seed,n,name in [('validation',721,60000,'sample'),('train',1329,32768,'calibration.sample')]:
    if len(sys.argv)>3 and name!=sys.argv[3]:continue
    sizes=np.array([(src/f'{label}-{i}.bin').stat().st_size//138 for i in range(37)])
    indices=np.sort(np.random.default_rng(seed).choice(sizes.sum(),n,replace=False)); hh=hashlib.sha256()
    for i,(start,N) in enumerate(zip(np.r_[0,sizes.cumsum()[:-1]],sizes)):
        f=rebuilt/f'{label}-{i}.bin'
        while not f.exists():time.sleep(.2)
        with f.open('rb') as fd:
            while os.fstat(fd.fileno()).st_size != N*138:time.sleep(.2)
            a=np.memmap(fd,mode='r',dtype='u1',shape=(N,138))
            hh.update(a[indices[(indices>=start)&(indices<start+N)]-start].tobytes())
    print(name,hh.hexdigest(),flush=True)
    assert hh.digest()==hashlib.file_digest((p/name).open('rb'),'sha256').digest()

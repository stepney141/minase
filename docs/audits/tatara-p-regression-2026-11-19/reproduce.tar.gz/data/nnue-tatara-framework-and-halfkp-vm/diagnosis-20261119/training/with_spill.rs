//! Rebuild the 37 production shards for one command, then let SpillStore remove them.
use minase_trainer::data::SpillStore;
use std::num::NonZeroUsize;
use std::path::PathBuf;
use std::process::{Command, ExitCode};

fn main() -> Result<ExitCode, Box<dyn std::error::Error>> {
    let mut args = std::env::args_os().skip(1);
    let books = PathBuf::from(args.next().ok_or("missing teacher directory")?);
    let scratch = PathBuf::from(args.next().ok_or("missing scratch parent")?);
    let command = args.next().ok_or("missing command")?;
    let paths: Vec<_> = (0..37).map(|i| books.join(format!("book-{i}.mnsd"))).collect();
    let store = SpillStore::create(&paths, None, NonZeroUsize::new(2).unwrap(), &scratch, 16, 262144)?;
    assert_eq!(store.training_count(), 96_462_343);
    assert_eq!(store.validation_count(), 5_162_867);
    assert_eq!(store.validation_indices_sha256(), "3c15e0b8a25efc2667546df287866fc93fd6edb51df70ba2d1a632e5a54c0e8a");
    assert_eq!(store.training_indices_sha256(), "dbab73b9ec851a429fc83337f28ef7107344bce4ab0d82f7315945663e8fcd80");
    let status = Command::new(command).args(args).env("MINASE_TATARA_SPILL",store.directory()).status()?;
    Ok(if status.success() { ExitCode::SUCCESS } else { ExitCode::FAILURE })
}

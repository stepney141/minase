#!/usr/bin/env bash
# Usage: with_spill.sh COMMAND [ARGS...]
# Replays all 37 permanent books in numeric order. Needs about 15 GB temporary disk space.
set -euo pipefail
probe_dir=$(cd -- "$(dirname -- "$0")" && pwd)
data_dir=$(cd -- "$probe_dir/../.." && pwd)
minase_root=$(cd -- "$data_dir/../.." && pwd)
dep="$minase_root/data/worktrees/tatara-head-264b7fc4/target/release/deps"
libs=("$dep"/libminase_trainer-*.rlib)
[[ ${#libs[@]} == 1 ]]
rustc --edition 2024 -C opt-level=3 -C target-cpu=native -L "dependency=$dep" --extern "minase_trainer=${libs[0]}" "$probe_dir/with_spill.rs" -o "$probe_dir/with-spill"
scratch=$(mktemp -d "$data_dir/diagnosis-20261119/spill-parent-XXXXXX")
trap 'rmdir -- "$scratch"' EXIT
nice -n 15 ionice -c 3 "$probe_dir/with-spill" "$data_dir/teacher-jcsa-v3" "$scratch" "$@"

from pathlib import Path
d=Path(__file__).resolve().parent
p=d/'bias-source/crates/minase-trainer/src/nnue/layerstack/model.rs'
s=p.read_text()
anchor='        for row in 0..94 * 72 {'
assert s.count(anchor)==1
p.write_text(s.replace(anchor,'        result[Parameter::L2Biases].fill(0.05);\n'+anchor))

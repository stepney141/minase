#!/bin/bash
# Run once in a newly extracted source bundle placed under the main repository.
set -eu
cd "$(dirname "$0")"
d=$(pwd); root=$(git rev-parse --show-toplevel)
# The investigation directory lives under the main repository's data directory.
for entry in 'source 8b853b66' 'float-source 8b853b66' 'order-source 8b853b66' 'train-source 8389b160' 'bias-source 8389b160'; do
  set -- $entry
  mkdir "$1"
  git -C "$root" archive "$2" | tar -xC "$1"
done
python build_probe.py
python build_float.py
python precise_paths.py
python games-analysis/order.py
python retrain.py
python bias_patch.py
for entry in 'source minase probe16' 'float-source minase probefloat' 'order-source minase order' 'train-source minase-trainer train' 'bias-source minase-trainer bias'; do
  set -- $entry
  (cd "$1" && cargo build --release -p "$2")
  if [[ $2 = minase ]]; then cp "$1/target/release/$2" "$3"; fi
done
python test_probes.py

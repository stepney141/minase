from pathlib import Path
import numpy as np
d=Path(__file__).resolve().parent
model=d.parent/'nnue-tatara-framework-and-halfkp-vm/train-after'
ck=np.load(model/'latest.npz')
def w(k): return ck['weights.'+k].astype('<f8')
idx=np.arange(13680)
rows=idx//144*72+idx%144//12*6+np.minimum(idx%12,11-idx%12)
ft=w('ft_weights')[rows]
ft[idx%12>=6]=np.roll(ft[idx%12>=6],128,axis=1)
# Each hidden unit has only 94 active input terms. Double-precision accumulation
# avoids dependence on incremental-update order for the f32 checkpoint values.
with open(d/'float.bin','wb') as f:
    f.write((model/'nnue.bin').read_bytes()+b'P64F')
    for v in [ft,np.tile(w('ft_biases'),2),w('psqt')[rows],w('l1_weights')+w('l1_shared_weights'),
              w('l1_biases')+w('l1_shared_biases'),w('l2_weights'),w('l2_biases'),w('l3_weights'),w('l3_bias')]:
        f.write(v.astype('<f8').tobytes())
p=d/'float-source/crates/minase/src/eval/nnue/network/layer_stack.rs'
s=p.read_text().replace('    dense: Dense,','    dense: Dense,\n    probe: Option<Box<FloatNet>>,',1).replace('            dense,','            dense,\n            probe: None,',1)
s=s.replace('    ft: FtAccumulator<P>,','    ft: FtAccumulator<P>,\n    fa: Option<Box<FloatAcc>>,',1)
s=s.replace('        let mut r = Reader::new(bytes);','''        const ORIGINAL:usize=3919422;
        if bytes.get(ORIGINAL..ORIGINAL+4)==Some(b"P64F") {
            let mut n=Self::decode(&bytes[..ORIGINAL])?;
            let mut r=Reader::new(&bytes[ORIGINAL+4..]);
            let mut read=|count:usize| ->Result<Vec<f64>,FormatError> {
                Ok(r.take(count*8,"float probe")?.chunks_exact(8)
                    .map(|b|f64::from_le_bytes(b.try_into().unwrap())).collect())
            };
            n.probe=Some(Box::new(FloatNet {ft:read(13680*256)?,b:read(256)?,ps:read(13680)?,
                w1:read(4096)?,b1:read(16)?,w2:read(960)?,b2:read(32)?,w3:read(32)?,b3:read(1)?[0]}));
            r.finish()?;
            return Ok(n);
        }
        let mut r = Reader::new(bytes);''',1)
s=s.replace('            ft: FtAccumulator::new(self.width()),','            fa:self.probe.as_ref().map(|_|Box::new(FloatAcc{a:[[0.;256];2],p:[0.;2]})),\n            ft: FtAccumulator::new(self.width()),')
s=s.replace('        let mut psqt = [0; 2];','''        if let Some(n)=&self.probe {
            let mut a=self.new_accumulator();
            let fa=a.fa.as_mut().unwrap();
            for side in Color::ALL {
                fa.a[side.index()].copy_from_slice(&n.b);
                features::active_features_for(side,position,|row|n.add(fa,side,row,1));
            }
            return a;
        }
        let mut psqt = [0; 2];''',1)
s=s.replace('            ft: self.ft.refresh(position),','            fa:None,\n            ft: self.ft.refresh(position),')
s=s.replace('        let refreshed = self','''        if let Some(n)=&self.probe {
            let a=after.fa.as_mut().unwrap();
            a.clone_from(before.fa.as_ref().unwrap());
            for side in Color::ALL {
                features::for_each_move_change(side,position_after,undo,|row,sign|n.add(a,side,row,sign));
            }
            return false;
        }
        let refreshed = self''',1)
s=s.replace('        self.ft\n            .update_after_null','''        if let Some(n)=&self.probe {
            let a=after.fa.as_mut().unwrap();
            a.clone_from(before.fa.as_ref().unwrap());
            for side in Color::ALL {
                features::for_each_null_change(side,lion_before,|row,sign|n.add(a,side,row,sign));
            }
            return;
        }
        self.ft
            .update_after_null''',1)
i=s.index('        score(\n',s.index('pub(crate) fn evaluate_accumulator('))
s=s[:i]+'''        if let Some(n)=&self.probe {
            return n.value(acc.fa.as_ref().unwrap(),side_to_move);
        }
'''+s[i:]
s=s.replace('        let dense = self.dense(&acc, side);','        let dense = if self.probe.is_some() {0} else {self.dense(&acc, side)};').replace('            value: score(i64::from(dense) + i64::from(psqt), self.fv_scale),','            value: self.evaluate_accumulator(&acc, side),')
s+='''
#[derive(Clone,Debug,PartialEq)]
struct FloatAcc { a:[[f64;256];2],p:[f64;2] }
impl Eq for FloatAcc {}
struct FloatNet { ft:Vec<f64>, b:Vec<f64>,ps:Vec<f64>,w1:Vec<f64>,b1:Vec<f64>,w2:Vec<f64>,b2:Vec<f64>,w3:Vec<f64>,b3:f64 }
impl FloatNet {
    fn add(&self,a:&mut FloatAcc,s:Color,row:usize,sign:i32) {
        let i=s.index();
        let w=&self.ft[row*256..row*256+256];
        let sign=f64::from(sign);
        for (v,w) in a.a[i].iter_mut().zip(w){*v+=sign*w;}
        a.p[i]+=sign*self.ps[row];
    }
    fn value(&self,a:&FloatAcc,s:Color)->i32 {
        const ALPHA:f64=127./128.;
        let mut x=[0.;256];
        for (p,side) in [s,s.opposite()].into_iter().enumerate(){
            let v=&a.a[side.index()];
            for j in 0..128 {x[p*128+j]=ALPHA*v[j].clamp(0.,1.)*v[j+128].clamp(0.,1.);}
        }
        fn dot(w:&[f64],x:&[f64])->f64 {
            let mut lanes=[0.;8];
            for (j,(w,x)) in w.iter().zip(x).enumerate(){lanes[j%8]+=w*x;}
            lanes.into_iter().sum()
        }
        let y:[f64;16]=std::array::from_fn(|i|self.b1[i]+dot(&self.w1[i*256..i*256+256],&x));
        let z:[f64;30]=std::array::from_fn(|i|if i<15 {(ALPHA*y[i]*y[i]).clamp(0.,1.)}else{y[i-15].clamp(0.,1.)});
        let h:[f64;32]=std::array::from_fn(|i|(self.b2[i]+dot(&self.w2[i*30..i*30+30],&z)).clamp(0.,1.));
        ((self.b3+dot(&self.w3,&h)+y[15]+0.5*(a.p[s.index()]-a.p[s.opposite().index()]))*(8128./12.)).clamp(-28999.,28999.) as i32
    }
}
'''
p.write_text(s)

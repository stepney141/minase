from pathlib import Path
import numpy as np
d=Path(__file__).resolve().parent
model=d.parent/'nnue-tatara-framework-and-halfkp-vm/train-after'
net=(model/'nnue.bin').read_bytes()
ck=np.load(model/'latest.npz')
def weights(k):
    return ck['weights.'+k].astype(np.float64)
def quant(x,s):
    return np.copysign(np.floor(np.abs(x)*s+.5),x).astype(np.int64)
for mode in ['precise','control']:
    data=bytearray()
    for layer in [1,2,3]:
        for bias in [False,True]:
            suffix='bias' if layer==3 and bias else 'biases' if bias else 'weights'
            a=weights(f'l{layer}_{suffix}')
            if layer==1:
                a+=weights(f'l1_shared_{suffix}')
            s=np.full_like(a,4096 if layer==3 else 256)
            if layer==1: s[-1]=4096
            if bias:s*=127
            current=8128 if bias else 64
            v=quant(a,s) if mode=='precise' else quant(a,current)*(s.astype(np.int64)//current)
            dtype=np.dtype('<i4' if bias else '<i2')
            assert v.max()<=np.iinfo(dtype).max and v.min()>=np.iinfo(dtype).min
            data+=v.astype(dtype).tobytes()
    (d/(mode+'.bin')).write_bytes(net+b'P16D'+data)
p=d/'source/crates/minase/src/eval/nnue/network/layer_stack.rs'
s=p.read_text().replace('    dense: Dense,','    precise: Option<Box<ProbeHead>>,\n    dense: Dense,',1).replace('            dense,','            precise: None,\n            dense,',1)
s=s.replace('        let mut r = Reader::new(bytes);','''        const ORIGINAL: usize = 3919422;
        if bytes.len() > ORIGINAL && bytes.get(ORIGINAL..ORIGINAL+4) == Some(b"P16D") {
            let mut net = Self::decode(&bytes[..ORIGINAL])?;
            let mut reader = Reader::new(&bytes[ORIGINAL+4..]);
            net.precise = Some(Box::new(ProbeHead::read(&mut reader)?));
            reader.finish()?;
            assert_eq!(net.width(),256);
            return Ok(net);
        }
        let mut r = Reader::new(bytes);''',1)
start=s.index('        score(\n',s.index('pub(crate) fn evaluate_accumulator('))
s=s[:start]+'''        if let Some(head) = &self.precise {
            let psqt = psqt_half(acc.psqt[side_to_move.index()], acc.psqt[side_to_move.opposite().index()]);
            return score(head.output(acc, side_to_move) + 64*i64::from(psqt), self.fv_scale*64);
        }
'''+s[start:]
s=s.replace('            value: score(i64::from(dense) + i64::from(psqt), self.fv_scale),','            value: self.evaluate_accumulator(&acc, side),')
s+='''
struct ProbeHead {
    w1: Vec<i16>, b1: Vec<i32>, w2: Vec<i16>, b2: Vec<i32>, w3: Vec<i16>, b3: i32,
}
impl ProbeHead {
    fn read(reader: &mut Reader<'_>) -> Result<Self, FormatError> {
        fn weights(reader: &mut Reader<'_>, n: usize) -> Result<Vec<i16>, FormatError> {
            let bytes=reader.take(n*2,"probe weights")?;
            Ok(bytes.chunks_exact(2).map(|w|i16::from_le_bytes([w[0],w[1]])).collect())
        }
        Ok(Self { w1: weights(reader,4096)?, b1: reader.i32s(16,"probe b1")?,
                  w2: weights(reader,960)?, b2: reader.i32s(32,"probe b2")?,
                  w3: weights(reader,32)?, b3: reader.i32s(1,"probe b3")?[0] })
    }
    fn output(&self, a:&LayerStackAccumulator, side:Color) -> i64 {
        let mut x=[0i16;256];
        for (i,s) in [side,side.opposite()].into_iter().enumerate() {
            let row=a.ft.row(s).unwrap();
            for j in 0..128 {x[i*128+j]=i16::from(pair(row[j],row[128+j]));}
        }
        fn dot(w:&[i16],x:&[i16])->i32 {
            w.iter().zip(x).map(|(&a,&b)|i32::from(a)*i32::from(b)).sum()
        }
        let mut z=[0i16;30];
        for i in 0..15 {
            let y=self.b1[i]+dot(&self.w1[i*256..(i+1)*256],&x);
            z[i]=((i64::from(y)*i64::from(y))>>23).clamp(0,127) as i16;
            z[i+15]=(y>>8).clamp(0,127) as i16;
        }
        let skip=self.b1[15]+dot(&self.w1[15*256..],&x);
        let h:[i16;32]=std::array::from_fn(|i|
            ((self.b2[i]+dot(&self.w2[i*30..i*30+30],&z))>>8).clamp(0,127) as i16);
        i64::from(skip)+i64::from(self.b3)+i64::from(dot(&self.w3,&h))
    }
}
'''
p.write_text(s)

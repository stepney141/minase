from pathlib import Path
import struct,numpy as np
d=Path(__file__).resolve().parent
for name,files,version in [('master',sorted((d.parent/'nnue-lr-schedule-gen').glob('generated-*.bin')),2),('gen2',[d.parent/f'nnue-tatara-framework-and-halfkp-vm/teacher-jcsa-v3/book-{i}.mnsd' for i in range(37)],3)]:
    assert len(files)==(30 if name=='master' else 37)
    out=d/('corpus-'+name);out.mkdir(exist_ok=True)
    rng=np.random.default_rng(1919)
    total_games=total_entries=0
    for i,src in enumerate(files):
        b=src.read_bytes()
        assert b[:8]==b'MNSD'+struct.pack('<I',version)
        ng,ne=struct.unpack_from('<QQ',b,136)
        keep=set(rng.choice(ng,7500//len(files)+int(i<7500%len(files)),replace=False))
        buf=bytearray(b[:152]);buf[4]=3; pos=152;entries=0
        for j in range(ng):
            n=struct.unpack_from('<I',b,pos+10)[0]
            end=pos+161+n*7
            # These self-play records contain the played move and no candidate lists.
            arr=np.frombuffer(b,dtype='u1',offset=pos+161,count=n*7).reshape(n,7)
            assert not arr[:,5:].any()
            if j in keep:
                game=bytearray(b[pos:end])
                if version==2:
                    a=np.frombuffer(game,dtype='u1',offset=161).reshape(n,7)[:,4]
                    assert not (a>=16).any()
                    a[:]=(a&3)|((a&12)<<1)
                buf.extend(game);entries+=n
            pos=end
        assert pos==len(b)
        struct.pack_into('<QQ',buf,136,len(keep),entries)
        (out/f'book-{i:02d}.mnsd').write_bytes(buf)
        total_games+=len(keep);total_entries+=entries
    print(name,len(files),total_games,total_entries,flush=True)

#!/bin/bash
set -eu
cd "$(dirname "$0")"
d=$(pwd)
for k in 1 2; do
  for tag in gen2 master; do
    ../worktrees/tatara-after-8389b160/target/release/minase-trainer nnue train layerstack --data "$d/corpus-$tag"/book-*.mnsd --output-dir "$d/fit-corpus-$tag-$k" --rules JCSA --teacher-cp-per-logit 679.029296875 --lambda 1 --batch 4096 --batches-per-superbatch 256 --superbatches 16 --lr-schedule cosine:16:0.027 --validation-superbatches 4 --seed "$k" --device cuda --threads 1 >"$d/fit-corpus-$tag-$k.log" 2>&1
  done
done

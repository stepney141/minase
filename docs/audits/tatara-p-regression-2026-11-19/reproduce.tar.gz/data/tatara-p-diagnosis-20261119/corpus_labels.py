from pathlib import Path
import sys,subprocess
import numpy as np

d=Path(__file__).resolve().parent
tag,work=sys.argv[1],Path(sys.argv[2])
full=d.parent/'nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training/full-after'
sig=lambda x:1/(1+np.exp(-x))
def fields(part):
    out=[]
    for f in sorted(work.glob(part+'-*.bin')):
        a=np.memmap(f,'u1',mode='r').reshape(-1,138)
        cp=a[:,113:117].copy().view('<f4').ravel()
        outcome=a[:,119]/2
        pieces=np.unpackbits(a[:,:18],axis=1).sum(axis=1)
        assert len(cp)==len(outcome) and np.max(pieces)<=92
        out.append((cp,outcome,pieces))
    return tuple(np.concatenate(v) for v in zip(*out))
train,y,n=fields('train')
cp=train.astype(int); assert np.array_equal(cp,train); offset=cp.min()
bins=np.arange(int(cp.max()-offset)+1)+offset
counts=np.bincount(cp-offset);wins=np.bincount(cp-offset,weights=y)
score=lambda k:np.dot(bins,counts*sig(bins/k)-wins)
lo,hi=50.,5000.
assert score(lo)>0 and score(hi)<0
for _ in range(50):
    k=(lo+hi)/2
    if score(k)>0: lo=k
    else: hi=k
K=(hi+lo)/2
v,y,n=fields('validation')
print(tag,'train/validation',len(train),len(v),'training logistic MLE CpPerLogit',K,'validation Brier K679 / fitted',*[np.mean((sig(v/k)-y)**2) for k in (679.029296875,K)])
for a,b in [(2,25),(26,50),(51,75),(76,92)]:
 m=(n>=a)&(n<=b);print('piece stratum',a,b,'fraction',m.mean(),'median abs cp',np.median(np.abs(v[m])),'Brier K679',np.mean((sig(v[m]/679.029296875)-y[m])**2))
files=sorted(work.glob('validation-*.bin'));raw=b''.join(f.read_bytes() for f in files);rec=np.frombuffer(raw,'u1').reshape(-1,138)
i=np.random.default_rng(135319).choice(len(rec),60000,replace=False);sample=d/f'corpus-{tag}.sample';sample.write_bytes(rec[i].tobytes())
for s in (1,2):
 for name in ('master','gen2'):
    scores=np.frombuffer(subprocess.check_output([full,d/f'fit-corpus-{name}-{s}/nnue.bin',sample]),'<i4')
    pred=sig(scores/679.029296875); print('sample',tag,name,s,'teacher MSE',np.mean((pred-sig(v[i]/679.029296875))**2),'outcome Brier',np.mean((pred-y[i])**2))

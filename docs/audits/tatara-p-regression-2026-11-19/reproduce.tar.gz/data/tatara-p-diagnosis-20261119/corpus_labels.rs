use minase_trainer::data::SpillStore;
use std::{fs,num::NonZeroUsize,path::PathBuf,process::Command};
fn main()->Result<(),Box<dyn std::error::Error>>{
    let dir=PathBuf::from(std::env::current_dir()?);
    let scratch=dir.join("corpus-labels-tmp");
    fs::create_dir_all(&scratch)?;
    for source in ["master","gen2"] {
        let mut books=fs::read_dir(dir.join(format!("corpus-{source}")))?.map(|e|e.map(|e|e.path())).collect::<Result<Vec<_>,_>>()?;
        books.sort();
        let db=SpillStore::create(&books,None,NonZeroUsize::new(2).unwrap(),&scratch,16,262144)?;
        assert!(Command::new("python").args(["corpus_labels.py",source]).arg(db.directory()).status()?.success());
    }
    fs::remove_dir(&scratch)?;
    Ok(())
}

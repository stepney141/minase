from pathlib import Path
import numpy as np,subprocess
d=Path(__file__).resolve().parent
full=d.parent/'nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training/full-after'
sig=lambda x:1/(1+np.exp(-x/679.029296875))
for k in ('master','gen2'):
 sample=d/f'corpus-{k}.sample';rec=np.fromfile(sample,'u1').reshape(-1,138)
 game=np.ascontiguousarray(rec[:,122:126]).view('<u4').ravel()+100000*np.ascontiguousarray(rec[:,126:130]).view('<u4').ravel()
 _,grp,n=np.unique(game,return_inverse=True,return_counts=True)
 y=rec[:,119]/2
 for seed in (1,2):
    pred=[sig(np.frombuffer(subprocess.check_output([full,d/f'fit-corpus-{a}-{seed}/nnue.bin',sample]),'<i4')) for a in ('master','gen2')]
    delta=(pred[0]-y)**2-(pred[1]-y)**2
    grouped=np.bincount(grp,weights=delta);rng=np.random.default_rng(1192223)
    draw=rng.integers(0,len(n),(5000,len(n)))
    lo,hi=np.quantile(grouped[draw].sum(1)/n[draw].sum(1),[.025,.975])
    print(k,seed,'games',len(n),'master minus gen2 student (outcome Brier)',delta.mean(),lo,hi)

#!/bin/bash
set -eu
d=$(cd "$(dirname "$0")" && pwd)
root=$(cd "$d/../.." && pwd)
old="$root/target/match-cache/a48f03aa35cfa419353739ee001664543536dd71/minase"
new="$root/target/match-cache/8b853b6655f3c2acfa41677449d2bcc8509dc66c/minase"
td="$root/data/nnue-tatara-framework-and-halfkp-vm"
name=$1
select_side() {
  case "$1" in
    old) engine="$old"; net="$td/train-before/nnue.bin";;
    new) engine="$new"; net="$td/train-after/nnue.bin";;
    calibrated) engine="$new"; net="$td/diagnosis-20261119/training/p-calibrated.bin";;
    precise|control) engine="$d/probe16"; net="$d/$1.bin";;
    float) engine="$d/probefloat"; net="$d/float.bin";;
    *) return 1;;
  esac
}
select_side "$2"; c="$engine"; cn="$net"
select_side "$3"; b="$engine"; bn="$net"
nice -n 12 "$new" match run --candidate "$c --protocol usi" --baseline "$b --protocol usi" --candidate-option "EvalFile=$cn" --baseline-option "EvalFile=$bn" --candidate-hash 256 --baseline-hash 256 --rules JCSA --seed "$7" --concurrency "$6" --each "$4" --run-dir "$d/$name" elo --pairs "$5" >"$d/$name.log" 2>&1

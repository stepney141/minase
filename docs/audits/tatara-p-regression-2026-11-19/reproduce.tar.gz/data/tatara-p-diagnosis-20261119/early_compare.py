from pathlib import Path
import numpy as np,json
d=Path(__file__).resolve().parent
rows=[]
for p in sorted((d/'early-old-vs-early-new/pairs').glob('*.json')):
    f=json.loads(p.read_text());g=json.loads((d/'final-old-vs-new/pairs'/p.name).read_text())
    assert f['pair_seed']==g['pair_seed'] and f['opening']==g['opening']
    if None not in (f['category'],g['category']):rows.append([f['category']/4,g['category']/4])
vals=np.asarray(rows);dif=vals[:,1]-vals[:,0];rng=np.random.default_rng(719321)
print('old score rate at sb2 and sb64:',len(vals),vals.mean(axis=0),'change:',dif.mean(),np.quantile(dif[rng.integers(0,len(vals),(20000,len(vals)))].mean(1),[.025,.975]))

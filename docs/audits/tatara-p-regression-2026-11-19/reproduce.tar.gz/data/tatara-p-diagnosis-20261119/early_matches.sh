#!/bin/bash
set -eu
cd "$(dirname "$0")"
wait_for() {
  while ! test -f "$1"; do sleep 15; done
}
# Let the next trainer reserve its dataset before starting a concurrent match.
wait_for early-new/config.json
bash duel.sh early-old-vs-old early-old old nodes=3000 200 3 20261119500000
wait_for early-bias/config.json
bash duel.sh early-new-vs-new early-new new nodes=3000 200 3 20261119500000
bash duel.sh early-old-vs-early-new early-old early-new nodes=3000 200 3 20261119500000
wait_for fit-full-shared/config.json
bash duel.sh early-bias-vs-early-new early-bias early-new nodes=3000 200 3 20261119500000

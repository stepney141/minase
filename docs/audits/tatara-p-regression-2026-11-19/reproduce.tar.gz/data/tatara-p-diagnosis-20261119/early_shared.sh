#!/bin/bash
set -eu
d=$(cd "$(dirname "$0")" && pwd)
td="$d/../nnue-tatara-framework-and-halfkp-vm"
while ! test -f "$d/early-bias/summary.json"; do sleep 20; done
while [[ $(awk '/^MemAvailable:/ {print $2}' /proc/meminfo) -lt 16000000 ]]; do sleep 20; done
for i in $(seq 0 36); do books+=("$td/teacher-jcsa-v3/book-$i.mnsd"); done
systemd-run --user --scope -p MemoryMax=18G -p MemorySwapMax=0 -- env P_PROBE=shared nice -n 15 "$d/train-source/target/release/minase-trainer" nnue train layerstack --rules JCSA --teacher-cp-per-logit 679.029296875 --data "${books[@]}" --output-dir "$d/fit-full-shared" --lambda 1 --batch 16384 --superbatches 2 --lr-schedule cosine:64:0.027 --validation-superbatches 1 --seed 1 --device cuda --threads 2 >"$d/fit-full-shared.log" 2>&1
bash "$d/duel.sh" full-shared-vs-early-new fit-full-shared early-new nodes=3000 200 5 20261119500000

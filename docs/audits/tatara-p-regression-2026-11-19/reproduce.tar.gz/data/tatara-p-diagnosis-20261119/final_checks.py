from pathlib import Path
import json,math
import numpy as np
d=Path(__file__).resolve().parent
def pairs(k):return sorted((d/k/'pairs').glob('*.json'))
t=[]
for k in ('old-3000','old-new-repeat','final-old-vs-new'):
 t.extend(a/4 for f in pairs(k) if (a:=json.loads(f.read_text())['category']) is not None)
v=np.asarray(t);p=v.mean();e=1.96*v.std()/np.sqrt(len(v));elo=lambda q:400*np.log10(q/(1-q))
print('final old vs new',len(t),p,elo(p),elo(p-e),elo(p+e))
a=[]
for f in pairs('standard-master-vs-new'):
 x=json.loads(f.read_text());y=json.loads((d/'standard-vs-early-new/pairs'/f.name).read_text())
 assert x['pair_seed']==y['pair_seed'] and x['opening']==y['opening']
 if None not in (x['category'],y['category']):a.append([1-x['category']/4,1-y['category']/4])
v=np.asarray(a);z=v[:,1]-v[:,0];rng=np.random.default_rng(719321)
print('late vs early new against standard',len(a),v.mean(0),z.mean(),np.quantile(z[rng.integers(0,len(z),(20000,len(z)))].mean(1),[.025,.975]))

#!/bin/bash
set -eu
cd "$(dirname "$0")"
for k in 1 2; do
  for mode in psqt shared bias; do
    while ! test -f "fit-$mode-$k/summary.json"; do sleep 10; done
    bash duel.sh "match-$mode-$k" "fit-$mode-$k" "fit-production-$k" nodes=3000 160 3 "$((20261119100000 + k*10000))"
  done
done

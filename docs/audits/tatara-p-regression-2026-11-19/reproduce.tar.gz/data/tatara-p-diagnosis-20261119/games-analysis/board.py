from probe import *
import numpy as np
def boardstats(board):
 out=np.zeros((2,9))
 for r,row in enumerate(board.split('/')):
  c=0
  for tok in re.findall(r'\d+|\+?[a-zA-Z]',row):
   if tok.isdigit():
    c+=int(tok); continue
   i=int(tok[-1].islower());k=tok.upper();a=r if i else 11-r
   out[i,0]+=k=='P'
   if k in ('N','+O'):out[i,1]+=a
   out[i,2]+=a if k=='P' else 0
   out[i,3]+=a if k not in ('P','I','K') else 0
   out[i,4]+=a>=6
   out[i,5]+= k.startswith('+')
   out[i,6]+= k[-1] in 'RBDHVMQN' and a>=4
   out[i,7]+=k=='P' and a>=6
   out[i,8]+= k=='I'
   c+=1
  assert c==12
 return out[0]-out[1]
e=Engine(0)
def run():
 rows=collections.defaultdict(list)
 for path in sorted(pairs.glob('*.json')):
  d=json.loads(path.read_text())
  if d['category']==None or d['pair_number']>284:continue
  for g in d['games']:
   cc=g['candidate_color'];ts=g['turns']
   for t in (0,32,64,96,128,192):
    if len(ts)<=t:continue
    m=d['opening']['moves']+[x['response']['usi'] for x in ts[:t]]
    e.send('position startpos moves '+' '.join(m)+'\nstate\nmoves')
    state=e.until('state rules')[-1].split();moves=e.until('moves')[-1].split()[1:]
    vals=boardstats(state[4])*(1 if cc=='black' else -1)
    sign=1 if (state[5]=='b')==(cc=='black') else -1
    rows[d['pair_number'],t].append(np.append(vals,sign*len(moves)))
 agg=collections.defaultdict(list)
 for (p,t),ds in rows.items():
  if len(ds)==2:
   v=np.mean(ds,axis=0);v[-1]*=2
   agg[t].append(v)
 print('pawn count, lion rank, pawn rank sum, nonpawn nonGB nonking rank sum, pieces in opposition half, promoted count, major+lions >=rank4, advanced pawn count, GB count, mobility (old-new)')
 for t,ds in sorted(agg.items()):
  a=np.array(ds);rng=np.random.default_rng(1)
  print(t,len(ds),np.round(a.mean(axis=0),3));print('CI',np.round(np.quantile(a[rng.integers(len(ds),size=(2000,len(ds)))].mean(axis=1),[.025,.975],axis=0),3))
try:run()
finally:e.close()

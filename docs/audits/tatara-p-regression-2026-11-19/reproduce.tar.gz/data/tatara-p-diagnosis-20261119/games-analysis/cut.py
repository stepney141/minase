from probe import *
import numpy as np
base=dict(zip('PILAMVBRHDQKEFTCSGOXN',[100,125,375,375,500,500,625,750,875,1000,1500,2600,503,375,380,250,250,378,385,383,2500]))
prom=dict(zip('PILAMVBRHD EFTCSGOX'.replace(' ',''),[378,503,875,625,1000,1000,875,1000,1250,1375,2600,625,750,500,500,750,2500,1500]))
def mats(board):
 m=[0,0];l=[0,0];q=[0,0];c=[0,0]
 for token in re.findall(r'\+?[a-zA-Z]',board):
  i=int(token[-1].islower());spec=token.upper();v=prom[spec[-1]] if len(spec)>1 else base[spec]
  m[i]+=v;l[i]+=spec in ('N','+O');q[i]+=spec in ('Q','+X');c[i]+=1
 return np.array([a-b for a,b in (m,l,q,c)])
e=Engine(0)
def run():
 counts=collections.Counter(); opening=collections.Counter();depths=collections.defaultdict(lambda:[[],[]]); scores=collections.defaultdict(lambda:[[],[]]); result=collections.defaultdict(list); clocks=[[],[]];delta=collections.defaultdict(list)
 for path in sorted(pairs.glob('*.json')):
  d=json.loads(path.read_text())
  if d['category']==None or d['pair_number']>284:continue
  for j,g in enumerate(d['games']):
   ts=g['turns'];cc=g['candidate_color'];winner=g['termination'].get('winner'); w=0.5 if winner==None else int(winner==cc)
   counts[(cc,w)]+=1
   delay=[sum(x['think_time_ns'] for x in ts if (x['side']==cc)==b)/1e9 for b in (True,False)]
   for i in range(2):clocks[i].append(delay[i])
   for t,x in enumerate(ts):
    k=(t//32*32) if t<128 else (128 if t<256 else 256)
    i=int(x['side']!=cc)
    if x['evaluation']:
     depths[k][i].append(x['evaluation']['depth'])
     if x['evaluation']['score']['kind']=='cp':scores[k][i].append(x['evaluation']['score']['value'])
   for t in (0,16,32,64,96,128,192,256):
    if t>=len(ts):continue
    moves=d['opening']['moves']+[x['response']['usi'] for x in ts[:t]]
    e.send('position startpos moves '+' '.join(moves)+'\nstate')
    board=e.until('state rules')[-1].split()[4]
    mat=mats(board)*(1 if cc=='black' else -1)
    result[d['pair_number'],t].append(mat)
    if t in (64,96,128,192,256): print('cut',d['pair_number'],cc,t,w,*mat)
   opening[len(d['opening']['moves'])]+=1
 print('count',counts,'openings',sorted(opening.items()),'total time',list(map(sum,clocks)), 'avg time/game',list(map(st.mean,clocks)))
 print('depth',[(k,[round(st.mean(x),2) for x in a],[st.median(x) for x in a]) for k,a in depths.items()])
 print('root scores',[(k,[round(st.median(x),2) for x in a]) for k,a in scores.items()])
 for (pair,t),xs in result.items():
  if len(xs)==2:delta[t].append(np.mean(xs,axis=0))
 rng=np.random.default_rng(1)
 for t,ds in sorted(delta.items()):
  a=np.array(ds);se= a[rng.integers(len(ds),size=(2000,len(ds)))].mean(axis=1)
  print('phase',t,len(ds),np.round(a.mean(axis=0),3),'CI',np.round(np.quantile(se,[.025,.975],axis=0),3))
try:run()
finally:e.close()

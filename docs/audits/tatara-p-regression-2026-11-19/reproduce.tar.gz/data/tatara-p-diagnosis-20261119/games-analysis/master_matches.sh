#!/bin/bash
set -eu
d=$(realpath "$(dirname "$0")/..")
cd "$d/../.."
N=/mnt/synology_nas/minase/nnue/nets
runner=target/match-cache/8b853b6655f3c2acfa41677449d2bcc8509dc66c/minase
case $1 in
    new) b=8b853b66; net=37054c9e49c9218bb18efdd1814fe1b298de5cbfc9c14352f6ad6eaecbb70dea;;
    retrained) b=a48f03aa; net=fc86cce6b2f60c357061222fd54afdd62a5a88330b0a9207c93ec0119622ee71;;
esac
nice -n 10 "$runner" match run --run-dir "$d/standard-master-vs-$1" --seed 20261119080000 --candidate commit:a48f03aa --baseline commit:"$b" --candidate-option EvalFile="$N/987f060d545c09f0a42b4c668ea8b24cbf83c1770d11d663a94e4b82601274cd.bin" --baseline-option EvalFile="$N/$net.bin" --candidate-hash 16 --baseline-hash 16 --each nodes=3000 --rules JCSA --concurrency 3 elo --pairs 200 > "$d/standard-master-vs-$1.log" 2>&1

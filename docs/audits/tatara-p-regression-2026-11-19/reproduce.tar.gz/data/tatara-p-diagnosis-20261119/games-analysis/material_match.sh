#!/bin/bash
set -eu
d=$(dirname "$(realpath "$0")")/..
root=$(realpath "$d/../..")
cd "$root"
net=/mnt/synology_nas/minase/nnue/nets
runner="$root/target/match-cache/8b853b6655f3c2acfa41677449d2bcc8509dc66c/minase"
case "$1" in
  standard-with-v0-table) c="$net/987f060d545c09f0a42b4c668ea8b24cbf83c1770d11d663a94e4b82601274cd.bin"; b="$d/$1.bin";;
  retrained-with-master-table) c="$d/$1.bin"; b="$net/fc86cce6b2f60c357061222fd54afdd62a5a88330b0a9207c93ec0119622ee71.bin";;
esac
nice -n 12 "$runner" match run --run-dir "$d/$1" --seed 20261119080000 --candidate commit:a48f03aa --baseline commit:a48f03aa --candidate-option EvalFile="$c" --baseline-option EvalFile="$b" --candidate-hash 16 --baseline-hash 16 --rules JCSA --each nodes=3000 --concurrency 2 elo --pairs 200 > "$d/$1.log" 2>&1

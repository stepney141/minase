from probe import *
import hashlib
folder=Path(__file__).resolve().parent.parent
std,ret=[Path(nets[i]).read_bytes() for i in (2,0)]
section=slice(192+54720,192+54720+4*47)
for name,to,frm in [('standard-with-v0-table',std,ret),('retrained-with-master-table',ret,std)]:
 b=bytearray(to)
 b[section]=frm[section]
 b[144:176]=hashlib.sha256(b[192:]).digest()
 assert len(b)==len(to) and b[176:section.start]==to[176:section.start] and b[section.stop:]==to[section.stop:]
 (folder/(name+'.bin')).write_bytes(b)
 print(name,hashlib.sha256(b).hexdigest())

from pathlib import Path
import hashlib
folder=Path(__file__).resolve().parent.parent
old=(folder.parent/'nnue-tatara-framework-and-halfkp-vm/train-before/nnue.bin').read_bytes()
assert hashlib.sha256(old).hexdigest()=='fc86cce6b2f60c357061222fd54afdd62a5a88330b0a9207c93ec0119622ee71'
rs=folder/'order-source/crates/minase/src/eval/nnue/network/layer_stack.rs'
(rs.parent/'order-table.bin').write_bytes(old[192:192+13680*4])
s=rs.read_text()
start=s.index('        let delta = |side|',s.index('pub(crate) fn quiet_move_psqt_delta'))
end=s.index('\n    }',start)
s=s[:start]+'''        const TABLE: &[u8; 54720] = include_bytes!("order-table.bin");
        let side = position.side_to_move();
        let weight = |feature: usize, phase: usize| {
            let offset = 4 * feature + 2 * phase;
            i64::from(i16::from_le_bytes([TABLE[offset], TABLE[offset + 1]]))
        };
        let from = features::feature_index(side, piece, mv.from);
        let to = features::feature_index(side, moved, mv.to);
        let q = i64::from(position.occupied().popcount().saturating_sub(2)).min(90);
        q * (weight(to, 0) - weight(from, 0))
            + (90 - q) * (weight(to, 1) - weight(from, 1))'''+s[end:]
rs.write_text(s)

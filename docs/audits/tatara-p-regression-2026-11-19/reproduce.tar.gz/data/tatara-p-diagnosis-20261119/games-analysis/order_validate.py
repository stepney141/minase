from probe import *
from collections import Counter
old=Engine(1)
exes[1]=root/'data/tatara-p-diagnosis-20261119/order'
swapped=Engine(1)
cnt=Counter()
try:
 for file in sorted(pairs.glob('*.json'))[:32]:
  d=json.loads(file.read_text()); turns=d['games'][0]['turns']
  for t in (0,64,128):
   if len(turns)<=t:continue
   m=d['opening']['moves']+[x['response']['usi'] for x in turns[:t]]
   raw=[]
   output=[]
   for e in (old,swapped):
    e.send('usinewgame\nposition startpos moves '+' '.join(m)+'\neval');raw.append(e.until('info string end'))
    output.append(e.go(m,3000))
   assert raw[0]==raw[1]
   cnt['same_eval']+=1
   cnt['changed_move']+=output[0][0]!=output[1][0]
 print(dict(cnt))
finally:
 for e in [old,swapped]:e.close()

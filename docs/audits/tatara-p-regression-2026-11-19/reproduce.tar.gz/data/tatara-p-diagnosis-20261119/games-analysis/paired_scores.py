import json
from pathlib import Path

import numpy as np

folder = Path(__file__).resolve().parent.parent
for candidate, reference in [
    ('old-3000', 'order-3000'),
    ('standard-master-vs-new', 'standard-master-vs-retrained'),
]:
    differences = []
    for pair_path in sorted((folder / candidate / 'pairs').glob('*.json')):
        pair = json.loads(pair_path.read_text())
        control = json.loads((folder / reference / 'pairs' / pair_path.name).read_text())
        assert pair['opening'] == control['opening']
        if pair['category'] is not None and control['category'] is not None:
            differences.append((pair['category'] - control['category']) / 4)
    outcomes = np.asarray(differences)
    rng = np.random.default_rng(1)
    means = outcomes[rng.integers(len(outcomes), size=(10000, len(outcomes)))].mean(axis=1)
    print(candidate, reference, len(outcomes), outcomes.mean(), np.quantile(means, [.025, .975]))

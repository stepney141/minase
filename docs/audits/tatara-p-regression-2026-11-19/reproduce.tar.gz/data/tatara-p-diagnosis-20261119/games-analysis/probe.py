import json,re,subprocess,sys,collections,statistics as st
from pathlib import Path

root=Path('/home/stepney141/board-games/minase')
pairs=root/'data/matches/nnue-tatara-framework-and-halfkp-vm-stc/pairs'
manifest=json.loads((pairs.parent/'manifest.json').read_text())
nets=[manifest[model]['options'][0][1] for model in ['candidate','baseline']]
nets.append(str(next(Path(nets[0]).parent.glob('987f*.bin'))))
exes=[root/'data/worktrees'/n/'target/release/minase' for n in ('tatara-before-a48f03aa','tatara-head-8b853b66','tatara-before-a48f03aa')]
class Engine:
 def __init__(self,i):
  self.p=subprocess.Popen([exes[i],'--protocol','usi'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
  self.send('usi');self.until('usiok')
  self.send('setoption name RuleSet value JCSA\nsetoption name USI_Hash value 16\nsetoption name EvalFile value '+nets[i]+'\nisready');self.until('readyok')
 def send(self,line):
  self.p.stdin.write(line+'\n');self.p.stdin.flush()
 def until(self,mark):
  lines=[]
  while True:
   raw=self.p.stdout.readline();line=raw.strip()
   if not raw or 'string error' in line:raise Exception((mark,line,lines[-3:]))
   lines.append(line)
   if line.startswith(mark): return lines
 def go(self,m,n):
  self.send('usinewgame\nposition startpos moves '+' '.join(m)+'\ngo nodes '+str(n))
  lines=self.until('bestmove')
  scr=None
  for l in lines:
   r=re.search(r'score (cp|mate) ([+-]?\d+)',l)
   if r:
    v=int(r[2]);scr=v if r[1]=='cp' else (30000-abs(v))*(1 if v>0 else -1)
  return lines[-1].split()[1],scr
 def close(self):self.send('quit');self.p.wait()
def run():
 engines=[Engine(i) for i in range(3)]
 try:
  for path in sorted(pairs.glob('*.json')):
   d=json.loads(path.read_text())
   if d['category']==None or d['pair_number']%4!=1:continue
   gp=d['games'][((d['pair_number']-1)//4)%2]
   if len(gp['turns'])<9:continue
   for t in (0,64,160):
    if t>=len(gp['turns'])-8:continue
    m=d['opening']['moves']+[x['response']['usi'] for x in gp['turns'][:t]]
    cand=[e.go(m,6000) for e in engines[:2]]
    scores={}
    if cand[0][0]!=cand[1][0] and all(x[0]!='resign' for x in cand):
     for i in (2,1):
      scores[i]=[engines[i].go(m+[x[0]],36000)[1] for x in cand]
    print(json.dumps(dict(pair=d['pair_number'],t=t,moves=cand,scores=scores)),flush=True)
 finally:
  for e in engines:e.close()
if __name__=='__main__':run()

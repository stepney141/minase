from probe import *
import numpy as np
eng=[Engine(i) for i in (0,1)]
def get_eval(e,sfen):
 e.send('position sfen '+sfen+'\neval')
 ls=e.until('info string end')
 return int(next(l for l in ls if l.startswith('info string evaluation')).split()[-1])
def deltok(b,idx):
 chunks=[]
 for r in b.split('/'):chunks.append(re.findall(r'\d+|\+?[a-zA-Z]',r))
 n=0
 for row in chunks:
  for i,x in enumerate(row):
   if x.isdigit():continue
   if n==idx:row[i]='1'
   n+=1
 def encode(row):
  arr=[];spaces=0
  for v in row:
   if v.isdigit():spaces+=int(v);continue
   if spaces:arr.append(str(spaces));spaces=0
   arr.append(v)
  if spaces:arr.append(str(spaces))
  return ''.join(arr)
 return '/'.join(encode(row) for row in chunks)
def run():
 for p in sorted(pairs.glob('*.json')):
  d=json.loads(p.read_text());num=d['pair_number']
  if num%4!=1 or num>284 or d['category']==None:continue
  gp=d['games'][((num-1)//4)%2];ts=gp['turns']
  for t in (0,64,96,160):
   if len(ts)<=t:continue
   moves=d['opening']['moves']+[x['response']['usi'] for x in ts[:t]]
   eng[0].send('usinewgame\nposition startpos moves '+' '.join(moves)+'\nd')
   sf=next(l for l in eng[0].until('rights-zobrist') if l.startswith('sfen ')).split()[1:]
   initial=[get_eval(e,' '.join(sf)) for e in eng]
   vals=collections.defaultdict(list)
   for idx,x in enumerate(re.findall(r'\+?[a-zA-Z]',sf[0])):
    if x.upper() not in ('P','I','N','Q','R','B','C','G'):continue
    sign=1 if x.isupper()==(sf[1]=='b') else -1
    removed=[get_eval(e,' '.join([deltok(sf[0],idx)]+sf[1:])) for e in eng]
    vals[x.upper()].append([(o-y)*sign for o,y in zip(initial,removed)])
   print(json.dumps({'pair':num,'t':t,'values':{k:np.mean(a,axis=0).tolist() for k,a in vals.items()}}),flush=True)
try:run()
finally:
 for e in eng:e.close()

import json
from pathlib import Path

import numpy as np

folder = Path(__file__).resolve().parent
positions = [json.loads(line) for line in (folder / 'probe.jsonl').read_text().splitlines()]
positions = [p for p in positions if p['pair'] <= 284]
print('Move agreement', sum(p['moves'][0][0] == p['moves'][1][0] for p in positions), len(positions))
for judge in ['2', '1']:
    clusters = {}
    for p in positions:
        score = p['scores'].get(judge)
        delta = score[1] - score[0] if score else 0
        clusters.setdefault(p['pair'], []).append(delta)
    # Exactly three root positions for every retained pair.
    data = np.array(list(clusters.values()))
    rng = np.random.default_rng(1)
    sample = data[rng.integers(len(data), size=(10000, len(data)))].mean(axis=(1, 2))
    print(judge, data.mean(), np.quantile(sample, [.025, .975]))

removals = [json.loads(line) for line in (folder / 'remove.jsonl').read_text().splitlines()]
for turn in [0, 64, 96, 160]:
    for piece in ['P','I','N','Q']:
        values = np.array([p['values'][piece] for p in removals if p['t'] == turn and piece in p['values']])
        delta = np.diff(values, axis=1).ravel()
        rng = np.random.default_rng(1)
        boot = delta[rng.integers(len(delta), size=(2000, len(delta)))].mean(axis=1)
        print(turn, piece, len(values), values.mean(axis=0), np.quantile(boot, [.025, .975]))

groups = {}
for line in (folder / 'cut.txt').read_text().splitlines():
    if not line.startswith('cut '):
        continue
    _, number, color, turns, score, material, *_ = line.split()
    groups.setdefault((int(turns), int(np.sign(float(material)))), []).append(float(score))
for group, sample in sorted(groups.items()):
    print('material and final score', group, len(sample), np.mean(sample))

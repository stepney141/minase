#!/bin/bash
set -eu
d=$(realpath "$(dirname "$0")/..")
cd "$d/../.."
runner=target/match-cache/8b853b6655f3c2acfa41677449d2bcc8509dc66c/minase
CARGO_BUILD_JOBS=1 nice -n 12 "$runner" match run --run-dir "$d/teacher-generators" --seed 20261119120000 --candidate commit:31c2a46 --baseline commit:7c2cfe4e --candidate-args="--rules L0,P0,R1,E0" --baseline-args="--rules L0,P0,R1,E0" --candidate-hash 16 --baseline-hash 16 --each nodes=20000 --rules L0,P0,R1,E0 --concurrency 3 elo --pairs 100 > "$d/teacher-generators.log" 2>&1

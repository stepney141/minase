from pathlib import Path
import re,subprocess,sys
d=Path(__file__).resolve().parent
dest=Path(sys.argv[1]).resolve()
s=r'''\documentclass[dvipdfmx,border=8pt]{standalone}
\usepackage{tikz}
\renewcommand{\familydefault}{\sfdefault}\renewcommand{\kanjifamilydefault}{\gtdefault}
\usepackage{pgfplots}\pgfplotsset{compat=1.18}
\definecolor{ink}{HTML}{23374A}\definecolor{data}{HTML}{195A79}\definecolor{grid}{HTML}{CFD7DB}
\begin{document}\begin{tikzpicture}
'''
def chart(title,offset,xrange,step,groups,xlabel):
 global s
 w=9.0; amin,amax=xrange
 transform=lambda v: w*(v-amin)/(amax-amin)
 s+=r'\begin{scope}[shift={(0,'+str(offset)+')}]\n'
 s+=r'\node[anchor=west,font=\bfseries,text=ink] at (-6.9,0.8){'+title+'};\n'
 bottom=-len(groups)*.65+.2
 for x in range(amin,amax+1,step):
    xx=transform(x)
    s+=r'\draw['+('ink' if x==0 else 'grid')+f'] ({xx},{bottom}) -- ({xx},0.34);\n'
    s+=r'\node[font=\small,text=ink,below] at '+f'({xx},{bottom})'+'{'+str(x)+'};\n'
 for i,(name,val,lo,hi) in enumerate(groups):
    y=-.65*i
    s+=r'\node[anchor=east,text=ink] at (-0.25,'+str(y)+'){'+name+'};\n'
    l,h,v=[transform(a) for a in (lo,hi,val)]
    s+=r'\draw[data,line width=1.1pt] '+f'({l},{y}) -- ({h},{y});\n'
    for e in(l,h):s+=r'\draw[data,line width=0.7pt] '+f'({e},{y-.09}) -- ({e},{y+.09});\n'
    s+=r'\fill[data] '+f'({v},{y}) circle[radius=1.8pt];\n'
 s+=r'\node[text=ink,anchor=north,font=\small] at '+f'({w/2},{bottom-.58})'+'{'+xlabel+'};\n\\end{scope}\n'
names=[('標準ネット 対 新型','standard-master-vs-new'),('標準ネット 対 再学習した旧型','standard-master-vs-retrained'),('再学習した旧型 対 新型','old-3000')]
vals=[]
for label,name in names:
    m=re.search(r'elo: estimate=(\S+) ci95=\[([^,]+), ([^\]]+)\]',(d/(name+'.log')).read_text()); vals.append((label,*map(float,m.groups())))
chart('同じ3,000ノードで比べた棋力差',0,(-100,500),100,vals,'先に記した側から見た棋力差（Elo）')
labels=['全層を実数に変更','後段を16ビットに変更','全層を実数に変更（別の開始局面）']
values=[]
for line,label in zip((d/'opponent.log').read_text().splitlines(),labels):
    m=re.search(r'change in new score rate vs old (\S+) \[\s*([-\d.]+)\s+([-\d.]+)\s*\]',line)
    values.append((label,*[float(v)*100 for v in m.groups()]))
chart('相手を旧型に固定したときの、新型の得点率の変化',-4.4,(-10,20),5,values,'通常の8ビットに対する得点率の差（ポイント）')
s+='\\end{tikzpicture}\\end{document}\n'
(d/'comparison.tex').write_text(s)
subprocess.run(['uplatex','-interaction=batchmode','-halt-on-error','comparison.tex'],cwd=d,check=True,stdout=subprocess.DEVNULL)
subprocess.run(['dvipdfmx','-q','comparison.dvi'],cwd=d,check=True)
subprocess.run(['pdftoppm','-r','160','-png','-singlefile',d/'comparison.pdf',dest.with_suffix('')],check=True)

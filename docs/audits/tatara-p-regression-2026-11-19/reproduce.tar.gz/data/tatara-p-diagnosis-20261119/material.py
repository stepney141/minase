from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
a=bytearray((d.parent/'nnue-tatara-framework-and-halfkp-vm/train-before/nnue.bin').read_bytes())
s=Path('/mnt/synology_nas/minase/nnue/nets/987f060d545c09f0a42b4c668ea8b24cbf83c1770d11d663a94e4b82601274cd.bin').read_bytes()
start=192+13680*4
a[start:start+47*4]=s[start:start+47*4]
a[144:176]=hashlib.sha256(a[192:]).digest()
(d/'old-standard-material.bin').write_bytes(a)

import numpy as np,json
from pathlib import Path
d=Path(__file__).resolve().parent
for base,x in [('old-3000','old-float-3000'),('old-3000','old-precise-3000'),('old-new-repeat','old-float-repeat')]:
 if not (d/x/'summary.json').exists():continue
 a=[];b=[]
 for p in sorted((d/base/'pairs').glob('*.json')):
    q=d/x/'pairs'/p.name
    if not q.exists():continue
    f,g=(json.loads(h.read_text()) for h in (p,q));assert f['opening']==g['opening'] and f['pair_seed']==g['pair_seed']
    if f['category'] is not None and g['category'] is not None:a.append(f['category']/4);b.append(g['category']/4)
 a=np.array(a);b=np.array(b);v=(a-b)
 rng=np.random.default_rng(119479)
 print(x,len(v),'old score rate with normal / intervention opponents',a.mean(),b.mean(),'change in new score rate vs old',v.mean(),np.quantile(v[rng.integers(0,len(v),(20000,len(v)))].mean(1),[.025,.975]))

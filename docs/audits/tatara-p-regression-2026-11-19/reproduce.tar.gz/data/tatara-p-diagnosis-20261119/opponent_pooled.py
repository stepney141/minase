from pathlib import Path
import numpy as np,json
d=Path(__file__).resolve().parent
rng=np.random.default_rng(9180222)
draw=[];avg=[]
for a,b in [('old-3000','old-float-3000'),('old-new-repeat','old-float-repeat')]:
 v=[]
 for f in sorted((d/a/'pairs').glob('*.json')):
    left=json.loads(f.read_text());right=json.loads((d/b/'pairs'/f.name).read_text())
    assert left['pair_seed']==right['pair_seed'] and left['opening']==right['opening']
    if left['category'] is None or right['category'] is None:continue
    v.append((left['category']-right['category'])/4)
 v=np.array(v);avg.append(v.mean());draw.append(v[rng.integers(0,len(v),(20000,len(v)))].mean(1))
print('FP vs 8bit, old opponent:',np.mean(avg),np.quantile(np.mean(draw,axis=0),[.025,.975]))

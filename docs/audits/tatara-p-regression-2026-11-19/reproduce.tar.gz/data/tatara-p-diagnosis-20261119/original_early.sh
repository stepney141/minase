#!/bin/bash
set -eu
d=$(cd "$(dirname "$0")" && pwd)
td="$d/../nnue-tatara-framework-and-halfkp-vm"
for i in $(seq 0 36); do books+=("$td/teacher-jcsa-v3/book-$i.mnsd"); done
while [[ ! -e "$d/fit-corpus-master-2/summary.json" ]]; do sleep 20; done
for arm in old new bias; do
  while [[ $(awk '/^MemAvailable:/ {print $2}' /proc/meminfo) -lt 16000000 ]]; do sleep 20; done
  case "$arm" in
    old) bin="$d/../worktrees/tatara-before-a48f03aa/target/release/minase-trainer"; opts=(--base "$d/../nnue-generation-reset/base.bin" --feature-set P --width 256 --head pairwise-l16-l32);;
    new) bin="$d/../worktrees/tatara-after-8389b160/target/release/minase-trainer"; opts=(layerstack --rules JCSA --teacher-cp-per-logit 679.029296875);;
    bias) bin="$d/bias-source/target/release/minase-trainer"; opts=(layerstack --rules JCSA --teacher-cp-per-logit 679.029296875);;
  esac
  systemd-run --user --scope -p MemoryMax=18G -p MemorySwapMax=0 -- nice -n 15 "$bin" nnue train "${opts[@]}" --data "${books[@]}" --output-dir "$d/early-$arm" --lambda 1 --batch 16384 --superbatches 2 --lr-schedule cosine:64:0.027 --validation-superbatches 1 --seed 1 --device cuda --threads 2 >"$d/early-$arm.log" 2>&1
done

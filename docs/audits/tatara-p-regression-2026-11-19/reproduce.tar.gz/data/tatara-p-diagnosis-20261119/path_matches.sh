#!/bin/bash
set -eu
cd "$(dirname "$0")"
while [[ ! -e float-new-3000.log ]] || ! rg -q '^summary:' float-new-3000.log; do sleep 15; done
for k in 'smooth new' 'ft smooth' 'head smooth'; do
 set -- $k
 bash duel.sh "$1-vs-$2" "$1" "$2" nodes=3000 240 4 20261119600000
done

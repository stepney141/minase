import json
import numpy as np
from pathlib import Path
d=Path(__file__).resolve().parent
for arm in ('match-psqt','match-shared','match-bias','corpus','temperature-master','temperature-gen2'):
    means=[]; estimates=[]
    rng=np.random.default_rng(871912)
    for seed in (1,2):
        folder=d/f'{arm}-{seed}';out=folder/'summary.json'
        if not out.exists() or json.loads(out.read_text())['invocation_active']: break
        vals=[json.loads(f.read_text())['category'] for f in sorted((folder/'pairs').glob('*.json'))]
        n=json.loads((folder/'invocations.json').read_text())[-1]['target_pairs'];assert len(vals)==n
        v=np.array([x for x in vals if x is not None])/4
        estimates.append(v.mean());means.append(v[rng.integers(0,len(v),(20000,len(v)))].mean(1))
    if len(means)!=2:continue
    pooled=np.mean(estimates);score=np.mean(means,axis=0)
    elo=lambda x:400*np.log10(x/(1-x))
    print(arm,'equal-seed score',pooled,'Elo',elo(pooled),*np.quantile(elo(score),[.025,.975]))

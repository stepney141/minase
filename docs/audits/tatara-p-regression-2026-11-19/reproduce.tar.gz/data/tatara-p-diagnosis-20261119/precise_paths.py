"""Hold FP inference arithmetic fixed and vary which trained parameters are rounded."""
from pathlib import Path
import numpy as np
d=Path(__file__).resolve().parent
buf=(d/'float.bin').read_bytes()
prefix=3919426
assert buf[prefix-4:prefix]==b'P64F'
sizes=(13680*256,256,13680,4096,16,960,32,32,1)
scales=(127,127,8128,64,8128,64,8128,64,8128)
full=np.frombuffer(buf,dtype='<f8',offset=prefix)
assert sum(sizes)==full.size
for mode in ('smooth','ft','head'):
    a=full.copy()
    j=0
    for i,(n,scale) in enumerate(zip(sizes,scales)):
        keep=(mode=='ft' and i<2) or (mode=='head' and i>=3)
        if not keep:
            v=a[j:j+n]
            v[:]=np.copysign(np.floor(abs(v)*scale+0.5),v)/scale
        j+=n
    (d/(mode+'.bin')).write_bytes(buf[:prefix]+a.tobytes())

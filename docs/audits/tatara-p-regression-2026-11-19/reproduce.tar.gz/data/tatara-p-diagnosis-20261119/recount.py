import json,sys,math,re
from pathlib import Path
from collections import Counter
d=Path(__file__).resolve().parent
def calculate(p):
    elapsed=json.loads((p/'summary.json').read_text())
    assert not elapsed['interrupted'] and not elapsed['invocation_active']
    cats=[0]*5; discard=0;t=Counter()
    files=sorted((p/'pairs').glob('*.json'))
    assert len(files)==json.loads((p/'invocations.json').read_text())[-1]['target_pairs']
    for i,path in enumerate(files,1):
        obj=json.loads(path.read_text());assert obj['pair_number']==i
        k=obj['category']
        if k is None:discard+=1
        else:cats[k]+=1
        for g in obj['games']:t[g['termination']['kind']]+=1
    n=sum(cats);mean=sum(i/4*x for i,x in enumerate(cats))/n
    se=math.sqrt(sum((i/4-mean)**2*x for i,x in enumerate(cats))/n**2)
    elo=lambda x:400*math.log10(x/(1-x))
    return len(files),discard,cats,[elo(x) for x in (mean,mean-1.96*se,mean+1.96*se)],t,elapsed['active_wall_time_ns']/1e9
if __name__=='__main__':
    for name in sys.argv[1:]:
        total,disc,cats,stats,terms,elapsed=calculate(d/name)
        print(name,total,disc,cats,stats,terms,elapsed,flush=True)

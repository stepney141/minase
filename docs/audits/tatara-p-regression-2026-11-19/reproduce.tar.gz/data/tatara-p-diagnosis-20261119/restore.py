from recount import *
for p in sorted(d.iterdir()):
    if not p.is_dir() or not (p/'manifest.json').exists():continue
    log=d/(p.name+'.log')
    if not log.exists() or '--run-dir: command not found' not in log.read_text(errors='replace')[-120:] or not (p/'summary.json').exists():continue
    total,sk,h,(v,lo,hi),terms,t=calculate(p)
    assert not set(terms)-{'adjudicated_win','adjudicated_draw','cutoff'}
    with log.open('a') as o:
        o.write(f'\nReconstructed from all completed pairs using recount.py. The original terminal summary was overwritten.\nsummary: mode=elo pairs={total} valid_pairs={sum(h)} discarded_pairs={sk}\npentanomial: {h}\nelo: estimate={v:.6f} ci95=[{lo:.6f}, {hi:.6f}]\nengine_failures: illegal_moves=0 crashes=0 timeouts=0 time_forfeits=0 rejected_moves=0\nelapsed: {t:.6f} s\n')
    print(p.name,v)

from pathlib import Path
import re,json
d=Path(__file__).resolve().parent
def result(k):
 log=(d/(k+'.log')).read_text()
 m=re.search(r'summary: mode=elo pairs=(\d+) valid_pairs=(\d+) discarded_pairs=(\d+).*?estimate=(\S+) ci95=\[([^,]+), ([^\]]+)\]',log,re.S);assert m,k
 n,v,skip,e,lo,hi=m.groups()
 return int(v),f'{float(e):+.1f}［{float(lo):+.1f}, {float(hi):+.1f}］'
def val(k):
 v,s=result(k)
 return f'[{s}](../measurements/adhoc/tatara-p-{k}.md)'
def loss(k):return json.loads((d/k/'summary.json').read_text())['final_validation_loss']
def table(rows):
 return '\n'.join(f'| {a} | {b} | {result(k)[0]} | {val(k)} |' for k,a,b in rows)
if __name__=='__main__':
 for f in sorted(d.glob('*.log')):
    if 'summary: mode=elo' in f.read_text(errors='ignore'):
       print(f.stem,*result(f.stem))

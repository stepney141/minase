from pathlib import Path
d=Path(__file__).resolve().parent
p=d/'train-source/crates/minase-trainer/src/nnue/layerstack/gpu/step.rs'
s=p.read_text()
key='                let offset = offset(p) as u32;'
assert s.count(key)==1
s=s.replace(key,'''                // These ablations only run with zero weight decay.
                let mode = *MODE.get_or_init(|| match std::env::var("P_PROBE").unwrap().as_str() {
                    "production" => 0, "psqt" => 1, "shared" => 2, _ => panic!("invalid arm"),
                });
                let lr = match (mode, p) {
                    (1, Parameter::Psqt) => lr*(0.03/(8128.0/12.0))/0.001,
                    (2, Parameter::L1Weights | Parameter::L1SharedWeights |
                        Parameter::L1Biases | Parameter::L1SharedBiases) => lr*0.5,
                    _ => lr,
                };
                assert_eq!(decay, 1.);
'''+key)
s+='\nstatic MODE:std::sync::OnceLock<u8>=std::sync::OnceLock::new();\n'
p.write_text(s)

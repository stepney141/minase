#!/bin/bash
set -eu
root=$(git rev-parse --path-format=absolute --git-common-dir | xargs dirname)
d="$root/data/tatara-p-diagnosis-20261119"
old="$root/target/match-cache/a48f03aa35cfa419353739ee001664543536dd71/minase"
new="$root/target/match-cache/8b853b6655f3c2acfa41677449d2bcc8509dc66c/minase"
cand="$1"
if [[ $cand == old ]]; then
  eng="$old"
  net="$root/data/nnue-tatara-framework-and-halfkp-vm/train-before/nnue.bin"
else
  eng="$d/$cand"
  net="$root/data/nnue-tatara-framework-and-halfkp-vm/train-after/nnue.bin"
fi
nice -n 12 "$new" match run --candidate "$eng --protocol usi" --baseline "$new --protocol usi" --candidate-option "EvalFile=$net" --baseline-option "EvalFile=$root/data/nnue-tatara-framework-and-halfkp-vm/train-after/nnue.bin" --candidate-hash 32 --baseline-hash 32 --rules JCSA --seed 20261119000000 --concurrency "${4}" --each "nodes=$2" --run-dir "$d/$cand-$2" elo --pairs "$3" >"$d/$cand-$2.log" 2>&1

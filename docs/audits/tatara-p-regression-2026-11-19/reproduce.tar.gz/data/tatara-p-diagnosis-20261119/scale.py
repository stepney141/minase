from pathlib import Path
import struct,numpy as np,subprocess
d=Path(__file__).resolve().parent
base=d.parent/'nnue-tatara-framework-and-halfkp-vm'
tr=base/'diagnosis-20261119/training'
b=(base/'train-after/nnue.bin').read_bytes()
n=struct.unpack_from('<I',b,8)[0]
a=b[12:12+n];assert a.endswith(b',fv_scale=12')
old=np.load(tr/'pred.npz')['ni']
for name,div in [('amplified',8),('attenuated',18)]:
    h=a[:-2]+str(div).encode()
    p=d/(name+'.bin');p.write_bytes(b[:8]+struct.pack('<I',len(h))+h+b[12+n:])
    cp=np.frombuffer(subprocess.check_output([tr/'full-after',p,tr/'sample']),'<i4')
    valid=np.abs(old)<19331
    diff=cp[valid]-np.trunc(old[valid]*12/div)
    assert np.abs(diff).max()<=2
    print(name,len(cp),sum(valid),np.abs(diff).max())

#!/bin/bash
set -eu
d=$(cd "$(dirname "$0")" && pwd); root=$(cd "$d/../.." && pwd)
cd "$root"
nice -n 12 target/match-cache/8b853b6655f3c2acfa41677449d2bcc8509dc66c/minase match run --run-dir "$d/standard-vs-early-new" --candidate commit:a48f03aa --baseline commit:8b853b66 --candidate-option 'EvalFile=/mnt/synology_nas/minase/nnue/nets/987f060d545c09f0a42b4c668ea8b24cbf83c1770d11d663a94e4b82601274cd.bin' --baseline-option "EvalFile=$d/early-new/nnue.bin" --rules JCSA --each nodes=3000 --candidate-hash 16 --baseline-hash 16 --concurrency 3 --seed 20261119080000 elo --pairs 200 >"$d/standard-vs-early-new.log" 2>&1

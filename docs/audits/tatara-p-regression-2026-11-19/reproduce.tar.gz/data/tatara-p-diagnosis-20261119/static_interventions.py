from pathlib import Path
import subprocess,numpy as np
d=Path(__file__).resolve().parent
tr=d.parent/'nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training'
heads=np.load(tr/'pred.npz')
prob=lambda x:1/(1+np.exp(-x/679.029296875))
for k in ['new','precise','smooth','ft','head','float']:
    z=heads
    if k in ('smooth','ft','head'):
        raw=subprocess.check_output([d/'readfloat',d/(k+'.bin'),tr/'sample'])
        x=np.frombuffer(raw,dtype=[('score','<i4'),('f','<u2',(2,94))])['score']
    else:
        if k=='new': x=z['ni']
        elif k=='precise': x=z['hi']
        else:x=np.trunc(z['nf'])
    dm=x-z['nf']
    print(k,'mean bias',dm.mean(),'MAE',np.abs(dm).mean(),'target MSE',np.mean((prob(x)-prob(z['score']))**2),flush=True)

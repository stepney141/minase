import json,numpy as np
from pathlib import Path
d=Path(__file__).resolve().parent/'precise-control-stc'
cpu=[[],[]];wall=[[],[]];dep=[[],[]];early=[[],[]];times=[[],[]]
for p in sorted((d/'pairs').glob('*.json')):
    obj=json.loads(p.read_text())
    if obj['category'] is None:continue
    for g in obj['games']:
        for i,key in enumerate(('candidate','baseline')):
            cpu[i].append(g[key+'_cpu_time_ns']/1e9)
            wall[i].append(g['wall_time_ns']/1e9)
        for j,t in enumerate(g['turns']):
            i=int(t['side']!=g['candidate_color'])
            if t['evaluation'] and t['evaluation'].get('depth') is not None:
                x=t['evaluation']['depth'];dep[i].append(x)
                if j<32:early[i].append(x)
            times[i].append(t['think_time_ns']/1e9)
for name,x in [('CPU sec/game',cpu),('elapsed sec/game',wall),('depth per scored move',dep),('depth first32',early),('think time/move',times)]:
    print(name,*[(len(v),np.mean(v)) for v in x])

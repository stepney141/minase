from pathlib import Path
import numpy as np
import struct
d=Path(__file__).resolve().parent.parent
total=games=0
for i in range(37):
    old=(d/f'nnue-generation-reset/gen-2/teacher/book-{i}.mnsd').read_bytes()
    new=(d/f'nnue-tatara-framework-and-halfkp-vm/teacher-jcsa-v3/book-{i}.mnsd').read_bytes()
    expected=bytearray(old)
    assert old[:8]==b'MNSD\x02\0\0\0' and new[:8]==b'MNSD\x03\0\0\0' and len(old)==len(new)
    expected[4]=3
    off=152
    ng,ne=struct.unpack_from('<QQ',old,136)
    got=0
    for _ in range(ng):
        n=struct.unpack_from('<I',old,off+10)[0]
        off+=161
        entries=np.frombuffer(expected,dtype='u1',count=n*7,offset=off).reshape(n,7)
        assert not entries[:,5:].any() # no policy candidates in these alpha-beta books
        flags=entries[:,4]
        assert not (flags>=16).any()
        flags[:]=(flags&3)|((flags&12)<<1)
        got+=n
        off+=7*n
    assert got==ne and off==len(new) and expected==new
    total+=ne
    games+=ng
print('identical after specified header/flag conversion:',37,'shards',games,'games',total,'entries')

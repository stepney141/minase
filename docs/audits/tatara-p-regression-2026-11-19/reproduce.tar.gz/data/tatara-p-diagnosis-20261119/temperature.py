from pathlib import Path
import subprocess,json
d=Path(__file__).resolve().parent
rates={};scale=679.029296875
for line in (d/'corpus-labels.log').read_text().splitlines():
    w=line.split()
    if 'CpPerLogit' in w: rates[w[0]]=float(w[w.index('CpPerLogit')+1])
assert set(rates)=={'gen2','master'}
for k in (1,2):
 for arm,other in [('master','gen2'),('gen2','master')]:
    path=d/f'fit-temperature-{arm}-{k}'
    dat=sorted((d/f'corpus-{arm}').glob('book-*.mnsd')); assert len(dat)==(30 if arm=='master' else 37)
    kt=scale*rates[arm]/rates[other]
    command=[str(d.parent/'worktrees/tatara-after-8389b160/target/release/minase-trainer'),'nnue','train','layerstack','--data',*map(str,dat),'--output-dir',str(path),'--rules','JCSA','--teacher-cp-per-logit',str(kt),'--lambda','1','--batch','4096','--batches-per-superbatch','256','--superbatches','16','--lr-schedule','cosine:16:0.027','--validation-superbatches','4','--seed',str(k),'--device','cuda','--threads','1']
    with (d/(path.name+'.log')).open('w') as log:subprocess.run(command,stdout=log,stderr=log,check=True)

#!/bin/bash
set -eu
cd "$(dirname "$0")"
for k in 1 2; do
 for arm in master gen2; do
  while ! test -f "fit-temperature-$arm-$k/summary.json"; do sleep 10; done
  bash duel.sh "temperature-$arm-$k" "fit-temperature-$arm-$k" "fit-corpus-$arm-$k" nodes=3000 160 3 "$((20261119700000 + k * 10000))"
 done
done

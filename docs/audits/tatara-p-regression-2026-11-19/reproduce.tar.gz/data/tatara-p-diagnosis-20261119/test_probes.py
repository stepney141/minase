from pathlib import Path
import subprocess
d=Path(__file__).resolve().parent
for source, names in [('source',['control','precise']),('float-source',['float'])]:
    p=d/source/'crates/minase/src/eval/nnue/network/evaluator.rs'
    s=p.read_text()
    start=s.index('    #[test]\n    fn random_games')
    stop=s.index('    #[test]',start+10)
    test=s[start:stop]
    a=test.index('for network in [')
    b=test.index('            for seed',a)
    code='for path in ['+','.join('"'+str(d/(name+'.bin'))+'"' for name in names)+'] {\n            let network=Network::decode(&std::fs::read(path).unwrap()).unwrap();\n'
    test=(test[:a]+code+test[b:]).replace('fn random_games_and_null_moves_match_full_evaluation()', 'fn probe_random_and_null_moves_match_full_evaluation()')
    p.write_text(s[:stop]+test+s[stop:])
    with (d/(source+'-update-test.log')).open('w') as out:
        subprocess.run(['cargo','test','--offline','-j2','--release','--lib','-p','minase','probe_random_and_null'],cwd=d/source,stdout=out,stderr=out,check=True)

#!/bin/bash
set -eu
d=$(cd "$(dirname "$0")" && pwd)
td="$d/../nnue-tatara-framework-and-halfkp-vm"
bin="$d/train-source/target/release/minase-trainer"
for seed in 1 2; do
 for mode in production psqt shared; do
  P_PROBE="$mode" nice -n 15 "$bin" nnue train layerstack --data "$td/teacher-jcsa-v3/book-0.mnsd" --output-dir "$d/fit-$mode-$seed" --rules JCSA --teacher-cp-per-logit 679.029296875 --lambda 1.0 --batch 4096 --batches-per-superbatch 256 --superbatches 16 --lr-schedule cosine:16:0.027 --validation-superbatches 4 --seed "$seed" --device cuda --threads 1 > "$d/fit-$mode-$seed.log" 2>&1
 done
done

#!/bin/bash
set -eu
cd "$(dirname "$0")"
d=$(pwd)
sample=../nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training
deps=source/target/release/deps
rustc --edition=2024 -C opt-level=3 -C target-cpu=native -L dependency="$deps" --extern minase=$(ls "$deps"/libminase-*.rlib) --extern minase_core=$(ls "$deps"/libminase_core-*.rlib) "$sample"/read.rs -o read16
for m in control precise; do ./read16 "$m.bin" "$sample/sample" >"$m.raw"; done
python3 - <<'PY'
import numpy as np
t='../nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training/'
d=np.load(t+'pred.npz')
for m,k in [('control','ni'),('precise','hi')]:
 x=np.fromfile(m+'.raw',dtype=np.dtype([('cp','<i4'),('f','<u2',(2,94))]))['cp']
 diff=x-d[k]
 print(m,len(x),np.max(abs(diff)),np.sum(diff!=0))
 assert not diff.any()
PY
cp source/target/release/minase probe16
bash duel.sh precise-3000 precise new nodes=3000 400 5 20261119000000

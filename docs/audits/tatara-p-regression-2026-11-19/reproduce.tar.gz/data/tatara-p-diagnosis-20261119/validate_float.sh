#!/bin/bash
set -eu
cd "$(dirname "$0")"
sample=../nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training
deps=float-source/target/release/deps
rustc --edition=2024 -C opt-level=3 -C target-cpu=native -L dependency="$deps" --extern minase=$(ls "$deps"/libminase-*.rlib) --extern minase_core=$(ls "$deps"/libminase_core-*.rlib) "$sample"/read.rs -o readfloat
./readfloat float.bin "$sample/sample" >float.raw
python3 - <<'PY'
import numpy as np
t='../nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training/'
x=np.fromfile('float.raw',dtype=np.dtype([('cp','<i4'),('f','<u2',(2,94))]))['cp']
y=np.clip(np.trunc(np.load(t+'pred.npz')['nf']),-28999,28999)
print('float',len(x),np.sum(x!=y),np.max(np.abs(x-y)),flush=True)
assert np.array_equal(x,y)
PY
cp float-source/target/release/minase probefloat
bash duel.sh old-float-3000 old float nodes=3000 240 3 20261119000000

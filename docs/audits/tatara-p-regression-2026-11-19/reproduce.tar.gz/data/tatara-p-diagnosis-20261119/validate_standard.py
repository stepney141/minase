from pathlib import Path
import numpy as np,subprocess,json
d=Path(__file__).resolve().parent
base=d.parent/'nnue-tatara-framework-and-halfkp-vm'
t=base/'diagnosis-20261119/training'
models={'master':next(Path('/mnt/synology_nas/minase/nnue/nets').glob('987f*.bin')),'archive':d.parent/'nnue-generation-reset/gen-2/train/nnue.bin','old':base/'train-before/nnue.bin','new':base/'train-after/nnue.bin'}
p=np.load(t/'pred.npz')
prob=lambda x:1/(1+np.exp(-x/679.029296875))
records=np.fromfile(t/'sample',np.uint8).reshape(-1,138)
for name,file in models.items():
 exe=t/('full-after' if name=='new' else 'full-before')
 x=np.frombuffer(subprocess.check_output([str(exe),str(file),str(t/'sample')]),'<i4')
 print(name,'outcome Brier',np.mean((prob(x)-records[:,119]/2)**2),'teacher MSE',np.mean((prob(x)-prob(p['score']))**2),'MAE',np.mean(abs(x-p['score'])))
 if name!='new':
  b=file.read_bytes(); tab=np.frombuffer(b,dtype='<i2',count=2*47*144*2,offset=192).reshape(2,47,144,2)/8
  print(name,'per-feature pooled spatial sd mg,eg',np.sqrt((tab.var(2)).mean((0,1))),'scale',np.frombuffer(b,dtype='<f4',count=1,offset=108))

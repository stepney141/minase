from pathlib import Path
import re,sys,tarfile,json,math
from recount import calculate
from results import result
repo=Path(sys.argv[1]).resolve();d=Path(__file__).resolve().parent
audit=repo/'docs/audits/tatara-p-regression-2026-11-19.md'
files=[audit,*sorted((repo/'docs/measurements/adhoc').glob('tatara-p-*.md'))]
for f in files:
 text=f.read_text()
 assert '\r' not in text and all(l==l.rstrip() for l in text.splitlines()),f
 for url in re.findall(r'\]\(([^()]+)\)',text):
    url=url.split('#',1)[0]
    if url and '://' not in url:assert (f.parent/url).is_file(),(f,url)
for f in files[1:]:
 name=f.stem.removeprefix('tatara-p-')
 total,disc,h,stats,terms,elapsed=calculate(d/name)
 v,display=result(name)
 assert v==total-disc and ('0.0 Elo' if abs(stats[0])<.05 else '{:+.1f} Elo'.format(stats[0])) in f.read_text(),(name,stats[0])
 log=(d/(name+'.log')).read_text()
 m=re.search(r'elo: estimate=(\S+) ci95=\[([^,]+), ([^\]]+)\]',log);assert m
 assert all(abs(a-float(b))<1e-5 for a,b in zip(stats,m.groups())),(name,stats,m.groups())
 assert h==json.loads(re.search(r'^pentanomial: (\[.+?\])',log,re.M)[1])
 print(name,total,disc,str(terms))
print('Checked',len(files),'docs')

import hashlib, json, re, shlex, sys
from pathlib import Path
d=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve()
out=repo/'docs/measurements/adhoc'
root=d.parents[1]
def desc(name):
    titles={
        'old-3000': ('同じ教師で学んだ旧型と新型', '同じ教師で学んだ旧型', '新型'),
        'standard-vs-early-new': ('標準ネットと学習を早く打ち切った新型の対局','masterの標準ネット','2回目のsuperbatchで学習を打ち切った新型'),
        'final-old-vs-new': ('早期終了との比較に使う最終時点の新旧対局','64回目の旧型','64回目の新型'),
        'old-precise-3000': ('旧型と後段を16ビットにした新型','第2世代の教師で学び直した旧型','後段を16ビットにした新型'),
        'old-new-repeat': ('別の開始局面で旧型と新型を比較した対局','第2世代の教師で学び直した旧型','通常の新型'),
        'old-float-repeat': ('別の開始局面で旧型と実数計算の新型を比較した対局','第2世代の教師で学び直した旧型','実数で推論する新型'),
        'old-float-3000': ('旧型と実数で推論する新型', '同じ教師で学んだ旧型', '実数で推論する新型'),
        'precise-3000': ('新型の後段の量子化精度', '後段を16ビットにした新型', '8ビットの新型'),
        'float-precise-3000': ('実数評価と後段16ビット評価', '実数で推論する新型','後段を16ビットにした新型'),
        'float-new-3000': ('実数評価と対局用の整数評価','実数で推論する新型','対局用の新型'),
        'calibrated-3000': ('後段の8ビット係数の補正', '8ビットの係数を補正した新型', '補正前の新型'),
        'precise-control-stc': ('同じ推論器で後段の精度を変えた短時間対局','後段を16ビットにした新型','8ビットの重みを整数倍して移した新型'),
        'standard-master-vs-new': ('masterの標準ネットと新型','masterの標準ネット','新型'),
        'standard-master-vs-retrained': ('masterの標準ネットと同じ教師で学び直した旧型','masterの標準ネット','同じ教師で学び直した旧型'),
        'gen2-old': ('第2世代の教師を使った学習条件の比較','第2世代の補正前の旧型（エポック2）','同じ教師で学び直した旧型（約66.3エポック）'),
        'standard-gen2': ('masterの標準ネットと第2世代の補正前の旧型','masterの標準ネット','第2世代の補正前の旧型（エポック2）'),
        'material-old': ('探索用の駒価値を交換した対局','探索用の駒価値を標準ネットから移した旧型','同じ重みでv0の駒価値を使う旧型'),
        'amplified-vs-new': ('新型の探索へ渡す評価値を1.5倍にした対局','評価値を1.5倍にした新型','通常の新型'),
        'attenuated-vs-new': ('新型の探索へ渡す評価値を3分の2にした対局','評価値を3分の2にした新型','通常の新型'),
        'teacher-generators': ('標準ネットと第2世代の教師生成機の対局','標準ネットの教師生成機','第2世代の教師生成機'),
        'order-3000': ('静かな手を並べる表の交換','旧型の並べ順を使う新型','通常の新型'),
    }
    titles.update({
        'standard-with-v0-table': ('標準ネットで探索用の駒価値を交換した対局','masterの標準ネット','v0の探索用駒価値を移した標準ネット'),
        'smooth-vs-new': ('整数化した重みで活性化を実数計算した対局','整数化した重みで途中の切り捨てを除いた新型','対局用の新型'),
        'ft-vs-smooth': ('入力層の重みを実数に戻した対局','入力層の重みを実数に戻した新型','整数化した重みで途中の切り捨てを除いた新型'),
        'head-vs-smooth': ('後段の重みを実数に戻した対局','後段の重みを実数に戻した新型','整数化した重みで途中の切り捨てを除いた新型'),
        'early-old-vs-old': ('全教師で旧型の学習期間を変えた対局','2回目のsuperbatchの旧型','64回目の旧型'),
        'early-new-vs-new': ('全教師で新型の学習期間を変えた対局','2回目のsuperbatchの新型','64回目の新型'),
        'full-shared-vs-early-new': ('全教師で幅16の層の学習率を半減した対局','幅16の層の学習率を半減した2回目の新型','通常の2回目の新型'),
        'early-bias-vs-early-new': ('全教師で新型の初期バイアスを変えた対局','初期バイアスを+0.05にした新型','初期バイアスを0にした新型'),
        'early-old-vs-early-new': ('全教師を使った学習初期の新旧対局','2回目のsuperbatchの旧型','2回目のsuperbatchの新型'),
    })
    temper=re.fullmatch(r'temperature-(master|gen2)-(\d+)',name)
    if temper:
        tag={'master':'標準ネット','gen2':'第2世代'}[temper[1]]
        return (f'{tag}の教師の勝率尺度を変えた新型（シード{temper[2]}）','教師の尺度を変えた新型','尺度679.03 cpで同じ教師から学んだ新型')
    r=re.fullmatch(r'corpus-(\d+)',name)
    if r: return (f'同数の対局を異なる教師から学ぶ比較（シード{r[1]}）','標準ネットと同じ出所の教師で学んだ新型','第2世代の教師で学んだ新型')
    m=re.fullmatch(r'match-(psqt|shared|bias)-(\d+)',name)
    if m:
        arm={'psqt':'駒と升の表の学習率を下げた新型','shared':'後段の第1層の学習率を半減した新型','bias':'幅32の層の初期バイアスを0.05にした新型'}[m[1]]
        return (f'{arm}の縮小実験（シード{m[2]}）',arm,'同じシードで学んだ新型')
    return titles.get(name)
def short(p):
    return str(p).replace(str(root),'$ROOT')
def spec(side):
    i=side['identity']
    if i['kind']=='commit': return 'commit:'+i['hash']
    return '"'+short(i['program'])+' '+' '.join(i['args'])+'"'
def netpath(side): return dict(side['options']).get('EvalFile','組み込み')
def ident(side):
    i=side['identity']
    if i['kind']=='commit':
        return i['hash'][:8],i['sha256']
    p=Path(i['program'])
    if p.name in ['probefloat','probe16','order']: ver='8b853b66 の診断用ビルド'
    elif p.parent.name[:8] in ('a48f03aa','8b853b66'):ver=p.parent.name[:8]
    else:ver='診断用ビルド'
    return ver,hashlib.sha256(p.read_bytes()).hexdigest()
for run in sorted(d.iterdir()):
    log=d/(run.name+'.log')
    labels=desc(run.name)
    if not labels or not (run/'manifest.json').exists() or not log.exists():continue
    s=log.read_text()
    mat=re.search(r'summary: mode=elo pairs=(\d+) valid_pairs=(\d+) discarded_pairs=(\d+)\npentanomial: (\[.*?\])\nelo: estimate=(\S+) ci95=\[([^,]+), ([^\]]+)\]\nengine_failures: (.*?)\nelapsed: (\S+)',s)
    if not mat:continue
    n,valid,skip,penta,est,lo,hi,fail,t=mat.groups()
    if run.name.startswith('standard') and 'time_forfeits=0' not in fail: print(run.name,fail)
    m=json.loads((run/'manifest.json').read_text()); iv=json.loads((run/'invocations.json').read_text())[-1]
    limit=m['candidate']['limit']
    each='nodes='+str(limit['nodes']) if limit['kind']=='fixed' else 'time=10000+100'
    title,cname,bname=labels
    c,b=[m[k] for k in ('candidate','baseline')]
    hc,hb=[m['hash_mb'][k] for k in ('candidate','baseline')]
    cver,csha=ident(c); bver,bsha=ident(b)
    tm=json.loads((run/'summary.json').read_text())['active_wall_time_ns']/1e9
    cmd=('minase match run '+chr(92)+'\n  --run-dir "$ROOT/data/tatara-p-diagnosis-20261119/'+run.name+'" --seed '+str(m['seed'])+' '+chr(92)+'\n  --candidate '+spec(c)+' --baseline '+spec(b)+' '+chr(92)+'\n  --candidate-option "EvalFile='+short(netpath(c))+'" '+chr(92)+'\n  --baseline-option "EvalFile='+short(netpath(b))+'" '+chr(92)+f'\n  --candidate-hash {hc} --baseline-hash {hb} --rules JCSA --each {each} '+chr(92)+f'\n  --concurrency {m["concurrency"]} elo --pairs {iv["target_pairs"]}')
    if run.name=='teacher-generators':
        c['network_sha256']='3679bebf1aaa79e08272b48cf9a6e4f912eef236d9ef92bdce918f750fb0655e'
        b['network_sha256']='82afc9dc2f61661965474c5f9da9c3624ddcb3d228c6b6e3034c0f7d0c148562'
        cmd=' '.join(['minase match run', '--run-dir "$ROOT/data/tatara-p-diagnosis-20261119/teacher-generators"', '--candidate '+spec(c),'--baseline '+spec(b), '--rules L0,P0,R1,E0','--each '+each,'--candidate-hash '+str(hc),'--baseline-hash '+str(hb),'--seed '+str(m['seed']),'--concurrency '+str(m['concurrency']),'elo --pairs '+str(iv['target_pairs'])])
    interpretation=(f'この条件では{cname}の得点率が高かった。' if float(lo)>0 else f'この条件では{bname}の得点率が高かった。' if float(hi)<0 else '区間は0 Eloを含み、この対局だけでは優劣を決められない。')
    qfail='不正着手、異常終了、応答のタイムアウト、時間切れ、着手の拒否はすべて0件だった。' if all(int(v)==0 for v in re.findall(r'=(\d+)',fail)) else f'異常の集計は `{fail}` だった。'
    text=f'''# {title}

## 目的

中将棋のP型評価関数をtataraのLayerStackへ移す前後の棋力を調べた。本文では移行前を旧型、移行後を新型と呼ぶ。下表の候補と基準を同じ開始局面から先後を入れ替えて対局させ、2局を1ペアとして候補側から見た棋力差を推定した。

## コマンドライン

`ROOT` は本体リポジトリのルートを指す。実行時の設定は測定ディレクトリの `manifest.json` にある。対局を実行したプログラムの版は{iv['runner']['version']}で、実行ファイルのSHA-256は `{iv['runner']['sha256']}` である。

```sh
{cmd}
```

## エンジン

日本中将棋連盟の規則セット `JCSA` を使った。

| 側 | ネット | エンジンのコミット | 実行ファイルの SHA-256 | 重みファイルの SHA-256 |
|---|---|---|---|---|
| 候補 | {cname} | {cver} | `{csha}` | `{c['network_sha256']}` |
| 基準 | {bname} | {bver} | `{bsha}` | `{b['network_sha256']}` |

## 環境

Intel Core Ultra 7 265KF（物理20コア、論理20コア）で{m['concurrency']}ペアを並行して測った。
探索は双方とも1スレッドで、置換表は候補{hc} MB、基準{hb} MBとした。

## 結果

{n}ペアのうち有効は{valid}ペア、破棄は{skip}ペアだった。
候補から見たペアの得点が0、0.5、1、1.5、2点だった度数は順に `{penta}` だった。
棋力差は{float(est):+.1f} Eloで、95%信頼区間は{float(lo):+.1f}〜{float(hi):+.1f} Eloだった。
{qfail}
累計実行時間は{tm:,.1f}秒だった。

## 結論

{interpretation}
関連する比較と診断用エンジンの構成は[棋力低下の調査](../../audits/tatara-p-regression-2026-11-19.md)にまとめた。
'''
    subject='中将棋のP型評価関数をtataraのLayerStackへ移す前後の棋力を調べた。本文では移行前を旧型、移行後を新型と呼ぶ。'
    if run.name!='teacher-generators':
        text=text.replace(subject,f'中将棋のP型評価関数について、{cname}の棋力を{bname}との直接対局で測った。本文中の新型はtataraのLayerStackへ移行した評価関数を指す。')
    text=text.replace('対局を実行したプログラムの版は','対局ハーネスの版は').replace('で、実行ファイルのSHA-256は','で、ハーネスの実行ファイルのSHA-256は')
    if run.name=='teacher-generators':
        text=text.replace('中将棋のP型評価関数をtataraのLayerStackへ移す前後の棋力を調べた。本文では移行前を旧型、移行後を新型と呼ぶ。','中将棋のP型評価関数の学習に使った2組の教師データについて、それぞれを生成したエンジンの棋力を比べた。')
        text=text.replace('日本中将棋連盟の規則セット `JCSA` を使った。','日本中将棋連盟の規則を表す `L0,P0,R1,E0` を使った。両エンジンは組み込みのネットを使用する。重みのSHA-256は各コミットの `crates/minase/nets/nnue.bin` から計算した。')
    if run.name=='precise-control-stc':
        verified=json.loads((run/'report.json').read_text())['run']
        assert abs(float(verified['elo'])-float(est))<1e-5
        text=text.replace('累計実行時間は', '同じ診断用エンジン同士が対局し、別の固定ノード対局や学習、ビルドも並行した。保存された棋譜を `minase match report` で再集計し、Eloと異常件数を照合した。有効な478局で最初の32手の平均完了深さは候補17.28手、基準16.85手だった。累計実行時間は')
    if int(skip):
        reason=all(int(v)==0 for v in re.findall(r'=(\d+)',fail))
        if reason:
            text=text.replace(f'破棄は{skip}ペアだった。',f'{skip}ペアは手数上限に達した局を含むため破棄した。')
    if 'Reconstructed from all completed pairs' in s:
        text=text.replace('累計実行時間は','実行スクリプトの変更と終了処理が重なり、最終集計の標準出力が上書きされた。保存された全ペアの棋譜から、対局ハーネスと同じ式で得点、信頼区間、終了理由を再集計した。累計実行時間は')
    text=text.replace('差は-0.0 Elo','差は0.0 Elo')
    if run.name.startswith(('early-','final-old-','full-shared-','standard-vs-early-')):
        text=text.replace('下表の候補と基準を','この実験の学習では6,104更新を1 superbatchとし、2回目は約2.07エポック、64回目は約66.3エポックに当たる。下表の候補と基準を')
    dest=out/('tatara-p-'+run.name+'.md')
    dest.write_text(text)

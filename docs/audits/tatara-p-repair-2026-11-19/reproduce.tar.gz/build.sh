#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
new=../worktrees/tatara-head-264b7fc4/target/release/deps
old=../worktrees/tatara-before-a48f03aa/target/release/deps
trainer=("$new"/libminase_trainer-*.rlib)
engine=("$old"/libminase-*.rlib)
core=("$old"/libminase_core-*.rlib)
[[ ${#trainer[@]} == 1 && ${#engine[@]} == 1 && ${#core[@]} == 1 ]]
for name in sample export; do
    if [[ "$name" == sample ]]; then out=select-sample; else out=export-net; fi
    rustc --edition 2024 -C opt-level=3 -C target-cpu=native -L "dependency=$new" --extern "minase_trainer=${trainer[0]}" "$name.rs" -o "$out"
done
rustc --edition 2024 -C opt-level=3 -C target-cpu=native -L "dependency=$old" --extern "minase=${engine[0]}" --extern "minase_core=${core[0]}" relabel.rs -o relabel-positions

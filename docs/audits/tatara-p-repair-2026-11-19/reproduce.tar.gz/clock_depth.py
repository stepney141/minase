from pathlib import Path
import json,re,numpy as np
from matches import d,m
out={}
for log in m.glob('gate-*.log'):
 s=log.read_text()
 maxp=int(re.findall(r'^summary: .*? pairs=(\d+) valid_pairs=',s,re.M)[-1]); vals=[]
 for q in (m/log.stem/'pairs').glob('*.json'):
    p=json.loads(q.read_text())
    if p['pair_number']>maxp or p['category'] is None:continue
    depth=[[],[]];time=[[],[]]
    for g in p['games']:
        moves=g['turns'][:32]
        if len(moves)!=32:break
        for t in moves:
            side=int(t['side']!=g['candidate_color'])
            e=t.get('evaluation')
            if e is not None and e.get('depth') is not None:depth[side].append(e['depth']);time[side].append(t['think_time_ns']/1e6)
    if len(depth[0])!=32 or len(depth[1])!=32:continue
    vals.append(np.array([np.mean(v) for v in depth+time]))
 a=np.stack(vals);rng=np.random.default_rng(1999387)
 delta=a[:,0]-a[:,1];means=[np.mean(rng.choice(delta,size=len(delta))) for _ in range(4000)]
 out[log.stem]={'pairs':len(a),'depth_candidate_baseline_ms_candidate_baseline':a.mean(0).tolist(),'paired_depth_difference_ci95':np.quantile(means,[.025,.975]).tolist()}
(d/'clock-depth.json').write_text(json.dumps(out,indent=2))

from matches import d,side,duel,base
import matches
def extra(tag):
    if tag.startswith('prev-'):
        arch=tag[5:]
        return (matches.old if arch=='old' else matches.new),d.parent/f'tatara-p-diagnosis-20261119/early-{arch}/nnue.bin'
    return side(tag)
matches.side=extra
for arch in ['new','old']:
    duel('two-epochs-teacher-'+arch,arch+'-13','prev-'+arch,base+90000,200)

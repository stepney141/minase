use minase_trainer::nnue::layerstack::{Checkpoint,Parameter,export};
use std::io::Read;
fn main(){
    let a:Vec<_>=std::env::args().collect();
    let mut c=Checkpoint::read(&a[1]).unwrap();
    let mut f=std::fs::File::open(&a[2]).unwrap();
    for key in Parameter::ALL{
        for x in c.parameters[key].iter_mut(){
            let mut b=[0;4];f.read_exact(&mut b).unwrap();*x=f32::from_le_bytes(b);
        }
    }
    assert_eq!(f.read(&mut [0;1]).unwrap(),0);
    std::fs::write(&a[3],export(&c.parameters,c.settings.scale).unwrap()).unwrap();
}

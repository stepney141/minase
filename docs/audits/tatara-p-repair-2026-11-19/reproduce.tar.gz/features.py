from pathlib import Path
import time,subprocess
d=Path(__file__).resolve().parent
diag=d.parent/'nnue-tatara-framework-and-halfkp-vm'
for tag in ['train','validation']:
    sample=d/f'{tag}.sample'
    while not sample.exists() or sample.stat().st_size!=138*(262144 if tag=='train' else 65536):time.sleep(5)
    with (d/f'{tag}.features.part').open('wb') as out:subprocess.run([diag/'diagnosis-20261119/training/read-after',diag/'train-after/nnue.bin',sample],stdout=out,check=True)
    (d/f'{tag}.features.part').rename(d/f'{tag}.features')

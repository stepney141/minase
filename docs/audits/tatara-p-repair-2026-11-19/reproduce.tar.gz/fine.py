from pathlib import Path
import subprocess,sys,time,json,hashlib,numpy as np,torch
from torch.nn import functional as F
d=Path(__file__).resolve().parent
torch.set_num_threads(2)
torch.backends.cuda.matmul.allow_tf32=False
torch.backends.cudnn.allow_tf32=False
dev=torch.device(sys.argv[4] if len(sys.argv)>4 else 'cuda')
netdir=Path(sys.argv[1]); mode=sys.argv[2]; out=d/sys.argv[3];out.mkdir(exist_ok=True)
source=netdir/'latest.npz'
z=np.load(source)
keys='ft_weights ft_biases psqt l1_weights l1_biases l1_shared_weights l1_shared_biases l2_weights l2_biases l3_weights l3_bias'.split()
weights={k:torch.nn.Parameter(torch.from_numpy(z['weights.'+k].copy()).to(dev)) for k in keys}
def T(a):return torch.as_tensor(a,device=dev)
idx=np.arange(13681); row=idx//144*72+idx%144//12*6+np.minimum(idx%12,11-idx%12)
row[-1]=6840; row=T(row); rev=T(((idx%12>=6)&(idx<13680))[:,None])
def ste(x,rounded):return rounded.detach()+(x-x.detach())
def trunc(x):return ste(x,torch.trunc(x))
def floor(x):return ste(x,torch.floor(x))
def quant(x,scale):
    val=x.double()*scale
    return ste(x*scale,(val.sign()*(val.abs()+0.5).floor()).to(x.dtype))
def forward(f,qat):
    w=weights
    ft=w['ft_weights']; bias=w['ft_biases'].repeat(2); ps=w['psqt']
    if qat:ft=quant(ft,127);bias=quant(bias,127);ps=quant(ps,8128)
    tab=ft[row];tab=torch.where(rev,tab.roll(128,1),tab)
    a=F.embedding_bag(f.reshape(-1,94),tab,mode='sum',padding_idx=13680)+bias
    side=ps[row][f].double().sum(-1);lin=(side[:,0]-side[:,1])/2
    c=a.clamp(0,127 if qat else 1);v=c[:,:128]*c[:,128:]
    w1=(w['l1_weights'].double()+w['l1_shared_weights'].double())
    b1=(w['l1_biases'].double()+w['l1_shared_biases'].double())
    if qat:
        pair=floor(v/128).reshape(-1,256)
        y=F.linear(pair,quant(w1,64).float(),quant(b1,8128).float())
        v=y[:,:15]
        act=torch.cat([floor((v.square()/524288).clamp(0,127)),floor((v/64).clamp(0,127))],1)
        u=F.linear(act,quant(w['l2_weights'],64),quant(w['l2_biases'],8128))
        h=floor((u/64).clamp(0,127))
        raw=h@quant(w['l3_weights'],64)+quant(w['l3_bias'],8128)+y[:,15]
        return trunc((raw.double()+trunc(lin))/12).clamp(-28999,28999).float()
    pair=(v*(127/128)).reshape(-1,256)
    y=F.linear(pair,w1.float(),b1.float())
    v=y[:,:15]
    act=torch.cat([(v.square()*(127/128)).clamp(0,1),v.clamp(0,1)],1)
    h=F.linear(act,w['l2_weights'],w['l2_biases']).clamp(0,1)
    return ((h@w['l3_weights']+w['l3_bias']+y[:,15]+lin)*(8128/12)).float()

def export(path):
    raw=out/'weights.raw'
    with raw.open('wb') as fp:
        for key in keys:weights[key].detach().cpu().numpy().astype('<f4').tofile(fp)
    subprocess.run([d/'export-net',source,raw,path],check=True)
def dataset(tag):
    feat=np.memmap(d/(tag+'.features'),dtype=[('cp','<i4'),('f','<u2',(2,94))],mode='r')['f']
    small=np.memmap(d/(tag+'.sample'),'u1',mode='r').reshape(-1,138)
    cp=small[:,113:117].copy().view('<f4').ravel().copy()
    feat=T(np.minimum(feat,13680).astype(np.int32))
    return feat,cp
def verify(path):
    samp=(d/'validation.sample').read_bytes()[:138*1024]
    (out/'check.sample').write_bytes(samp)
    diag=d.parent/'nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training'
    expected=np.frombuffer(subprocess.check_output([diag/'full-after',path,out/'check.sample']),'<i4')
    with torch.no_grad(): cp=forward(vf[:1024].long(),True).cpu().numpy()
    assert np.array_equal(expected,cp),(np.count_nonzero(cp!=expected),np.max(abs(cp-expected)))
vf,vc=dataset('validation')
export(out/'initial.bin')
assert (out/'initial.bin').read_bytes()==(netdir/'nnue.bin').read_bytes()
verify(out/'initial.bin')
if mode=='test':print('export and integer parity passed');sys.exit(0)
ft,cp=dataset('train')
if 'relabel' in mode:cp[:65536]=np.load(d/'labels.npy')[:,1]
target=torch.sigmoid(T(cp)/679.029296875)
optimizer=torch.optim.AdamW(weights.values(),lr=0.00003,weight_decay=0)
rng=np.random.default_rng(119771);qat='qat' in mode
for epoch in range(2):
    order=rng.permutation(len(cp))
    for idx in np.array_split(order,len(order)//512):
        j=T(idx);optimizer.zero_grad(set_to_none=True)
        val=forward(ft[j].long(),qat)
        loss=F.mse_loss((val/679.029296875).sigmoid(),target[j]);loss.backward();optimizer.step()
        with torch.no_grad():
            for k in keys:
                if k=='psqt' or k=='l3_bias':continue
                m=224/127 if k.startswith('ft_') else 127/128 if k in ('l1_weights','l1_shared_weights') else 127/64
                weights[k].clamp_(-m,m)
            weights['ft_weights'][-1].zero_();weights['psqt'][-1].zero_()
    print('epoch',epoch+1,'last loss',float(loss.detach()),flush=True)
export(out/'nnue.part');verify(out/'nnue.part')
with torch.no_grad():
    val=np.concatenate([forward(vf[s:s+512].long(),True).cpu().numpy() for s in range(0,len(vc),512)])
np.save(out/'val.npy',val)
(out/'nnue.part').rename(out/'nnue.bin')

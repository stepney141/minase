from matches import d,wait,duel,base
from concurrent.futures import ThreadPoolExecutor
import subprocess
py=d.parent.parent/'tools/train/zero/.venv/bin/python'
net='new-6'
def measure():
    duel('first-vs-prior',net,'prior',base+120000,160)
    for a,b in [('first-relabel','first-fp'),('first-qat','first-fp'),('first-relabel-qat','first-fp'),('first-relabel-qat','standard')]:
        duel(a+'-vs-'+b,a,b,base+130000,160)
with ThreadPoolExecutor(1) as pool:
    pending=pool.submit(measure)
    for arm in ['fp','qat','relabel','relabel-qat']:
        if 'relabel' in arm:wait(d/'labels.npy')
        output='first-'+arm
        with (d/(output+'.log')).open('w') as log:
            subprocess.run([py,d/'fine.py',d/net,arm,output],stdout=log,stderr=subprocess.STDOUT,check=True)
    pending.result()

"""Watch the experiment's own active, timed runs and stop that harness on engine errors."""
from pathlib import Path
import time,sys,os,signal,re,json
p=Path(__file__).resolve().parent/'matches'
seen={}
while not (p/'gate-standard-stc.log').exists() or any(p.glob('gate-*.work')) or not (Path(__file__).resolve().parent/'trial.log').read_text().strip().endswith(('H0','H1','pending')):
    for f in p.glob('gate-*.work'):
        d=p/f.stem
        if not (d/'pairs').exists():continue
        mem=seen.setdefault(f.stem,set())
        for q in (d/'pairs').glob('*.json'):
            if q.name in mem:continue
            try:j=json.loads(q.read_text())
            except ValueError:continue
            mem.add(q.name)
            for game in j['games']:
                reason=game['termination']['kind']
                if reason=='forfeit':
                    for proc in Path('/proc').glob('[0-9]*'):
                        try:args=(proc/'cmdline').read_bytes().split(b'\0')
                        except (OSError,PermissionError):continue
                        if b'match' in args and b'run' in args and os.fsencode(d) in args:
                            print('stopping our timed match',f.stem,q.name,reason,flush=True)
                            os.kill(int(proc.name),signal.SIGINT)
                    sys.exit(1)
    time.sleep(15)

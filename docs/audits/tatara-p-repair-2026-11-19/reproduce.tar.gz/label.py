from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess, time,numpy as np
p=Path(__file__).resolve().parent
net=Path('/mnt/synology_nas/minase/nnue/nets/987f060d545c09f0a42b4c668ea8b24cbf83c1770d11d663a94e4b82601274cd.bin')
while not (p/'validation.sample').exists():time.sleep(10)
def run(i):
    subprocess.run([p/'relabel-positions',str(i),net],check=True,cwd=p)
with ThreadPoolExecutor(6) as pool:list(pool.map(run,range(30)))
a=np.vstack([np.loadtxt(f,dtype='i8',ndmin=2) for f in sorted(p.glob('labels-*.txt'))]);a=a[a[:,0].argsort()]
assert np.array_equal(a[:,0],np.arange(65536))
np.save(p/'labels.npy',a)
print('labelled',len(a),'nodes',a[:,2].sum())

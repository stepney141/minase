from matches import best,duel,base,d
cand=best('new');old='old-'+cand.split('-')[1]
duel('matched-duration',cand,old,base+100000,240)

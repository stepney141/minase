from pathlib import Path
import subprocess,time,sys,re,json,os
d=Path(__file__).resolve().parent; root=d.parent.parent
old='a48f03aa35cfa419353739ee001664543536dd71';new='8b853b6655f3c2acfa41677449d2bcc8509dc66c'
runner=root/'target/match-cache'/new/'minase'
standard=Path('/mnt/synology_nas/minase/nnue/nets/987f060d545c09f0a42b4c668ea8b24cbf83c1770d11d663a94e4b82601274cd.bin')
m=d/'matches';m.mkdir(exist_ok=True)
def side(tag):
    if tag=='standard':return old,standard
    if tag=='prior':return new,d.parent/'nnue-tatara-framework-and-halfkp-vm/train-after/nnue.bin'
    return (old if tag.startswith('old-') else new),d/tag/'nnue.bin'
def wait(p):
    while not p.is_file():time.sleep(12)
def duel(name,c,b,seed,pairs,stage='fixed'):
    cmt,cn=side(c);bmt,bn=side(b);wait(cn);wait(bn)
    run=m/name; final=m/(name+'.log'); raw=m/(name+'.work')
    stageargs=['elo','--pairs',str(pairs)] if stage=='fixed' else ['gsprt','--max-pairs',str(pairs)]
    secs={'fixed':'nodes=3000','stc':'time=10000+100','ltc':'time=60000+200'}[stage]
    args=[str(runner),'match','run','--candidate','commit:'+cmt,'--baseline','commit:'+bmt,'--candidate-option','EvalFile='+str(cn),'--baseline-option','EvalFile='+str(bn),'--each',secs,'--rules','JCSA','--candidate-hash',str(32 if stage=='fixed' else 256),'--baseline-hash',str(32 if stage=='fixed' else 256),'--concurrency',str(7 if stage=='fixed' else 12),'--seed',str(seed),'--run-dir',str(run),*stageargs]
    if not final.exists():
        if (run/'manifest.json').exists():raise RuntimeError('Inspect interrupted match '+name)
        (m/(name+'.args.json')).write_text(json.dumps([c,b,args],indent=1))
        with raw.open('w') as log:subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=root)
        raw.rename(final)
    s=final.read_text()
    assert 'engine_failures: illegal_moves=0 crashes=0 timeouts=0 time_forfeits=0 rejected_moves=0' in s,name
    if stage=='fixed':
        counts=json.loads(re.findall(r'^pentanomial: (\[.*\])',s,re.M)[-1]);return sum(i*n for i,n in enumerate(counts))/(4*sum(counts))
    return re.findall('^decision: (.+)',s,re.M)[-1]
base=20261119400000
def selection(arm):
    scores={}
    for sb in [6,13,25,51]:
        name=f'{arm}-{sb}';scores[name]=duel('screen-'+name,name,'standard',base,96)
    best=max(scores,key=scores.get)
    (d/f'selected-{arm}.json').write_text(json.dumps({'best':best,'score':scores},indent=2))
    return best
def best(arm):
    p=d/f'selected-{arm}.json';wait(p);return json.loads(p.read_text())['best']
def trial():
    n=best('new')
    for arm in ['fp','relabel','qat','relabel-qat']:
        wait(d/arm/'nnue.bin')
    # Compare all four fine-tunes with the common starting net and across paired arms.
    for i,(c,b) in enumerate([('fp',n),('relabel','fp'),('qat','fp'),('relabel-qat','relabel'),('relabel-qat','qat')]):
        duel('test-'+c+'-vs-'+b,c,b,base+10000,200)
    participants=[n,'fp','relabel','qat','relabel-qat']
    scores={t:duel('choose-'+t,t,'standard',base+20000,128) for t in participants}
    chosen=max(scores,key=scores.get)
    (d/'final-choice.json').write_text(json.dumps({'best':chosen,'scores':scores},indent=2))
    o=best('old')
    for i,(a,b) in enumerate([(n,o),(n,'prior'),(n,'standard'),(chosen,o),(chosen,'standard'),(chosen,'prior')]):
        name='confirm-'+a+'-vs-'+b;duel(name,a,b,base+30000,240)
    # No background training, relabelling, checkpoint selection or fixed-node testing at this point.
    old_decision=duel('gate-old-stc',o,chosen,base+50000,3000,'stc')
    if old_decision=='H0':
        old_decision=duel('gate-old-ltc',o,chosen,base+60000,3000,'ltc')
    print('old',old_decision,flush=True)
    standard_decision=duel('gate-standard-stc',chosen,'standard',base+70000,3000,'stc')
    print('standard',standard_decision,flush=True)
if __name__=='__main__':
    if sys.argv[1]=='select':
        selection('new');selection('old')
    elif sys.argv[1]=='trial':trial()

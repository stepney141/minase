from matches import d,best,wait,side
from pathlib import Path
import subprocess,numpy as np,json
p=d.parent/'nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training'
val=np.memmap(d/'validation.sample','u1',mode='r').reshape(-1,138)
n=np.bitwise_count(val[:,:18]).sum(1)
games=val[:,126:130].copy().view('<u4').ravel().astype('i8')*2**32+val[:,122:126].copy().view('<u4').ravel()
cp=val[:,113:117].copy().view('<f4').ravel().astype('f8')
outcome=val[:,119]*.5
sig=lambda x:1/(1+np.exp(-x/679.029296875))
nets=['prior',best('new'),best('old'),'standard','fp','qat','relabel','relabel-qat']
scores={}
for tag in nets:
    _,net=side(tag);wait(net)
    cmd=p/('full-before' if tag.startswith('old') or tag=='standard' else 'full-after')
    scores[tag]=np.frombuffer(subprocess.check_output([cmd,net,d/'validation.sample']),'<i4')
    if tag in ['fp','qat','relabel','relabel-qat']: assert np.array_equal(scores[tag],np.load(d/tag/'val.npy')),tag
results={}
for label,sel in [('all',n>=2),('ending',n<=25),('opening',n>=76)]:
    order=np.argsort(games[sel]);g=games[sel][order]
    groups,starts,sizes=np.unique(g,return_index=True,return_counts=True)
    rng=np.random.default_rng(11871)
    vals={tag:np.stack([(sig(sc[sel])-sig(cp[sel]))**2,(sig(sc[sel])-outcome[sel])**2]) for tag,sc in scores.items()}
    diffs={}
    for cand,base in [('relabel','fp'),('qat','fp'),('relabel-qat','qat'),('relabel-qat','relabel')]:
        delta=vals[cand]-vals[base]
        sums=np.add.reduceat(delta[:,order],starts,axis=1)
        means=[]
        for _ in range(500):
            idx=rng.integers(0,len(groups),size=len(groups))
            means.append(sums[:,idx].sum(1)/sizes[idx].sum())
        diffs[cand+' vs '+base]=[delta.mean(1).tolist(),np.quantile(means,[.025,.975],axis=0).tolist()]
    results[label]={'positions':int(sel.sum()),'games':len(groups),'scores':{k:v.mean(1).tolist() for k,v in vals.items()},'differences':diffs}
(d/'metrics.json').write_text(json.dumps(results,indent=2))

from pathlib import Path
import json,numpy as np
from matches import d,m,best
n=best('new');o=best('old')
c=json.loads((d/'final-choice.json').read_text())['best']
def scores(tag):
    r={}
    for f in (m/tag/'pairs').glob('*.json'):
        p=json.loads(f.read_text());k=(p['opening']['seed'], str(p['opening']['moves']))
        if p['category'] is not None:
            assert k not in r;r[k]=p['category']/4
    return r
result={}
for enemy in (o,'standard','prior'):
    a='confirm-'+c+'-vs-'+enemy;b='confirm-'+n+'-vs-'+enemy
    if not (m/(a+'.log')).exists() or not (m/(b+'.log')).exists():continue
    s,t=scores(a),scores(b);keys=sorted(s.keys()&t.keys())
    x=np.array([s[k]-t[k] for k in keys]);rng=np.random.default_rng(48031)
    boot=rng.choice(x,(20000,len(x))).mean(1)*100
    result[enemy]=dict(shared=len(keys),gain_pp=x.mean()*100,ci95_pp=np.quantile(boot,[.025,.975]).tolist(),before_pct=np.mean([t[k] for k in keys])*100,after_pct=np.mean([s[k] for k in keys])*100)
(d/'opponents.json').write_text(json.dumps(result,indent=2));print(result)

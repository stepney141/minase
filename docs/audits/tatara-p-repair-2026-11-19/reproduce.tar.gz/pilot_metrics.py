from pathlib import Path
import numpy as np,json,subprocess
d=Path(__file__).resolve().parent
r=np.memmap(d/'validation.sample','u1',mode='r').reshape(-1,138)
cp=r[:,113:117].copy().view('<f4').ravel().astype('f8')
end=np.bitwise_count(r[:,:18]).sum(1)<=25
y=r[:,119]*.5
sig=lambda x:1/(1+np.exp(-x/679.029296875))
op=d.parent/'nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training/full-after'
out={}
for name in ['new-6','first-fp','first-qat','first-relabel','first-relabel-qat']:
    z=np.frombuffer(subprocess.check_output([op,d/name/'nnue.bin',d/'validation.sample']),'<i4')
    if name!='new-6':assert np.array_equal(z,np.load(d/name/'val.npy'))
    p=sig(z)
    out[name]=[[((p[mask]-act[mask])**2).mean() for act in (sig(cp),y)] for mask in (np.full(len(y),True),end)]
print(json.dumps(out,indent=2))

from pathlib import Path
import sys,subprocess
from concurrent.futures import ThreadPoolExecutor
d=Path(__file__).resolve().parent; repo=Path(sys.argv[1]).resolve()
suffix=sys.argv[2]
docs=[repo/'docs/audits/tatara-p-repair-2026-11-19.md',*sorted((repo/'docs/measurements/adhoc').glob('tatara-repair-*.md'))]
groups=[];current='';prompt='ツールを使わず、初見の人が棋力の比較対象と実験条件を正確に理解できるか、不自然な日本語がないかを推敲し、直すべき点を短く指摘してください。各文書は独立した測定記録または調査報告です。数値や結論は変えません。\n'
for f in docs:
    text=f.name+'\n'+'\n'.join(f'{i}: {line}' for i,line in enumerate(f.read_text().splitlines(),1))+'\n'
    if len((current+text).encode())>85000:
        groups.append(current);current=''
    current+=text
if current:groups.append(current)
def task(item):
    i,body=item
    with (d/f'proofread-{suffix}-{i}.txt').open('w') as out:
        subprocess.run(['agy','-p',prompt+body,'--model','gemini-4-argon-high','--mode','plan'],stdout=out,stderr=subprocess.STDOUT,check=True)
with ThreadPoolExecutor(2) as pool:list(pool.map(task,enumerate(groups)))

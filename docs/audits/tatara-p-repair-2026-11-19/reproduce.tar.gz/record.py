from pathlib import Path
import json,sys,re,math,shlex
d=Path(__file__).resolve().parent; root=d.parent.parent; repo=Path(sys.argv[1]).resolve()
out=repo/'docs/measurements/adhoc'; m=d/'matches'
def title(t):
    names={'standard':'masterの標準ネット','prior':'第2世代の教師で学んだ移行後の最終版','fp':'元の教師値で浮動小数点で学習した新型','relabel':'終盤の教師値を付け直して浮動小数点で学習した新型','qat':'元の教師値で量子化を模擬して学習した新型','relabel-qat':'終盤の教師値を付け直し、量子化を模擬して学習した新型','prev-new':'第2世代の教師で約2.07エポック学んだ新型','prev-old':'第2世代の教師で約2.07エポック学んだ旧型'}
    if t.startswith('first-'):return '約0.94エポックの重みから'+names[t[6:]]
    if t in names:return names[t]
    s=json.loads((d/t/'summary.json').read_text())
    return f'教師30本で約{s["epochs"]:.2f}エポック学んだ'+('旧型' if t.startswith('old-') else '新型')
def elo(x):return 400*math.log10(x/(1-x))
for log in sorted(m.glob('*.log')):
    name=log.stem;s=log.read_text();mf=json.loads((m/name/'manifest.json').read_text())
    a,b,cmd=json.loads((m/(name+'.args.json')).read_text());lines=[]
    h=json.loads(re.findall(r'^pentanomial: (\[.*\])',s,re.M)[-1])
    total,valid,discard=map(int,re.findall(r'^summary: .*? pairs=(\d+) valid_pairs=(\d+) discarded_pairs=(\d+)',s,re.M)[-1])
    assert sum(h)==valid and total==valid+discard
    counts=[0]*5; dis=0
    for path in (m/name/'pairs').glob('*.json'):
        p=json.loads(path.read_text())
        if p['pair_number']>total:continue
        if p['category'] is None:dis+=1
        else:counts[p['category']]+=1
    assert counts==h and dis==discard
    mean=sum(i*x/4 for i,x in enumerate(h))/valid
    se=math.sqrt(sum(x*(i/4-mean)**2 for i,x in enumerate(h)))/valid
    ci=[elo(mean),elo(mean-1.96*se),elo(mean+1.96*se)] if 0<mean-1.96*se<=mean+1.96*se<1 else None
    cond=mf['candidate']['limit']; tc='1手3,000ノード' if 'base_ms' not in cond else f'持ち時間{cond["base_ms"]/1000:g}秒、1手につき{cond["increment_ms"]/1000:g}秒加算'
    readout=f'基準に対する候補の棋力差は{ci[0]:+.1f} Elo、95%信頼区間は{ci[1]:+.1f}〜{ci[2]:+.1f} Eloだった。' if ci else '得点率は'+f'{mean*100:.2f}%だった。'
    dec=re.findall('^decision: (.+)',s,re.M)
    if dec:
        llr=re.findall(r'^llr: (.+)',s,re.M)[-1]
        readout+=f'\n対数尤度比は{llr}、逐次検定の判定は `{dec[-1]}` だった。'
    key='候補選び' if name.startswith(('screen','choose')) else '検証'
    lines=[f'# {title(a)}と{title(b)}の対局','',f'tatara方式への移行で生じたP型評価関数の棋力低下を調べるため、{key}のための対局を行った。','旧型はtatara方式への移行前のP型、新型は移行後のP型を指す。教師30本はmasterの標準ネットの学習に使った30ファイルである。',f'候補は{title(a)}、基準は{title(b)}で、同じ開始局面から先後を入れ替えた2局を1ペアとした。','',f'日本中将棋連盟の規則で双方に{tc}を与え、シード {mf["seed"]} から開始局面を生成した。',f'Intel Core Ultra 7 265KFで{mf["concurrency"]}ペアを並行実行し、両側とも探索は1スレッド、置換表は{mf["hash_mb"]["candidate"]} MBとした。','','| 対局側 | エンジンのコミット | 実行ファイルのSHA-256 | 評価関数のSHA-256 |','|---|---|---|---|']
    for side,jp in [('candidate','候補'),('baseline','基準')]:
        q=mf[side];lines.append(f'| {jp} | `{q["identity"]["hash"][:8]}` | `{q["identity"]["sha256"]}` | `{q["network_sha256"]}` |')
    lines+=['',(f'{total}ペアのうち手数上限に達した対局を含む{discard}ペアを除き、{valid}ペアを集計した。' if discard else f'全{valid}ペアを集計した。'),f'2局合計で候補の得点が順に0、0.5、1、1.5、2点だったペア数は `{h}` で、得点率は{mean*100:.2f}%だった。',readout,f'エンジン異常、時間切れ、着手の拒否はいずれも0件だった。実行時間は{float(re.findall(r"^elapsed: ([0-9.]+) s",s,re.M)[-1]):,.1f}秒だった。','','## 再現手順','',f'本体リポジトリのルートで測定した。対局ハーネスのSHA-256は `b6066b1dee6eea6d8d6d3d1740778e7a0e5c4b387e22486bd8ec3a065c32897d` である。','', '```sh',shlex.join([v.replace(str(root)+'/','') for v in cmd]),'```','']
    if any(t.startswith('first-') or t in ('fp','relabel','qat','relabel-qat') for t in (a,b)):
        epoch='0.94' if any(t.startswith('first-') for t in (a,b)) else '2.05'
        lines.insert(5,f'追加学習したモデルは、教師30本で約{epoch}エポック学んだ新型を出発点とし、訓練集合から抽出した262,144局面を2エポック学んだ。')
        if any('relabel' in t for t in (a,b)):
            lines.insert(6,'終盤の教師値を付け直す条件では、駒が25枚以下の65,536局面をmaster標準ネットで各3,000ノード再探索した。')
    if any(t in ('prev-new','prev-old','prior') for t in (a,b)):
        lines.insert(4,'第2世代の教師は、tatara方式への移行時に新旧を学習させた37ファイルを指す。')
    (out/f'tatara-repair-{name}.md').write_text('\n'.join(lines))

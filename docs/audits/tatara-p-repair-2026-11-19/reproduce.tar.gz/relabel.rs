use minase::eval::Nnue;
use minase::search::{HistoryTables,SearchLimits,SearchSnapshot,TranspositionTable,DEFAULT_THREADS,search};
use minase::training::records::{Reader,Value,encode_board};
use minase_core::{Game,Rules};
use std::{collections::HashMap,env,fs::File,io::{BufReader,BufWriter,Write}};
fn main(){
    let a:Vec<_>=env::args().collect(); let file:u32=a[1].parse().unwrap();
    let input=std::fs::read("train.sample").unwrap();
    let mut requests=HashMap::new();
    for (i,r) in input.chunks_exact(138).take(65536).enumerate(){
        let f=u32::from_le_bytes(r[126..130].try_into().unwrap());
        if f==file{
            let game=u32::from_le_bytes(r[122..126].try_into().unwrap());
            let ply=u16::from_le_bytes(r[120..122].try_into().unwrap());
            assert!(requests.entry(game).or_insert_with(HashMap::new).insert(ply,(i,r)).is_none());
        }
    }
    let net=Nnue::decode(&std::fs::read(&a[2]).unwrap()).unwrap();
    let mut reader=Reader::new(BufReader::new(File::open(format!("books/book-{file:02}.mnsd")).unwrap())).unwrap();
    let mut scores=BufWriter::new(File::create(format!("labels-{file:02}.txt")).unwrap());
    let mut tt=TranspositionTable::new(4).unwrap();
    let limits=SearchLimits::new(None,Some(3000),None,None).unwrap();
    while let Some(decoded)=reader.read_game().unwrap(){
        let rec=decoded.record();
        let Some(mut wanted)=requests.remove(&rec.game_number()) else {continue};
        let mut game=Game::from_position(Rules::JCSA,rec.start_position().clone());
        for (j,e) in rec.entries().iter().enumerate(){
            if let Some((idx,r))=wanted.remove(&(rec.start_ply()+j as u16)){
                let board=encode_board(game.position()).unwrap();
                let mut k=21;
                for (i,&piece) in board.iter().enumerate(){if (r[i/8]>>(i%8))&1!=0{assert_eq!(piece,r[k]);k+=1;}}
                assert_eq!(e.value(),Value::AlphaBeta(i16::from_le_bytes(r[117..119].try_into().unwrap())));
                let snapshot=SearchSnapshot::from_game(&game).unwrap();
                tt.clear();
                let result=search(&net,&snapshot,&limits,DEFAULT_THREADS,&mut tt,&mut HistoryTables::new(DEFAULT_THREADS)).unwrap();
                writeln!(scores,"{} {} {}",idx,result.score,result.nodes).unwrap();
            }
            if wanted.is_empty(){break}
            game.play(e.played_move().unwrap()).unwrap();
        }
        assert!(wanted.is_empty());
    }
    assert!(requests.is_empty());
}

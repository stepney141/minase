from matches import d,wait,best
import subprocess,sys,time
py=d.parent.parent/'tools/train/zero/.venv/bin/python'
wait(d/'validation.features')
previous=d.parent/'tatara-p-diagnosis-20261119/early-new'
with (d/'parity.log').open('w') as log:subprocess.run([py,d/'fine.py',previous,'test','parity','cpu'],stdout=log,stderr=subprocess.STDOUT,check=True)
n=best('new')
wait(d/'labels.npy')
for arm in ['fp','relabel','qat','relabel-qat']:
    if (d/arm/'nnue.bin').exists():continue
    with (d/(arm+'.log')).open('w') as log:subprocess.run([py,d/'fine.py',d/n,arm,arm],stdout=log,stderr=subprocess.STDOUT,check=True)

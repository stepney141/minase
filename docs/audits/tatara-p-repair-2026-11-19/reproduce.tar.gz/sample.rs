use std::{num::NonZeroUsize,path::PathBuf,process::Command};
use minase_trainer::data::SpillStore;
fn main() {
  let dir=PathBuf::from(std::env::current_dir().unwrap());
  let paths:Vec<_>=(0..30).map(|i|dir.join(format!("books/book-{i:02}.mnsd"))).collect();
  let s=SpillStore::create(&paths,None,NonZeroUsize::new(2).unwrap(),&dir,16,262144).unwrap();
  println!("{} {}",s.training_indices_sha256(),s.validation_indices_sha256());
  assert!(Command::new("python").arg("samples.py").env("MINASE_TATARA_SPILL",s.directory()).status().unwrap().success());
}

from pathlib import Path
import os, numpy as np
d=Path(__file__).resolve().parent
s=Path(os.environ['MINASE_TATARA_SPILL'])
rng=np.random.default_rng(741951)
for label,n in [('train',524288),('validation',65536)]:
    files=[s/f'{label}-{i}.bin' for i in range(30)]
    sizes=[f.stat().st_size//138 for f in files]
    idx=np.sort(rng.choice(sum(sizes),n,replace=False))
    items=[]; off=0
    for f,size in zip(files,sizes):
        a=np.memmap(f,'u1',mode='r',shape=(size,138))
        items.append(a[idx[(idx>=off)&(idx<off+size)]-off])
        off+=size
    a=np.concatenate(items)
    if label=='train':
        pieces=np.bitwise_count(a[:,:18]).sum(1)
        keep=np.concatenate([rng.choice(np.flatnonzero(pieces<=25),65536,False),rng.choice(np.flatnonzero(pieces>25),196608,False)])
        a=a[keep]
    a.tofile(d/f'{label}.sample')
    print(label,sum(sizes),len(a),flush=True)

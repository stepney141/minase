from pathlib import Path
import subprocess, json, shutil
d=Path(__file__).resolve().parent
assert not (d/'new-51').exists() and not (d/'old-train').exists()
books=[r[2] for r in json.loads((d/'books.json').read_text())]
args=['systemd-run','--user','--scope','-p','MemoryMax=16G','-p','MemorySwapMax=0','--','nice','-n','10',str(d.parent/'worktrees/tatara-before-a48f03aa/target/release/minase-trainer'),'nnue','train','--base',str(d.parent/'nnue-generation-reset/base.bin'),'--feature-set','P','--width','256','--head','pairwise-l16-l32','--data',*books,'--output-dir',str(d/'old-train'),'--lambda','1','--batch','16384','--batches-per-superbatch','763','--superbatches','6','--lr-schedule','cosine:512:0.027','--validation-superbatches','6','--seed','1','--device','cuda','--threads','3']
with (d/'train-old-6.log').open('w') as log:subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
assert not (d/'new-51').exists()
shutil.copytree(d/'old-train',d/'old-6.part')
(d/'old-6.part').rename(d/'old-6')

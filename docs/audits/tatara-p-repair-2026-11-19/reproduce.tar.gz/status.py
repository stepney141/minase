from pathlib import Path
import json
p=Path(__file__).resolve().parent
for phase in ['new','old']:
    f=p/(phase+'-train/training.jsonl')
    if f.exists():
        try:
            j=json.loads(f.read_text().splitlines()[-1]);print(phase,j['superbatch'],round(j['epochs'],2))
        except (ValueError,IndexError): pass
for name in ['sample','features','label','parity','run-fine','pipeline','selection','trial','fp','qat','relabel','relabel-qat']:
    f=p/(name+'.log')
    if f.exists() and f.stat().st_size:print(name,f.read_text(errors='replace').splitlines()[-1][:190])
for f in p.glob('selected-*.json'):print(f.name,json.loads(f.read_text())['best'])
logs=sorted((p/'matches').glob('*.log'),key=lambda f:f.stat().st_mtime)
for f in logs[-3:]:print(f.stem,[x for x in f.read_text().splitlines() if x.startswith(('elo:','decision:'))][-1:])
for f in (p/'matches').glob('*.work'):
    print(f.stem,'saved pairs',len(list((p/'matches'/f.stem/'pairs').glob('*.json'))))

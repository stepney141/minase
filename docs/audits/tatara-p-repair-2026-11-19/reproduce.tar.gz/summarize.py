from pathlib import Path
import json,re,sys,hashlib,tarfile,subprocess
from matches import d,m
repo=Path(sys.argv[1]).resolve()
subprocess.run([sys.executable,d/'record.py',repo],check=True)
report=repo/'docs/audits/tatara-p-repair-2026-11-19.md'
assets=report.with_suffix('');assets.mkdir(exist_ok=True)
dist=assets/'reproduce.tar.gz'
files=[p for spec in ['*.py','*.rs','build.sh','reproduce.txt','protocol.txt','books.json','sample.log','label.log','pilot-metrics.json','first-metrics.json','two-snapshots.json','opponents.json','clock-depth.json','metrics.json','*choice.json','selected-*.json','matches/*.args.json','matches/*/manifest.json','matches/*/stop.json','new-*/summary.json','old-*/summary.json'] for p in d.glob(spec) if 'smoke' not in p.name]
with tarfile.open(dist,'w:gz') as tar:
    for p in sorted(set(files)):tar.add(p,arcname=p.relative_to(d),recursive=False)
def label(t):
 labels={'standard':'master標準','prior':'第2世代の教師で学んだ新型の最終版','fp':'実数（対照）','relabel':'終盤再探索','qat':'量子化を模擬','relabel-qat':'終盤再探索と量子化を併用','prev-new':'第2世代の教師・新型早期版','prev-old':'第2世代の教師・旧型早期版'}
 if t in labels:return labels[t]
 if t.startswith('first-'):return '新型0.94エポックから'+labels[t[6:]]
 j=json.loads((d/t/'summary.json').read_text());return ('旧型' if t.startswith('old-') else '新型')+f'{j["epochs"]:.2f}エポック'
def rows(pattern):
 out=[]
 for f in sorted(m.glob(pattern),key=lambda x:[int(v) if v.isdigit() else v for v in re.split(r'(\d+)',x.name)]):
    s=f.read_text();a,b,_=json.loads((m/(f.stem+'.args.json')).read_text());v=re.search(r'valid_pairs=(\d+) discarded_pairs=(\d+)\n',s)
    e=re.findall(r'^elo: estimate=([^ ]+) ci95=\[([^,]+), ([^\]]+)\]',s,re.M)
    count=json.loads(re.findall(r'^pentanomial: (.+)',s,re.M)[-1]);valid=sum(count)
    effect=f'{float(e[-1][0]):+.1f}［{float(e[-1][1]):+.1f}, {float(e[-1][2]):+.1f}］' if e else re.findall(r'^decision: (.+)',s,re.M)[-1]
    link='../measurements/adhoc/tatara-repair-'+f.stem+'.md'
    out.append(f'| {label(a)} | {label(b)} | {valid} | [{effect}]({link}) |')
 return out
parts=['# tatara方式のP型評価関数の棋力を回復する実験','',
'2026年11月19日に、移行前のP型 `a48f03aa` と移行後のP型 `8b853b66` を使って、教師と学習期間、終盤の教師値、学習時の量子化が棋力に及ぼす効果を調べ始めた。',
'元の短時間対局では同じ第2世代の教師37ファイルで育てた移行前のP型が移行後のP型を64.4 Elo上回り、固定ノード数では別の教師で育てたmasterの標準ネットが移行後のP型を342.0 Elo上回った。',
'旧型と新型はいずれも、駒種と升を入力に取る差分更新型のニューラルネットワーク（NNUE）である。旧型は移行前の構造、新型はtataraのLayerStackを使う。以下では、同じ教師で学び直した旧型と、保存済みのmaster標準ネットをそれぞれ対戦相手とした。[元の調査報告](tatara-p-regression-2026-11-19.md)','',
'## 教師と学習期間','',
'標準ネットの学習に使った教師ファイル30本の222,636局を全て用い、訓練79,458,082局面と検証4,153,303局面に対局単位で分けた。',
'学習率を余弦曲線に沿って減らす期間390,656更新、勝率の尺度679.0293センチポーン、バッチ16,384局面、乱数シード1を新旧で揃えた。',
'約0.94、2.05、3.93、8.02エポック（順に4,578、9,919、19,075、38,913更新）の重みを保存し、両型に同じ開始局面と1手3,000ノードの探索予算を与えて標準ネットと対局させた。',
'候補選びには96ペアの得点率を使い、同率なら更新数が少ない方を選ぶ。以下の表で棋力差は左の候補から見たElo、角括弧は各条件での95%信頼区間を表す。','']
table=['| 候補 | 相手 | 有効ペア | 棋力差または逐次検定の判定 |','|---|---|---:|---|']
parts+=table+rows('screen-*.log')+rows('first-vs-prior.log')+rows('two-epochs*.log')+rows('first-matched-duration.log')+rows('matched-duration.log')
parts+=['','全教師を使い、学習期間を約2エポックに揃えると、標準ネットと同じ教師から学んだ新型は第2世代の教師で学んだ新型に+126.0 Elo、旧型同士でも同じ比較で+121.1 Eloだった。教師の世代を替えると局面と探索値の両方が変わるため、両者の寄与はこの対局から分離できない。','同じ30ファイルを使った新旧のモデルは訓練局面と検証局面それぞれの通し番号のSHA-256が一致した。探索用駒価値は両型ともv0の設定とし、標準ネットとの対局では標準ネット自身の重みと駒価値を使った。']
parts+=['','## 終盤の再探索と量子化を模擬した学習','',
'訓練から抽出した262,144局面のうち、駒が25枚以下の65,536局面に対して、保存棋譜から手順を再現し、局面ごとに置換表と履歴を初期化してmasterの標準ネットに3,000ノードを読ませた。',
'各局面の元の教師値、または終盤だけを再探索値へ替えた教師値を用いた。各条件について通常の実数計算と、対局用ネットの丸め、切り捨て、飽和を順伝播に取り入れた学習を比較した。',
'4条件とも同じ初期重みを使い、抽出した262,144局面を同じ順で2エポック追加学習した。追加学習のバッチは512局面、AdamWの学習率は0.00003で、重み減衰は使わなかった。',
'以下の対局はすべて1手3,000ノードとした。表中に0.94エポックと明記したモデル以外は、約2.05エポックの新型から追加学習した。','']
parts+=table+rows('first-*-vs-*.log')+rows('test-*.log')
if (d/'two-snapshots.json').exists():
    combined=json.loads((d/'two-snapshots.json').read_text())
    parts+=['','0.94エポックと2.05エポックの両方で、元の教師値を使って実数で追加学習したモデルを対照とした。各時点の得点率に等しい重みを与え、時点ごとに先後を入れ替えた対局ペアを20,000回復元抽出して95%信頼区間を求めた。','', '| 対照からの変更 | 2時点の有効ペア数 | 棋力差と95%信頼区間（Elo） |','|---|---:|---:|']
    for a,x in combined.items():
        parts.append(f'| {label(a)} | {x["n"][0]}、{x["n"][1]} | {x["elo"]:+.1f}［{x["ci95"][0]:+.1f}, {x["ci95"][1]:+.1f}］ |')
    parts+=['','区間はこの2つの初期重みと対照についての対局誤差を表す。いずれの変更でも棋力の改善は確認できなかった。']

if (d/'metrics.json').exists():
    ending=json.loads((d/'metrics.json').read_text())['ending']
    a=ending['differences']['relabel vs fp'];b=ending['differences']['relabel-qat vs qat']
    parts+=['',f'追加学習に使わなかった検証65,536局面のうち、残り25枚以下の{ending["positions"]:,}局面で、整数評価から予測した勝率と実際の終局得点の二乗誤差を調べた。',f'約2.05エポックの重みから実数で追加学習した場合、終盤の教師値を付け直すと二乗誤差は{ending["scores"]["fp"][1]:.7f}から{ending["scores"]["relabel"][1]:.7f}へ下がった。差は{a[0][1]:+.7f}で、対局単位で500回復元抽出した95%信頼区間は{a[1][0][1]:+.7f}〜{a[1][1][1]:+.7f}だった。', '終盤の勝敗予測は改善したが、上の対局では通常の追加学習に対する棋力の改善は確認できなかった。追加学習した4本について、学習側で求めた整数評価と、書き出した重みを対局エンジンで読んで求めた評価は65,536局面で全件一致した。']
parts+=['','## 候補の選択と独立な対局','',
'追加学習を行わない新型と、4条件で追加学習した新型を128ペアで標準ネットと比較し、得点率が最大の候補を選ぶ。確認用には選択に使っていない開始局面を用いる。','']
parts+=table+rows('choose-*.log')
parts+=['','候補を選んだ後、その候補と追加学習前の新型を、同じ3つの相手と独立の開始局面で比較した。','']
parts+=table+rows('confirm-*.log')
if (d/'opponents.json').exists():
    opponents=json.loads((d/'opponents.json').read_text())
    parts+=['','独立の確認対局では、同じ相手、同じ開始局面を用いて、追加学習前後の新型の得点率を比較した。両条件で有効な開始局面を対にして20,000回復元抽出した。','','| 対戦相手 | 共通の有効ペア数 | 追加学習前の得点率 | 終盤再探索で追加学習した後の得点率 | 変化と95%信頼区間（ポイント） |','|---|---:|---:|---:|---:|']
    for tag,v in opponents.items():
        parts.append(f'| {label(tag)} | {v["shared"]} | {v["before_pct"]:.2f}% | {v["after_pct"]:.2f}% | {v["gain_pp"]:+.2f}［{v["ci95_pp"][0]:+.2f}, {v["ci95_pp"][1]:+.2f}］ |')
    parts+=['','同じ教師で育てた旧型に対しては得点率が上がった。保存済みの標準ネットに対する得点率は、追加学習の前後でほぼ同じだった。この比較には追加学習そのものの効果も含まれる。']
parts+=['','## 持ち時間を揃えた対局','',
'同じ教師で学んだ旧型を候補、修整後の新型を基準として0 Eloと+10 Eloの仮説を比べる。短時間対局と長時間対局の両方で旧型の+10 Elo仮説が退けられた場合に載せ替えの条件を満たす。',
'標準ネットとの比較は、2026年11月19日16時28分、標準ネットとの時間制御対局を始める前に短時間対局までと定めた。その後、標準ネット戦は開始前に取りやめた。短時間対局は持ち時間10秒・1手0.1秒加算、長時間対局は持ち時間60秒・1手0.2秒加算とした。表のH0は候補と基準が同等という仮説を、H1は候補が10 Elo強いという仮説を逐次検定が選んだことを表す。[載せ替えの設計書](../plans/archived/nnue-tatara-framework-and-halfkp-vm.md)・[棋力測定の手順](../guides/sprt.md)','']
parts+=table+rows('gate-*.log')
parts+=['',
'## 再現資料','',
'教師の変換、モデルの学習、終盤の再探索、量子化を模擬した学習、および全対局の実行条件を保存した。最終候補の重みは測定機の本体リポジトリにある `data/tatara-p-repair-20261119/relabel/nnue.bin` で、SHA-256は `3c771b7c52b3affae41cf469fe170de1c09339a4dd8fe7c6631b2c2afe0390f2` である。[再現用コードと測定条件](tatara-p-repair-2026-11-19/reproduce.tar.gz)','']
if (d/'final-choice.json').exists():
    winner=json.loads((d/'final-choice.json').read_text())['best']
    core=[f'新旧とも学習量を約2.05エポックとしたモデルが候補選びで最も高い得点率を示した。最終候補には、約2.05エポックの新型から、終盤の教師値を付け直して浮動小数点で追加学習したモデルを選んだ。']
    if len(rows('confirm-relabel-*.log'))==3:
        core+=['選択から独立した1手3,000ノードの240ペアでは、最終候補は修整前の新型に+385.8 Elo、同じ教師で育てた旧型に+55.5 Elo、masterの標準ネットに−47.3 Eloだった。']
    for tag,description,positive in [('old','同じ教師で育てた旧型との比較','H0'),('standard','masterの標準ネットとの比較','H1')]:
        for stage,word in [('stc','短時間'),('ltc','長時間')]:
            f=m/f'gate-{tag}-{stage}.log'
            if not f.exists():continue
            raw=f.read_text();value=re.findall(r'^decision: (.+)',raw,re.M)[-1]
            n=re.findall(r'^summary: .*? valid_pairs=(\d+)',raw,re.M)[-1]
            thelink=f'../measurements/adhoc/tatara-repair-gate-{tag}-{stage}.md'
            core+=[f'{description}では{word}対局の有効{int(n):,}ペアで `{value}` と判定した。[{word}対局の記録]({thelink})']
    old_ltc=m/'gate-old-ltc.log';std_stc=m/'gate-standard-stc.log'
    verdict=lambda path:re.findall(r'^decision: (.+)',path.read_text(),re.M)[-1]
    if old_ltc.exists() and verdict(old_ltc)=='H0':
        core+=['短時間と長時間の両方で、同じ教師で育てた旧型が修整版を10 Elo上回るという仮説は退けられた。したがって、この教師と重みの組について、載せ替えによる棋力低下は親計画の許容幅に収まったと判定した。']
    if old_ltc.exists() and verdict(old_ltc)=='H1':
        core+=['長時間対局では旧型が優位で、載せ替えの許容条件は満たさなかった。']
    if old_ltc.exists() and verdict(old_ltc)=='pending':
        core+=['長時間対局は規定の上限で判定保留となった。旧型に対して載せ替えの条件を満たすかは確定しなかった。']
    if std_stc.exists() and verdict(std_stc)=='pending':
        core+=['標準ネットとの短時間対局は上限で判定保留となった。']
    if std_stc.exists() and verdict(std_stc)=='H0':
        core+=['短時間対局では修整版がmasterの標準ネットより10 Elo強いという仮説が退けられ、標準ネットの置き換え基準を満たさなかった。']
    if std_stc.exists() and verdict(std_stc)=='H1':
        core+=['標準ネットとの短時間対局では修整版が優位だった。長時間対局での対標準ネットの棋力は未測定である。']
    core+=['']
    parts[6:6]=core
if (m/'gate-old-ltc/stop.json').exists():
    parts[6:6]=['2026年11月19日23時24分、利用者の指示で旧型との長時間対局を中断した。短時間対局は設計書の基準を満たしたが、長時間対局の判定がないため、載せ替えによる棋力低下が許容幅に収まったかは確定していない。標準ネットとの時間制御対局は開始前に取りやめた。','']
    k=parts.index('## 再現資料')
    parts[k:k]=['旧型との長時間対局は利用者指示で中断・判定なしとした。確定した1,128ペアの棋譜を保存した。開始局面の番号順にそろった先頭1,108ペアのうち、手数上限による23ペアを除いた1,085ペアが逐次検定に入った。旧型のペア得点を0点から2点まで0.5点刻みで数えると223、53、531、51、227ペアで、中断時の対数尤度比は−0.827だった。並列実行により欠番より先に終了した20ペアは保存のみとした。','SIGINTで対局を止めたため、実行ディレクトリの `summary.json` には起動中を示す最後の値が残っている。中断理由と保存数は同じディレクトリの `stop.json` に記録した。','教師局面を抽出する棋譜の数と、検証損失に基づく早期終了については、その後の独立した実験で調べた。[教師の多様性と学習期間の測定](../measurements/adhoc/tatara-p-generalization.md)・[学習手順](../guides/nnue-training.md)','']
elif not (m/'gate-standard-stc.log').exists():
    parts[2:2]=['持ち時間を揃えた対局が進行中である。','']
report.write_text('\n'.join(parts))

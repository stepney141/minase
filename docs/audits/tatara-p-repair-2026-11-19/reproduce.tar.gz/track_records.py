from pathlib import Path
import subprocess,sys,time
d=Path(__file__).resolve().parent; seen=set()
while True:
    done={p.stem for p in (d/'matches').glob('*.log')}
    if done!=seen:
        subprocess.run([sys.executable,d/'summarize.py',d.parent/'worktrees/nnue-tatara-framework-and-halfkp-vm'],check=True)
        seen=done
    if len((d/'trial.log').read_text().strip().splitlines())==2 and (d/'trial.log').read_text().splitlines()[-1].startswith('standard '): break
    time.sleep(25)

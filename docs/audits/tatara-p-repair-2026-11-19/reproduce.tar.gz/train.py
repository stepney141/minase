from pathlib import Path
import sys,subprocess,struct,numpy as np,shutil,json,hashlib
d=Path(__file__).resolve().parent
data=d.parent
books=d/'books'
books.mkdir(exist_ok=True)
original=sorted((data/'nnue-lr-schedule-gen').glob('generated-*.bin'))
assert len(original)==30
manifest=[]
for i,f in enumerate(original):
    b=bytearray(f.read_bytes())
    orig=hashlib.sha256(b).hexdigest()
    assert b[:8]==b'MNSD'+struct.pack('<I',2)
    ng,ne=struct.unpack_from('<QQ',b,136)
    b[4]=3
    p=152
    for j in range(ng):
        n=struct.unpack_from('<I',b,p+10)[0]
        arr=np.frombuffer(b,'u1',offset=p+161,count=n*7).reshape(n,7)
        assert not arr[:,5:].any() and not (arr[:,4]>=16).any()
        a=arr[:,4];a[:]=(a&3)|((a&12)<<1)
        p+=161+n*7
    assert p==len(b)
    out=books/f'book-{i:02d}.mnsd'
    out.write_bytes(b)
    manifest.append([str(f),orig,str(out),hashlib.sha256(b).hexdigest(),ng,ne])
(d/'books.json').write_text(json.dumps(manifest,indent=1))
books=sorted(books.glob('*.mnsd'))
for arch in ['new','old']:
    if arch=='new':
        bin=data/'worktrees/tatara-after-8389b160/target/release/minase-trainer'
        opts=['layerstack','--rules','JCSA','--teacher-cp-per-logit','679.029296875']
    else:
        bin=data/'worktrees/tatara-before-a48f03aa/target/release/minase-trainer'
        opts=['--base',str(data/'nnue-generation-reset/base.bin'),'--feature-set','P','--width','256','--head','pairwise-l16-l32']
    work=d/(arch+'-train')
    for sb in [6,13,25,51]:
        target=d/f'{arch}-{sb}'
        if (target/'nnue.bin').exists(): continue
        args=['systemd-run','--user','--scope','-p','MemoryMax=20G','-p','MemorySwapMax=0','--','nice','-n','10',str(bin),'nnue','train',*opts,'--data',*map(str,books),'--output-dir',str(work),'--lambda','1','--batch','16384','--batches-per-superbatch','763','--superbatches',str(sb),'--lr-schedule','cosine:512:0.027','--validation-superbatches',str(6),'--seed','1','--device','cuda','--threads','3']
        if sb!=6:args+=['--resume',str(work)]
        with (d/f'train-{arch}-{sb}.log').open('w') as log:subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
        temp=d/f'{arch}-{sb}.part'
        shutil.copytree(work,temp)
        temp.rename(target)

from matches import m,d
import numpy as np,re,json
rng=np.random.default_rng(714933);report={}
def h(t):return np.array(json.loads(re.findall(r'^pentanomial: (.+)',(m/(t+'.log')).read_text(),re.M)[-1]))
def rate(t):return t@(np.arange(5)/4)/t.sum(axis=-1)
def elo(x):return 400*np.log10(x/(1-x))
for mod in ['relabel','qat','relabel-qat']:
    counts=[h('first-'+mod+'-vs-first-fp'),h('test-'+mod+'-vs-fp')]
    p=np.mean([rate(x) for x in counts])
    vals=[rate(rng.multinomial(x.sum(),x/x.sum(),size=20000)) for x in counts]
    report[mod]={'n':[int(x.sum()) for x in counts],'elo':float(elo(p)),'ci95':elo(np.quantile(np.mean(vals,axis=0),[.025,.975])).tolist()}
(d/'two-snapshots.json').write_text(json.dumps(report,indent=2));print(report)

2026年11月19日　tatara P型の学習期間、対局数、終盤教師の比較

このアーカイブをminase本体の data/tatara-p-generalization-20261119/ に展開する。
以下は新しく展開した作業ディレクトリから実行する。reference/ は測定時の記録である。
教師とチェックポイントは大きいため別置きとしている。前回の修整実験の記録
docs/audits/tatara-p-repair-2026-11-19.md と docs/audits/tatara-p-repair-2026-11-19/reproduce.tar.gz に従い、
data/tatara-p-repair-20261119/ に教師30本、new-6、new-13、new-25、new-51、fp の各モデル、訓練・検証標本と読込器を用意する。
reference/networks.sha256 のパスは data/ からの相対パスである。学習後に data/ 直下で sha256sum -c に渡して照合する。
reference/runs/ の config.json には入力ファイル、学習引数、順列の検査に使うハッシュがある。
Pythonの計算にはNumPy 2以降、終盤の追加学習には前回と同じPyTorchとCUDAを使う。

1. 作業ツリー data/worktrees/nnue-tatara-framework-and-halfkp-vm/ で次を実行する。

   cargo build --release -p minase-trainer

2. 展開先に戻り、次の順に学習する。学習や対局の出力には新しいディレクトリを用いる。
   diversity.sh は2通りの方法で抽出した局面を使った学習を、replay_extra.sh は局面数を揃えた比較、
   学習率の減衰、検証による停止、終盤の追加学習および教師30本の最良時点を再現する。
   教師30本の再開には前回の学習器 data/worktrees/tatara-after-8389b160/ のビルド済み学習器を使用する。

   bash diversity.sh
   bash replay_extra.sh

3. 教師の相関、以前の候補比較の信頼区間、整数推論器での誤差を求める。
   complete_validation.py は検証対局から全適格局面を展開する。
   all_metrics.py は元の65,536局面との照合を済ませた後で全件を集計する。

   python autocorrelation.py ../tatara-p-repair-20261119/books > correlation.json
   python paired_screen.py . > screening.json
   python validation.py . epochs > epochs.jsonl
   python validation.py . small > small.jsonl
   python complete_validation.py .
   python all_metrics.py .

4. 次の各比較を開始局面の先後を入れ替えて実行する。エンジンは親リポジトリの
   target/match-cache/8b853b6655f3c2acfa41677449d2bcc8509dc66c/minase を使う。

   for run in matched-volume-match diversity-match schedule-match selection-match ending-match full-vs-match-choice full-vs-late full-vs-late-confirm; do
       python duel.py "$run" > "$run.log" 2>&1 || exit 1
   done

   reference/matches/ の manifest.json にはエンジン、重み、シード、探索条件を、
   pairs.jsonl には開始局面の手順、組ごとの得点区分、各局の終了理由を収録した。
   得点区分0、1、2、3、4は、候補が2局で得た合計0、0.5、1、1.5、2点に対応する。
   screen-new-* は元の候補比較で、同じ開始局面の同じ相手に対する得点率を比較できる。

5. 学習曲線の図はMatplotlibとNoto Sans CJK JPを用いて描く。

   python curves.py . curves.png

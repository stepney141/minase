"""Check the archived sample and compute losses and residual correlations on every validation position."""
import json
from pathlib import Path
import subprocess
import sys
import numpy as np

work = Path(sys.argv[1]).resolve()
archive = work.parent/'tatara-p-repair-20261119'
reader = work.parent/'nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training/full-after'
sample = work/'held-out/validation.sample'
records = np.memmap(sample,'u1',mode='r').reshape(-1,138)
assert len(records)==4153303
def column(data, offset, dtype):
    return data[:,offset:offset+np.dtype(dtype).itemsize].copy().view(dtype).ravel()
def ids(data):
    return (column(data,126,'<u4').astype('i8')<<32) + column(data,122,'<u4')
def keys(data):
    return ids(data)*65536+column(data,120,'<u2')
key=keys(records)
assert (np.diff(key)>0).all()
subset=np.memmap(archive/'validation.sample','u1',mode='r').reshape(-1,138)
idx=np.searchsorted(key,keys(subset))
# The last 8 bytes store the global position index, which changes when training games are omitted.
assert np.array_equal(records[idx,:130],subset[:,:130])
ids_full=ids(records)
games,group,counts=np.unique(ids_full,return_inverse=True,return_counts=True)
end=np.bitwise_count(records[:,:18]).sum(1)<=25
outcome=records[:,119]*0.5
def prob(x):return 1/(1+np.exp(-x.astype('f8')/679.029296875))
teacher=prob(column(records,113,'<f4'))
def score(folder):
    path=work/'held-out'/(folder.name+'.cp')
    if not path.exists():
        temp=path.with_suffix('.tmp')
        with temp.open('wb') as out:
            subprocess.run([reader,folder/'nnue.bin',sample],stdout=out,check=True)
        assert temp.stat().st_size==4*len(records)
        temp.rename(path)
    data=np.memmap(path,dtype='<i4',mode='r')
    if folder in (work/'endgame',archive/'fp'):
        assert np.array_equal(data[idx],np.load(folder/'val.npy'))
    return prob(data)
def summary(a,b,sel):
    n=np.bincount(group[sel],minlength=len(games))
    delta=np.array([np.bincount(group[sel],weights=((a[sel]-target[sel])**2-(b[sel]-target[sel])**2),minlength=len(games)) for target in (teacher,outcome)])
    valid=n>0
    n=n[valid];delta=delta[:,valid]
    rng=np.random.default_rng(191119)
    boot=[]
    for _ in range(2000):
        j=rng.integers(len(n),size=len(n))
        boot.append(delta[:,j].sum(1)/n[j].sum())
    def losses(x):return [np.mean((x[sel]-t[sel])**2) for t in (teacher,outcome)]
    return dict(positions=int(n.sum()),games=len(n),candidate=losses(a),baseline=losses(b),delta=list(delta.sum(1)/n.sum()),ci95=np.quantile(boot,[.025,.975],axis=0).T.tolist())
def report(a,b):
    return {name:summary(a,b,sel) for name,sel in [('all',np.ones(len(end),bool)),('end',end),('other',~end)]}
mix,fp=score(work/'endgame'),score(archive/'fp')
results={'mixed vs pure':report(mix,fp)}
print(json.dumps(results),flush=True)
chosen=score(work/'full-selected')
late=score(archive/'new-51')
results['selected vs late']=report(chosen,late)
# Compare correlations of prediction errors with those of the teacher signal.
error=(chosen-teacher)*np.where(records[:,18]==0,1,-1)
error-= (np.bincount(group,weights=error)/counts)[group]
corr={}
for lag in (1,2,8,16,32):
    j=np.searchsorted(key,key+lag)
    i=np.flatnonzero(j<len(key));j=j[i]
    take=(key[i]+lag==key[j]) & (group[i]==group[j])
    a,b=error[i[take]],error[j[take]]
    corr[lag]=[len(a),np.corrcoef(a,b)[0,1]]
results['residual correlations']=corr
(work/'complete-metrics.json').write_text(json.dumps(results,indent=2)+'\n')

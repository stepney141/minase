"""Correlate eligible search targets h plies apart after centering each game."""
import json
from pathlib import Path
import struct
import sys
import numpy as np

lags = (1, 2, 8, 16, 32)
sums = np.zeros((len(lags), 6))
eligible = games = 0
for book in sorted(Path(sys.argv[1]).glob('*.mnsd')):
    data = book.read_bytes()
    assert data[:8] == b'MNSD\x03\0\0\0' and data[112] == 0
    ng, ne = struct.unpack_from('<QQ', data, 136)
    games += ng
    cursor = 152
    offsets = []
    for game in range(ng):
        n, = struct.unpack_from('<I', data, cursor+10)
        offsets.append((cursor+161, n))
        cursor += 161 + n*7
    assert cursor == len(data) and sum(n for _, n in offsets) == ne
    records = np.concatenate([np.frombuffer(data, 'u1', n*7, p).reshape(n,7) for p,n in offsets])
    assert not records[:,5:].any()
    ids = np.repeat(np.arange(ng), [n for _, n in offsets])
    plies = np.arange(ne) - np.repeat(np.cumsum([0] + [n for _,n in offsets[:-1]]), [n for _,n in offsets])
    keep = (records[:,4] & 15) == 0
    eligible += int(keep.sum())
    cp = records[:,2:4].copy().view('<i2').ravel().astype('f8')
    x = 1/(1+np.exp(-cp * (1 - 2*(plies % 2)) / 679.029296875))
    total = np.bincount(ids, weights=x*keep, minlength=ng)
    count = np.bincount(ids, weights=keep, minlength=ng)
    x -= (total / np.maximum(count, 1))[ids]
    for i, h in enumerate(lags):
        pair = (ids[h:]==ids[:-h]) & keep[h:] & keep[:-h]
        a,b = x[:-h][pair],x[h:][pair]
        sums[i] += [len(a), a.sum(), b.sum(), (a*a).sum(), (b*b).sum(), (a*b).sum()]
def corr(row):
    n,a,b,aa,bb,ab = row
    return (ab-a*b/n)/np.sqrt((aa-a*a/n)*(bb-b*b/n))
print(json.dumps(dict(games=games, eligible=eligible, lags={h:[int(row[0]),corr(row)] for h,row in zip(lags,sums)}), indent=2))

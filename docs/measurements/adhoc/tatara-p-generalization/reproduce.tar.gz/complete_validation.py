"""Materialize only held-out games, preserving teacher headers, numbers and order."""
from pathlib import Path
import struct
import subprocess
import sys
work = Path(sys.argv[1]).resolve()
archive = work.parent/'tatara-p-repair-20261119'
dest = work/'held-out'
books = dest/'books'
books.mkdir(parents=True)
mask = 2**64 - 1
def validation(seed,number):
    x = seed ^ ((number*0x9E3779B97F4A7C15) & mask)
    x = ((x ^ x>>30)*0xBF58476D1CE4E5B9) & mask
    x = ((x ^ x>>27)*0x94D049BB133111EB) & mask
    return (x ^ x>>31)%20 == 0
for source in sorted((archive/'books').glob('*.mnsd')):
    raw=source.read_bytes()
    seed,ng,entries=struct.unpack_from('<QQQ',raw,128)
    new=bytearray(raw[:152])
    cursor=152
    games=items=0
    for _ in range(ng):
        number,=struct.unpack_from('<I',raw,cursor)
        n,=struct.unpack_from('<I',raw,cursor+10)
        end=cursor+161+7*n
        if validation(seed,number):
            new.extend(raw[cursor:end])
            games+=1
            items+=n
        cursor=end
    assert cursor==len(raw)
    struct.pack_into('<QQ',new,136,games,items)
    (books/source.name).write_bytes(new)
# The archived Rust reader calls samples.py while its verified spill store is open.
(dest/'samples.py').write_text("""
from pathlib import Path
import os,shutil
spill=Path(os.environ['MINASE_TATARA_SPILL'])
with Path('validation.sample').open('xb') as target:
    for i in range(30):
        assert (spill/f'train-{i}.bin').stat().st_size == 0
        with (spill/f'validation-{i}.bin').open('rb') as chunk:
            shutil.copyfileobj(chunk,target)
assert Path('validation.sample').stat().st_size == 4153303*138
""")
subprocess.run([archive/'select-sample'],cwd=dest,check=True)

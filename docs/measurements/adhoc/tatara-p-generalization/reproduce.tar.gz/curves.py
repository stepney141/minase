from pathlib import Path
import json
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import MaxNLocator

work = Path(sys.argv[1]).resolve()
source = work.parent/'tatara-p-repair-20261119'
def curve(directory):
    return [x for x in map(json.loads,(directory/'training.jsonl').read_text().splitlines())
            if x['train_loss'] is not None]
font_manager.findfont('Noto Sans CJK JP', fallback_to_default=False)
plt.rcParams.update({'font.family':'Noto Sans CJK JP', 'font.size':10,
                     'axes.spines.top':False, 'axes.spines.right':False})
fig, (a,b) = plt.subplots(1,2,figsize=(10,3.8),layout='constrained')
def line(ax, rows, x, field, label, color, style):
    vals = [r for r in rows if r[field] is not None]
    ax.plot([r[x] for r in vals],[r[field]*1000 for r in vals],style,
            color=color,label=label,linewidth=1.7,markersize=3.1)
rows=curve(source/'new-51')
line(a,rows,'epochs','train_loss','訓練','#555555','-')
line(a,rows,'epochs','validation_loss','検証','#006891','o-')
a.set(title='30本の教師で同じ局面を繰り返し学ぶ',xlabel='エポック数',ylabel='平均二乗誤差（$10^{-3}$）',ylim=(1.38,2.25))
a.set_xlim(0.82,8.2)
colors = ('#b34d24','#006891')
for directory,label,color in zip(('games','matched-positions'),('3,425局','14,048局'),colors):
    line(b,curve(work/directory),'total_steps','validation_loss',label,color,'o-')
b.set(title='局面数を揃えて対局数を変える',xlabel='更新回数',ylabel='検証の平均二乗誤差（$10^{-3}$）')
for ax in (a,b):
    ax.grid(axis='y',alpha=.22)
    ax.legend(frameon=False)
    ax.xaxis.set_major_locator(MaxNLocator(6,integer=True))
fig.savefig(sys.argv[2],dpi=170,facecolor='white')

#!/bin/bash
set -eu
root=$(cd "$(dirname "$0")" && pwd)
repo="$root/../worktrees/nnue-tatara-framework-and-halfkp-vm"
books="$root/../tatara-p-repair-20261119/books"
for unit in games positions; do
  nice -n 19 "$repo/target/release/minase-trainer" nnue train layerstack \
    --data "$books/book-00.mnsd" "$books/book-01.mnsd" --rules JCSA \
    --teacher-cp-per-logit 679.029296875 --lambda 1 --train-subsample "$unit:4:0" \
    --batch 4096 --batches-per-superbatch 160 --superbatches 16 --validation-superbatches 1 \
    --lr-schedule cosine:2441.6:0.027 --threads 2 --seed 1 --device cuda \
    --output-dir "$root/$unit" > "$root/$unit.log" 2>&1
done

"""Fixed-node comparisons on previously unused openings."""
import json
from pathlib import Path
import subprocess
import sys
work = Path(__file__).resolve().parent
archive = work.parent / 'tatara-p-repair-20261119'
repo = work.parent.parent
commit = '8b853b6655f3c2acfa41677449d2bcc8509dc66c'
runner = repo / 'target/match-cache' / commit / 'minase'
name = sys.argv[1]
candidate, baseline = {
    'ending-match': (work / 'endgame', archive / 'fp'),
    'diversity-match': (work / 'positions', work / 'games'),
    'schedule-match': (work / 'short-cosine', work / 'matched-positions'),
    'matched-volume-match': (work / 'matched-positions', work / 'games'),
    'full-vs-late-confirm': (work / 'full-selected', archive / 'new-51'),
    'full-vs-late': (work / 'full-selected', archive / 'new-51'),
    'full-vs-match-choice': (work / 'full-selected', archive / 'new-13'),
    'selection-match': (work / 'games-selected', work / 'games'),
}[name]
confirmation = name == 'full-vs-late-confirm'
seed = '20261119990000' if confirmation else '20261119950000'
pairs = '384' if confirmation else '96'
concurrency = '5' if confirmation else '3'
args = [str(runner), 'match', 'run', '--candidate', 'commit:'+commit, '--baseline', 'commit:'+commit,
        '--candidate-option', 'EvalFile='+str(candidate/'nnue.bin'),
        '--baseline-option', 'EvalFile='+str(baseline/'nnue.bin'),
        '--each', 'nodes=3000', '--candidate-hash', '32', '--baseline-hash', '32',
        '--rules', 'JCSA', '--concurrency', concurrency, '--seed', seed,
        '--run-dir', str(work/name), 'elo', '--pairs', pairs]
(work/(name+'.args.json')).write_text(json.dumps(args, indent=2))
subprocess.run(args, cwd=repo, check=True)

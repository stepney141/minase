"""Repeat the archived float fine-tune, mixing in results only at <=25 pieces."""
from pathlib import Path
import hashlib
import sys

source, output = map(Path, sys.argv[1:])
source = source.resolve()
script = source / "fine.py"
code = script.read_bytes()
assert hashlib.sha256(code).hexdigest() == "798c15e171c70dbb3b31c495ac6727d5d3702dab02429571b3fffbb6c90c286b"
anchor = 'target=torch.sigmoid(T(cp)/679.029296875)'
mix = """
records = np.memmap(d/'train.sample', 'u1', mode='r').reshape(-1,138)
end = np.bitwise_count(records[:, :18]).sum(1) <= 25
assert end.sum() == 65536 and end[:65536].all()
result = T(records[end,119].astype('f4') * 0.5)
target[:65536] = 0.75 * target[:65536] + 0.25 * result
"""
assert code.decode().count(anchor) == 1
sys.argv = [str(script), str(source / 'new-13'), 'fp', str(output.resolve()), 'cuda']
exec(compile(code.decode().replace(anchor, anchor + '\n' + mix), str(script), 'exec'),
     {'__file__': str(script), '__name__': '__main__'})

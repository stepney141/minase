"""Omit a uniform sample of training labels to match the dense arm's exact volume."""
import json
import sys
from pathlib import Path
import struct
import numpy as np

work = Path(sys.argv[1]).resolve()
archive = work.parent / 'tatara-p-repair-20261119'
out = work / 'matched-books'
out.mkdir(exist_ok=False)
step = np.uint64(0x9E3779B97F4A7C15)
def mix(x):
    a = (x ^ (x >> 30)) * np.uint64(0xBF58476D1CE4E5B9)
    b = (a ^ (a >> 27)) * np.uint64(0x94D049BB133111EB)
    return b ^ (b >> 31)
positions = []
for i in range(2):
    data = (archive/'books'/f'book-{i:02}.mnsd').read_bytes()
    seed, games = struct.unpack_from('<QQ',data,128)
    cursor = 152
    offsets = []
    with np.errstate(over='ignore'):
        for _ in range(games):
            num, = struct.unpack_from('<I',data,cursor)
            start,n = struct.unpack_from('<HI',data,cursor+8)
            first = cursor+161
            if mix(np.uint64(seed) ^ (np.uint64(num)*step)) % 20:
                flags = np.frombuffer(data,'u1',n*7,first).reshape(n,7)[:,4]
                ply = np.arange(start,start+n,dtype=np.uint64)
                key = mix(np.uint64((i<<32) | num))
                keep = (flags & 15 == 0) & (mix(key ^ (ply*step)) % 4 == 0)
                offsets.append(first + 7 * np.flatnonzero(keep))
            cursor = first + 7*n
    assert cursor == len(data)
    positions.append(np.concatenate(offsets))
def volume(unit):
    return json.loads((work/unit/'config.json').read_text())['preprocessing']['train_subsample']['training_positions_after']
assert sum(map(len,positions)) == volume('positions')
remove = np.random.default_rng(20261119).choice(volume('positions'),volume('positions')-volume('games'),replace=False)
offset=0
for i, locations in enumerate(positions):
    book = f'book-{i:02}.mnsd'
    data = bytearray((archive/'books'/book).read_bytes())
    raw = np.frombuffer(data, 'u1')
    p = locations[remove[(remove>=offset)&(remove<offset+len(locations))]-offset]
    raw[p+2] = raw[p+3] = 0
    raw[p+4] |= 8
    (out/book).write_bytes(data)
    offset += len(locations)

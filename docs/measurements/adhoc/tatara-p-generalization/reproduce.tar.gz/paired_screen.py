"""Reanalyze two earlier comparisons to the same opponent on common openings."""
import json
from pathlib import Path
import sys
import numpy as np

work = Path(sys.argv[1]).resolve()
archive = work.parent / 'tatara-p-repair-20261119' / 'matches'
def records(run):
    pairs = [json.loads(p.read_text()) for p in sorted((archive/run/'pairs').glob('*.json'))]
    return {(p['opening']['seed'],tuple(p['opening']['moves'])):p['category']/4 for p in pairs}
early,late = (records('screen-new-'+k) for k in ('13','51'))
assert len(early) == 96 and early.keys() == late.keys()
delta = np.array([late[k]-early[k] for k in early])
rng = np.random.default_rng(2718)
values = delta[rng.integers(0,len(delta),size=(20000,len(delta)))].mean(1)
print(json.dumps(dict(early=np.mean(list(early.values())),late=np.mean(list(late.values())),
                      delta=delta.mean(),ci95=list(np.quantile(values,[.025,.975]))),indent=2))

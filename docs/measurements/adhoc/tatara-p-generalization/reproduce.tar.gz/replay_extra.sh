#!/bin/bash
# Run from the main repository's data/tatara-p-generalization-20261119.
set -eu
work=$(cd "$(dirname "$0")" && pwd)
repo="$work/../worktrees/nnue-tatara-framework-and-halfkp-vm"
repair="$work/../tatara-p-repair-20261119"
trainer="$repo/target/release/minase-trainer"
python "$work/match_volume.py" "$work"
for arm in matched-positions short-cosine games-selected; do
    books=("$work"/matched-books/*.mnsd)
    subsample=positions:4:0
    horizon=2441.6
    extra=()
    case "$arm" in
        short-cosine) horizon=16 ;;
        games-selected)
            books=("$repair/books/book-00.mnsd" "$repair/books/book-01.mnsd")
            subsample=games:4:0
            extra=(--validation-patience 2)
            ;;
    esac
    nice -n 19 "$trainer" nnue train layerstack --data "${books[@]}" --rules JCSA \
        --teacher-cp-per-logit 679.029296875 --lambda 1 --train-subsample "$subsample" \
        --batch 4096 --batches-per-superbatch 160 --superbatches 16 --validation-superbatches 1 \
        --lr-schedule "cosine:$horizon:0.027" --threads 2 --seed 1 --device cuda \
        --output-dir "$work/$arm" "${extra[@]}" > "$work/$arm.log" 2>&1
done
"$work/../../tools/train/zero/.venv/bin/python" "$work/endgame.py" "$repair" "$work/endgame"
bash "$work/selected_full.sh"

#!/bin/bash
set -eu
work=$(cd "$(dirname "$0")" && pwd)
repair="$work/../tatara-p-repair-20261119"
run="$work/full-selected"
cp -r "$repair/new-13" "$run"
trainer="$work/../worktrees/tatara-after-8389b160/target/release/minase-trainer"
systemd-run --user --scope -p MemoryMax=13G -p MemorySwapMax=1G -- nice -n 19 "$trainer" nnue train layerstack \
  --data "$repair"/books/*.mnsd --output-dir "$run" --resume "$run" --rules JCSA \
  --teacher-cp-per-logit 679.029296875 --lambda 1 --batch 16384 --batches-per-superbatch 763 \
  --superbatches 18 --lr-schedule cosine:512:0.027 --validation-superbatches 6 --threads 3 --seed 1 --device cuda

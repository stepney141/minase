"""Evaluate released integers on the paired held-out sample and bootstrap games."""
import json
import subprocess
import sys
from pathlib import Path
import numpy as np

work = Path(sys.argv[1]).resolve()
archive = work.parent / 'tatara-p-repair-20261119'
reader = work.parent / 'nnue-tatara-framework-and-halfkp-vm/diagnosis-20261119/training/full-after'
sample = archive / 'validation.sample'
records = np.memmap(sample, 'u1', mode='r').reshape(-1,138)
def column(start, dtype):
    return records[:,start:start+np.dtype(dtype).itemsize].copy().view(dtype).ravel()
file = column(126,'<u4').astype('i8')
game = file*2**32 + column(122,'<u4')
pieces = np.bitwise_count(records[:,:18]).sum(1)
outcome = records[:,119]*0.5
def sigmoid(cp):
    return 1 / (1 + np.exp(-cp.astype('f8') / 679.029296875))
teacher = sigmoid(column(113,'<f4'))
def evaluate(net):
    raw = subprocess.check_output([reader, net/'nnue.bin', sample])
    scores = np.frombuffer(raw, '<i4')
    assert len(scores) == len(teacher)
    prob = sigmoid(scores)
    return np.column_stack(((prob-teacher)**2,(prob-outcome)**2))
def compare(candidate, baseline, mask):
    d = (candidate-baseline)[mask]
    _,idx,count = np.unique(game[mask],return_inverse=True,return_counts=True)
    total = np.stack([np.bincount(idx, weights=col) for col in d.T],axis=1)
    rng = np.random.default_rng(191119)
    boot=[]
    for _ in range(2000):
        g=rng.integers(0,len(count),size=len(count))
        boot.append(total[g].sum(0)/count[g].sum())
    return dict(positions=len(d),games=len(count),candidate=candidate[mask].mean(0).tolist(),
                baseline=baseline[mask].mean(0).tolist(),delta=d.mean(0).tolist(),
                ci95=np.quantile(boot,[.025,.975],axis=0).T.tolist())
def main():
    if sys.argv[2]=='epochs':
        nets=[archive / f'new-{sb}' for sb in (6,13,25,51)]+[work/'endgame',archive/'fp']
        pairs=[(0,1),(2,1),(3,1),(4,5)]
        include = np.ones(len(game),dtype=bool)
    else:
        nets=[work/'matched-positions',work/'games',work/'games-selected',work/'short-cosine']
        pairs=[(0,1),(2,1),(3,0)]
        include = file >= 2
    values=[evaluate(p) for p in nets]
    for i,j in pairs:
        result={k:compare(values[i],values[j],include & mask) for k,mask in [
            ('all',pieces>=2),('end',pieces<=25),('other',pieces>25)]}
        print(json.dumps([nets[i].name,nets[j].name,result]),flush=True)
if __name__=='__main__':
    main()
